

class VaultCuratedTransformation():
    
    @staticmethod
    def transform(dfs, spark=None):
        """
        NA to evidences at this moment.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        None. The dfs dictionary is updated in place.
        """
       
        return dfs

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            
            "evidences": {"table": dfs.get('evidences'), "type": "fact", "path": "tc/vault/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id and source.appclient == target.appclient'},
            "trustcloudfile": {"table": dfs.get('trustcloudfile'), "type": "fact", "path": "tc/vault/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id and source.appclient == target.appclient'}

        }


        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items() if v['table'] is not None}

        return dfs_dict

