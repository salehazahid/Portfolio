from trustcloud.aws_glue import Pipeline

VAULT_MODEL = {
    "source_paths": {

         'trustcloudfile': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'tc/vault/',
            "version": "/v1",
            "type": "jdbc"
        },

        'evidences': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'tc/vault/',
            "version": "/v1",
            "type": "jdbc"
        }
    },
    "delta_paths": {
        "evidences": {"path": "tc/vault/evidences/", "filter": True},
        "trustcloudfile": {"path": "tc/vault/trustcloudfile/", "filter": True}
    }
}
