from datalake_transformation import select_cols
from pyspark.sql import functions as f
from datalake_transformation import flatten, select_cols
from pyspark.sql.functions import col, from_utc_timestamp, to_date, concat_ws, year, month, dayofmonth, hour, lpad

class JumioLegacyTransform():

    def transform_links(df):
        # Assuming df_datasource0 is already loaded
        df = df.withColumn("DateCreated", f.to_timestamp(
            "Date", "MM/dd/yyyy HH.mm:ss.SSS"))
        enc_df = df.drop('Date', 'eMailUser')
        df = enc_df.fillna({'manualSnapshot': 0, 'filterBlur': 0})

        return df

    def _transform_logs(df, spark):
        json_schema = spark.read.json(df.rdd.map(
            lambda row: row.ResponseSource)).schema
        df_with_struct = df.withColumn('ResponseSource', f.from_json(
            f.col('ResponseSource'), json_schema))
        flat_df = flatten(df_with_struct)

        fields_to_drop = ['ResponseSource_callBackType',
                          'ResponseSource_idScanSource',
                          'ResponseSource_idSubtype',
                          'ResponseSource_idScanImage',
                          'ResponseSource_idScanImageFace',
                          'ResponseSource_idScanImageBackside',
                          'ResponseSource_idNumber',
                          'ResponseSource_idFirstName',
                          'ResponseSource_idLastName',
                          'ResponseSource_idExpiry',
                          'ResponseSource_idUsState',
                          'ResponseSource_personalNumber',
                          'ResponseSource_merchantIdScanReference',
                          'ResponseSource_clientIp',
                          'ResponseSource_firstAttemptDate',
                          'ResponseSource_optionalData1',
                          'ResponseSource_optionalData2',
                          'ResponseSource_dni',
                          'ResponseSource_curp',
                          'ResponseSource_presetCountry',
                          'ResponseSource_presetIdType',
                          'ResponseSource_dlCarPermission',
                          'ResponseSource_dlCategories',
                          'ResponseSource_passportNumber',
                          'ResponseSource_durationOfStay',
                          'ResponseSource_numberOfEntries',
                          'ResponseSource_visaCategory',
                          'ResponseSource_originDob',
                          'ResponseSource_issuingAuthority',
                          'ResponseSource_issuingDate',
                          'ResponseSource_issuingPlace',
                          'ResponseSource_livenessImages',
                          'ResponseSource_idCheckDataPositions',
                          'ResponseSource_idCheckDocumentValidation',
                          'ResponseSource_idCheckMRZcode',
                          'ResponseSource_idCheckMicroprint',
                          'ResponseSource_idCheckSecurityFeatures',
                          'ResponseSource_idCheckSignature']

        dropunnecesary_df = flat_df.drop(*fields_to_drop)

        original_columns = [("ResponseSource_jumioIdScanReference", "string", "jumioIdScanReference", "string"),
                            ("ResponseSource_customerId",
                             "string", "customerId", "string"),
                            ("ResponseSource_verificationStatus",
                             "string", "verificationStatus", "string"),
                            ("ResponseSource_idScanStatus",
                             "string", "idScanStatus", "string"),
                            ("ResponseSource_idCheckHologram",
                             "string", "idCheckHologram", "string"),
                            ("ResponseSource_transactionDate",
                             "string", "transactionDate", "timestamp"),
                            ("ResponseSource_callbackDate",
                             "string", "callbackDate", "timestamp"),
                            ("ResponseSource_identityVerification_similarity",
                             "string", "similarity", "string"),
                            ("ResponseSource_identityVerification_validity",
                             "string", "validity", "string"),
                            ("ResponseSource_identityVerification_reason",
                             "string", "reason", "string"),
                            ("ResponseSource_identityVerification_handwrittenNoteMatches",
                             "string", "handwrittenNoteMatches", "string"),
                            ("ResponseSource_idType", "string", "idType", "string"),
                            ("ResponseSource_idCountry",
                             "string", "idCountry", "string"),
                            ("ResponseSource_rejectReason_rejectReasonCode",
                             "string", "rejectReasonCode", "string"),
                            ("ResponseSource_rejectReason_rejectReasonDescription",
                             "string", "rejectReasonDescription", "string"),
                            ("ResponseSource_idDob", "string", "idDob", "string"),
                            ("ResponseSource_idAddress_country",
                             "string", "addressCountry", "string"),
                            ("ResponseSource_idAddress_city",
                             "string", "address", "string"),
                            ("ResponseSource_gender", "string", "gender", "string"),
                            ("ResponseSource_nationality",
                             "string", "nationality", "string"),
                            ("CreationDate", "timestamp",
                             "creationDate", "timestamp"),
                            ("ResponseSource_merchantReportingCriteria",
                             "string", "merchantReportingCriteria", "string"),
                            ("year", "string", "year", "string"),
                            ("month", "string", "month", "string"),
                            ("day", "string", "day", "string"),
                            ("appclient", "string", "appclient", "string")
                            ]  # Your list of original columns for verificationlog.

        for col_original, original_type, col_name, cast_type in original_columns:
            dropunnecesary_df = dropunnecesary_df.withColumn(
                col_name, f.col(col_original).cast(cast_type))

        renamed_df_temp = dropunnecesary_df.select(
            *[dropunnecesary_df[col_name].alias(col_name) for col_original, original_type, col_name, cast_type in original_columns]
        )

        filled_df = renamed_df_temp.fillna({
            "verificationStatus": '0',
            "customerId": 'NA',
            "nationality": 'NA'
        })

        df_verificationlog = filled_df.orderBy(
            f.col('CreationDate').desc()).dropDuplicates(["jumioIdScanReference"])

        columns_to_select = [

            ("ResponseSource_jumioIdScanReference",
             "string", "jumioIdScanReference", "string"),
            ("CreationDate", "timestamp",
             "creationDate", "timestamp"),
            ("ResponseSource_customerId", "string", "customerId", "string"),
            ("ResponseSource_transactionDate",
             "string", "transactionDate", "timestamp"),
            ("ResponseSource_callbackDate", "string", "callbackDate", "timestamp"),
            ("ResponseSource_rejectReason_rejectReasonCode", "string", "rejectReasonCode", "string"),
            ('ResponseSource_rejectReason_rejectReasonDetails_detailsCode',"string", "detailsCode", "int"),
            ('ResponseSource_rejectReason_rejectReasonDescription',"string", "rejectreasondescription", "string"),
            ('ResponseSource_rejectReason_rejectReasonDetails_detailsDescription',"string", "detailsDescription", "string"),
            ("year", "string", "year", "string"),
            ("month", "string", "month", "string"),
            ("day", "string", "appcdaylient", "string"),
            ("appclient", "string", "appclient", "string")
        ]

        # Cast columns for jumio codes BEFORE renaming.
        for col_original, original_type, col_name, cast_type in columns_to_select:
            flat_df = flat_df.withColumn(
                col_name, f.col(col_original).cast(cast_type))

        df_jumio_codes = flat_df.select(
            *[flat_df[col_name].alias(col_name) for col_original, original_type, col_name, cast_type in columns_to_select]
        )
        df_jumio_codes = df_jumio_codes.filter(f.col("rejectreasondescription").isNotNull())
        df_dm_jumioscanReference = df_verificationlog.select(
            "jumioIdScanReference")
        return df_verificationlog, df_jumio_codes, df_dm_jumioscanReference

    def transform(dfs, spark):
        """
        Transforms calls and telemetry dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        None. The dfs dictionary is updated in place.
        """
        useraccesslink = dfs.get('useraccesslink')
        stats = dfs.get('stats')
        verificationlog = dfs.get('verificationlog')
        if stats is None or useraccesslink is None:
            raise ValueError(
                "Both calls and telemetry dataframes must be provided")

        dfs['useraccesslink'] = JumioLegacyTransform.transform_links(useraccesslink)
        dfs['stats'] = stats
        dfs['verificationlog'], dfs['jumio_codes'], dfs['dm_jumioscanReference'] = JumioLegacyTransform._transform_logs(verificationlog, spark)
        return dfs

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {

                              
            "stats": {"table": dfs.get('stats'), "type": "fact", "path": "tc/vu/", "version": "/v1",  'merge_conditions':   "source.Id = target.Id"}, #TODO: set the id column (if you rename de id with bussines id) merge with appclient column example "source.Id == target.Id and source.appclient == target.appclient",
            "verificationlog": {"table": dfs.get('verificationlog'), "type": "fact", "path": "tc/vu/", "version": "/v1",  'merge_conditions': "source.jumioidscanreference = target.jumioidscanreference"}, #TODO: set the id column merge with appclient column,
            "useraccesslink": {"table": dfs.get('useraccesslink'), "type": "fact", "path": "tc/vu/", "version": "/v1",  'merge_conditions':  "source.Id = target.Id"}, #TODO: set the id column merge with appclient column
            "jumio_codes": {"table": dfs.get('jumio_codes'), "type": "dm", "path": "tc/vu/", "version": "/v1",  'merge_conditions': "source.jumioidscanreference = target.jumioidscanreference and source.detailscode = target.detailscode"}, #TODO: set the id column merge with appclient column
            "dm_jumioscanReference": {"table": dfs.get('dm_jumioscanReference'), "type": "dm", "path": "tc/vu/", "version": "/v1",  'merge_conditions': "source.jumioidscanreference = target.jumioidscanreference"}, #TODO: set the id column merge with appclient column
            

        }

        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items()
                    if v['table'] is not None}

        return dfs_dict

class UnassistedSQLTransformation():
   
    @staticmethod

    def add_date_cest_columns(df, column=None, type="calls"):
        """
        Adds CEST (Central European Summer Time) date and time columns to a DataFrame. 
        Handles different columns based on the type specified.

        Args:
            df (DataFrame): The Spark DataFrame to be modified.
            column (str): The name of the column to be used for CEST date/time conversion. 
                        Used only when type is not 'calls'.
            type (str): The type of data being processed. If 'calls', uses 'DateCreated' 
                        and 'DateVideoCreated' columns. Otherwise, uses the specified column.

        Returns:
            DataFrame: The modified DataFrame with added CEST date/time columns.
        """

        if type == "calls":
            # Handling 'calls' type with 'DateCreated' and 'DateVideoCreated' columns
            columns_to_convert = ["Date_Created", "Date_Video_Created"]
        else:
            # Handling other types with a specified column
            if column is None:
                raise ValueError("Column name must be provided for types other than 'calls'")
            columns_to_convert = [column]

        for col_name in columns_to_convert:
            cest_col = f"{col_name}_CEST"
            cest_key_col = f"{col_name}_Key_CEST"
            hour_col = f"{col_name}_Hour_CEST_Id"

            # Convert UTC to CEST and create corresponding columns
            df = df.withColumn(cest_col, from_utc_timestamp(col(col_name), "Europe/Madrid"))
            df = df.withColumn(cest_key_col, concat_ws("",
                                                    year(col(cest_col)),
                                                    lpad(month(col(cest_col)), 2, '0'),
                                                    lpad(dayofmonth(col(cest_col)), 2, '0')))
            df = df.withColumn(hour_col, hour(col(cest_col)))

        return df


    @staticmethod
    def transform(dfs: dict,spark) -> dict:
        """
        This function takes as input a dictionary containing the various dataframes for VideoID Unassited raw data and performs various transformations on the 
        dataframes such that it is in the required format for the curated layer when returned
        
        :param dfs: Dictionary containing dataframes
        :return: Dictionary containing the transformed dataframes
        """
        
        vuidentification_columns ={
            'Id': 'Link_Id',
            'DateCreated': 'Date_Created',
            'TrustCloudIdentityId': 'TrustCloud_IdentityId',
            'DocType': 'Doc_Type',
            'DocNumber': 'Doc_Number',
            'DocumentCountry': 'Document_Country',
            'InputRaw': 'Input_Raw',
            'ClientReference': 'Client_Reference',
            'TrustCloudFileId': 'TrustCloud_FileId',
            'DateVideoCreated': 'Date_Video_Created',
            'DateVideoEnded': 'Date_Video_Ended',
            'Device': 'Device',
            'OS': 'OS',
            'Browser': 'Browser',
            'MRZVerified': 'MRZ_Verified',
            'MRZTaskId': 'MRZ_TaskId',
            'DocumentIdTaskId': 'DocumentId_TaskId',
            'VideoSessionId': 'Video_SessionId',
            'VideoRecordingId': 'Video_RecordingId',
            'NfcTaskId': 'Nfc_TaskId',
            'RecognitionLog': 'Recognition_Log',
            'IsLivenessProcess': 'Is_Liveness_Process',
            'CreatedBy': 'Created_By',
            'TypeOfGenerator': 'Type_Of_Generator',
            'ConsentData': 'Consent_Data',
            'VideoRecorderLog': 'Video_Recorder_Log',
            'DeepFakesTaskIds': 'DeepFakes_TaskIds',
            'appclient': 'appclient',
            'year': 'year',
            'month': 'month'
    }

        
        vuimagecaptures_columns = {
            'Id':'Id',
            'SessionReference': 'Session_Reference',
            'VideoUnassistedIdentificationId': 'Link_Id',
            'FrontImageFileName': 'FrontImage_FileName',
            'BackImageFileName': 'BackImage_FileName',
            'FaceImageFileName': 'FaceImage_FileName',
            'VideoSnapshotFileName': 'VideoSnapshot_FileName',
            'VideoFileName': 'Video_FileName',
            'CreationDate': 'Creation_Date',
            'ModificationDate': 'Modification_Date',
            'LivenessImage1FileName': 'LivenessImage1_FileName',
            'LivenessImage2FileName': 'LivenessImage2_FileName',
            'CutFrontImageFileName': 'Cut_FrontImage_FileName',
            'CutFaceImageFileName': 'Cut_FaceImage_FileName',
            'PassiveLifeLiveness': 'Passive_Life_Liveness',
            'BackImageRaw': 'BackImage_Raw',
            'FrontImageRaw': 'FrontImage_Raw',
            'appclient': 'appclient',
            'year': 'year',
            'month': 'month'
        }
        
        vunotificationstatus_columns = {
            'Id': 'Id',
            'UseCaseId': 'UseCase_Id',
            'TrustCloudIdentityId': 'TrustCloud_IdentityId',
            'VideoIdentificationId': 'Link_Id',
            'Status': 'Status',
            'DateCreated': 'Date_Created',
            'Result': 'Result',
            'ClientReference': 'Client_Reference',
            'State': 'State',
            'TrustCloudFileId': 'TrustCloud_FileId',
            'EvidencesStatus': 'Evidences_Status',
            'StatusName': 'Status_Name',
            'appclient': 'appclient',
            'year': 'year',
            'month': 'month'
        }
        
        # Select only the required columns for the curated layer from the raw VideoUnassistedIdentification dataframe 
        vuid_df = dfs.get('VideoUnassistedIdentification')
        vuid_df = select_cols(df=vuid_df,cols_or_mapping=vuidentification_columns) 
        vuid_df = UnassistedSQLTransformation.add_date_cest_columns(vuid_df)
        dfs['VideoUnassistedIdentification'] = vuid_df
        
        
        # Select only the required columns for the curated layer from the raw VideoUnassistedImagesCaptures dataframe 
        vuimagecaptures_df = dfs.get('VideoUnassistedImagesCaptures')
        vuimagecaptures_df = select_cols(df=vuimagecaptures_df,cols_or_mapping=vuimagecaptures_columns) 
        dfs['VideoUnassistedImagesCaptures'] = vuimagecaptures_df 
        
        # Select only the required columns for the curated layer from the raw VideoUnassistedNotificationStatus dataframe 
        vunotificationstatus_df = dfs.get('VideoUnassistedNotificationStatus')
        vunotificationstatus_df = select_cols(df=vunotificationstatus_df,cols_or_mapping=vunotificationstatus_columns) 
        dfs['VideoUnassistedNotificationStatus'] = vunotificationstatus_df 
        
        return dfs

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            
 
            "VideoUnassistedIdentification": {"table": dfs.get('VideoUnassistedIdentification'), "type": "fact", "path": "tc/vu/", "version": "/v1", 'merge_conditions':   "source.link_id == target.link_id and source.appclient == target.appclient"}, #TODO: set the id column (if you rename de id with bussines id) merge with appclient column example "source.Id == target.Id and source.appclient == target.appclient",
            "VideoUnassistedImagesCaptures": {"table": dfs.get('VideoUnassistedImagesCaptures'), "type": "fact", "path": "tc/vu/", "version": "/v1",   'merge_conditions':   "source.id == target.id and source.appclient == target.appclient"}, #TODO: set the id column merge with appclient column,
            "VideoUnassistedNotificationStatus": {"table": dfs.get('VideoUnassistedNotificationStatus'), "type": "fact", "path": "tc/vu/", "version": "/v1",   'merge_conditions':   "source.id == target.id and source.appclient == target.appclient"}, #TODO: set the id column merge with appclient column

        }
 
        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items()
                    if v['table'] is not None}

        return dfs_dict

class CuratedUnassistedTransformation():
   
    
    @staticmethod
    def transform(dfs: dict,spark) -> dict:
        """
        This function takes as input a dictionary containing the various dataframes for VideoID Unassited raw data and performs various transformations on the 
        dataframes such that it is in the required format for the curated layer when returned
        
        :param dfs: Dictionary containing dataframes
        :return: Dictionary containing the transformed dataframes
        """
        df_columns =  [
                'id', #unique identifier   
                'trustcloudfileid',
                'type',
                'clientreference',
                'engine',
                'eventtimestamp',
                'frontdocumentpath',
                'status',
                'summarydocumentpath',
                'timestamp',
                'trustcloudidentityid',
                'usecaseid',
                'usecasename',
                'iddocumentprocessentitydata_city',
                'iddocumentprocessentitydata_concordanceratio',
                'iddocumentprocessentitydata_documentnumber',
                'iddocumentprocessentitydata_documentprocessresult',
                'iddocumentprocessentitydata_error',
                'iddocumentprocessentitydata_expirydate',
                'iddocumentprocessentitydata_facematchresult',
                'iddocumentprocessentitydata_id',
                'iddocumentprocessentitydata_idcountry',
                'iddocumentprocessentitydata_identificationnumber',
                'iddocumentprocessentitydata_idtype',
                'iddocumentprocessentitydata_nationality',
                'iddocumentprocessentitydata_documentvalidationtest_colorimage',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzbirthdate',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzdocumentnumber',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzexpirydate',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzidentificationnumber',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzname',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzsex',
                'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzsurname',
                'iddocumentprocessentitydata_documentvalidationtest_expirydate',
                'iddocumentprocessentitydata_documentvalidationtest_globalauthenticityratio',
                'iddocumentprocessentitydata_documentvalidationtest_identificationnumberchecksum',
                'iddocumentprocessentitydata_documentvalidationtest_isglobalauthenticityvalid',
                'iddocumentprocessentitydata_documentvalidationtest_mrzfieldbirthdate',
                'iddocumentprocessentitydata_documentvalidationtest_mrzfielddocumentnumber',
                'iddocumentprocessentitydata_documentvalidationtest_mrzfieldexpirydate',
                'iddocumentprocessentitydata_documentvalidationtest_mrzglobalintegrity',
                'iddocumentprocessentitydata_documentvalidationtest_sidecorrespondence',
                'iddocumentprocessentitydata_facematchtest_ratio',
                'iddocumentprocessentitydata_facematchtest_reason',
                'iddocumentprocessentitydata_facematchtest_result',
                'appclient',
                'year',
                'month',
                ]

                    
        # Select only the required columns for the curated layer from the raw VideoUnassistedIdentification dataframe 
        id_df = dfs.get('identifications')
        id_df = select_cols(df=id_df,cols_or_mapping=df_columns) 
        
        dfs['identifications'] = id_df
        
        return dfs
    

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            "identifications": {"table": dfs.get('identifications'), "type": "fact", "path": "tc/vu/", "version": "/v1",  'merge_conditions':   "source.id == target.id and source.appclient == target.appclient"},

        }

        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items()
                    if v['table'] is not None}

        return dfs_dict