from trustcloud.aws_glue import Pipeline
from trustcloud.videoid.unassisted.model.raw_model import VU_MODEL
from trustcloud.videoid.unassisted.model.landing_model import VU_MODEL_LANDING
from trustcloud.aws_glue.config.etl_config import load_config
from trustcloud.videoid.unassisted.transformations import JumioLegacyTransform, UnassistedSQLTransformation,CuratedUnassistedTransformation


def run_etl(**kwargs):
    """
    Run the ETL (Extract, Transform, Load) pipeline.

    This function runs the RAW and CURATED ETL processes in sequence.
    The RAW process extracts data from the source, transforms it, and loads it into the RAW layer of the data lake.
    The CURATED process extracts data from the RAW layer, transforms it, and loads it into the CURATED layer of the data lake.

    :param spark: Spark session object.
    :param bucket_in: S3 bucket where the input data is stored.
    :param bucket_out: S3 bucket where the output data will be stored.
    :param partitions: Number of partitions to use when writing data.
    :param connections: Dictionary of database connections.
    :param env: Environment ('dev', 'prod', etc.).
    :param etl_type: Type of ETL process to run ('raw', 'curated', or 'both'). Default is 'both'.

    """

    # RUN RAW ETL PROCESS
    """
    Extract data from the source, transform it, and load it into the RAW layer of the data lake.
    """
    days = kwargs.get("days", None)
    hours = kwargs.get("hours", None) 
    minutes = kwargs.get("minutes", None) #TODO
    dimensions = kwargs.get("dimensions", False) #TODO
    etl_type = kwargs.get("etl_type", "all")
    islocal = kwargs.get("islocal", False)
    env = kwargs.get("env", "pro")
    transformation_layers = [JumioLegacyTransform, UnassistedSQLTransformation,CuratedUnassistedTransformation] if kwargs.get("include_legacy", False) else [UnassistedSQLTransformation,CuratedUnassistedTransformation]
    job, spark, connections, bucket_in, bucket_out, partitions, env = load_config(islocal=islocal, env = env)
    # spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled","true")
    # spark.conf.set("spark.sql.caseSensitive", "true")
    # Set result to False by default while testing
    result = False

    if etl_type in [ "landing", "all"]:
        
        Pipeline.run(spark=spark,
                              bucket=bucket_in,
                              bucket_in = bucket_in.replace("raw", "landing"),
                              partitions=["appclient", "year", "month"],
                              connections=connections,
                              processing_map=VU_MODEL_LANDING.get("source_paths"),
                              layer="landing",
                              days=days,
                              product='vu'
                                )


    if etl_type in ["raw", "all"]:

        result = Pipeline.run(spark=spark,
                              bucket=bucket_in,
                              bucket_in=bucket_in,
                              partitions=["appclient", "year", "month"],
                              connections=connections,
                              processing_map=VU_MODEL.get("source_paths"),
                              layer="raw",
                              days=days,
                              hours=hours,
                              product='vu'
                 

                              )

    # RUN CURATED ETL PROCESS
    """
    Extract data from the RAW layer, transform it, and load it into the CURATED layer of the data lake.
    """
    if etl_type in ["curated", "all"]:

        Pipeline.run(spark=spark,
                     bucket_in=bucket_in,
                     bucket_out=bucket_out.replace("raw","curated"),
                     partitions=["appclient", "year", "month"],
                     connections=connections,
                     table_paths=VU_MODEL.get("delta_paths"),
                     layer="curated",
                     transformation_layers=transformation_layers,
                     date_event=result,
                     product='vu',
                     dimensions=dimensions
                     )

    job.commit()
