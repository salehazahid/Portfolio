from trustcloud.aws_glue import Pipeline

VU_MODEL = {
    "source_paths": {
        "VideoUnassistedImagesCaptures": {
            "function": lambda df, customer: Pipeline.format_timestamp_column(df, ["CreationDate", "ModificationDate"], customer),
            "merge_conditions": "source.Id == target.Id and  source.appclient == target.appclient",
            "path": "tc/vu/",
            "version": "/v1",
            "type": "jdbc"
        },
        "useraccesslink": {
            "function": lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            "merge_conditions": "source.Id == target.Id and source.appclient == target.appclient",
            "path": "tc/vu/",
            "database": "TCJumioEbury",
            "version": "/v1",
            "type": "jdbc"
        },
        "stats": {
            "function": lambda df, customer: Pipeline.get_raw_data(df, customer, "AccessDate"),
            "merge_conditions": "source.Id == target.Id and source.appclient == target.appclient",
            "path": "tc/vu/",
            "database": "TCJumioEbury",
            "version": "/v1",
            "type": "jdbc"
        },
        "verificationlog": {
            "function": lambda df, customer: Pipeline.get_raw_data(df, customer, "CreationDate"),
            "merge_conditions": "source.Id == target.Id and source.appclient == target.appclient",
            "path": "tc/vu/",
            "database": "TCJumioEbury",
            "version": "/v1",
            "type": "jdbc"
        },
        "VideoUnassistedIdentification": {
            "function": lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            "merge_conditions": "source.Id == target.Id and source.appclient == target.appclient",
            "path": "tc/vu/",
            "version": "/v1",
            "type": "jdbc"
        },

        "VideoUnassistedNotificationStatus": {
            "function": lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            "merge_conditions": "source.Id == target.Id and  source.appclient == target.appclient",
            "path": "tc/vu/",
            "version": "/v1",
            "type": "jdbc"
        },
    

    },
    "delta_paths": {
        "stats": {"path": "tc/vu/stats/", "filter": False},
        "verificationlog": {"path": "tc/vu/verificationlog/", "filter": False},
        "useraccesslink": {"path": "tc/vu/useraccesslink/", "filter": False},
        "identifications": {"path": "tc/vu/identifications/", "filter": True},
        "VideoUnassistedIdentification": {"path": "tc/vu/VideoUnassistedIdentification/", "filter": True},
        "VideoUnassistedImagesCaptures": {"path": "tc/vu/VideoUnassistedImagesCaptures/", "filter": True},
        "VideoUnassistedNotificationStatus": {"path": "tc/vu/VideoUnassistedNotificationStatus/", "filter": True},
    },
}
