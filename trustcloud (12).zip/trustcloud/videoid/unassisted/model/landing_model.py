from trustcloud.aws_glue import Pipeline

VU_MODEL_LANDING = {
    "source_paths": {
      
         "identifications": {
            "function":lambda spark, df: Pipeline.get_landing_data(spark, df, "TrustCloudID"),
            "merge_conditions": "source.id == target.id and  source.appclient == target.appclient" ,
            "path": "tc/vu/",
            "version": "/v1",
            "type": "datalake",
            "format":"parquet",
            "source_path" :"tc/dynamodb/events/"
        },
        

    },
    "delta_paths": {
        "identifications": {"path": "tc/vu/identifications/", "filter": False}
    },
}
