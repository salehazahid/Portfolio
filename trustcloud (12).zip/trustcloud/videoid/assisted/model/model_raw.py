from trustcloud.aws_glue import Pipeline
from trustcloud.videoid.assisted.transformations.raw import VideoIdRawTransformation


VA_MODEL = {
    "source_paths": {
            'videoidentifications': {
                'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
                'merge_conditions': 'source.Id == target.Id',
                'path': 'tc/va/',
                "version": "/v1",
                'type' :"jdbc"
            },
            
            'customers': {
                'function': lambda df: VideoIdRawTransformation.get_raw_customers(df),
                'path': 'tc/admin/',
                'database': 'TrusCloudAdmin',
                "version": "/v1",
                 'type' :"jdbc"
            },
            'agents': {
                'function': lambda df: VideoIdRawTransformation.get_raw_agents(df),
                'path': 'tc/admin/',
                'database': 'TrustCloudPortalV2',
                "version": "/v1",
                 'type' :"jdbc"
            },
            'telemetry': {
                'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "EventDate"),
                'merge_conditions': 'source.Id == target.Id',
                'path': 'tc/va/',
                "version": "/v1",
                 'type' :"jdbc"
            }
       
        
    },
    "delta_paths": {
        "videoidentifications": {"path": "tc/va/videoidentifications/", "filter": True},
        "customers": {"path": "tc/admin/customers/", "filter": False},
        "agents": {"path": "tc/admin/agents/", "filter": False},
        "evidences": {"path": "tc/vault/evidences/", "filter": True},
        "telemetry": {"path": "tc/va/telemetry/", "filter": True},
    }
}
