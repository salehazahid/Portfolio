DIMENSIONS = [
    {
        "table_name": "dm_country",
        "version": "/v1",
        "schema": [
            {"name": "service_country", "type": "StringType", "nullable": True},
            {"name": "service_country_id", "type": "IntegerType", "nullable": True},
            {"name": "country_name", "type": "StringType", "nullable": True}
        ],
        "data": [
            ['AE', 1, 'United Arab Emirates'],
            ['AF', 2, 'Afghanista'],
            ['AI', 3, 'Anguilla'],
            ['AL', 4, 'Albania'],
            ['AO', 5, 'Anla'],
            ['AR', 6, 'Argentina'],
            ['AT', 7, 'Austria'],
            ['AU', 8, 'Australia'],
            ['AZ', 9, 'Azerbaija'],
            ['BA', 10, 'Bosnia and Herzevina'],
            ['BD', 11, 'Bangladesh'],
            ['BE', 12, 'Belgium'],
            ['BF', 13, 'Burkina Faso'],
            ['BG', 14, 'Bulgaria'],
            ['BJ', 15, 'Beni'],
            ['BO', 16, 'Bolivia'],
            ['BR', 17, 'Brazil'],
            ['BZ', 18, 'Belize'],
            ['CA', 19, 'Canada'],
            ['CH', 20, 'Switzerland'],
            ['CI', 21, 'Ivory Coast'],
            ['CL', 22, 'Chile'],
            ['CM', 23, 'Cameroo'],
            ['CN', 24, None],
            ['CO', 25, 'Colombia'],
            ['CR', 26, 'Costa Rica'],
            ['CU', 27, 'Cuba'],
            ['DE', 28, 'Germany'],
            ['DK', 29, 'Denmark'],
            ['DO', 30, 'Dominican Republic'],
            ['DZ', 31, 'Algeria'],
            ['EG', 32, 'Egypt'],
            ['ES', 33, 'Spain'],
            ['ET', 34, 'Ethiopia'],
            ['GB', 35, 'United Kingdom'],
            ['GE', 36, 'Georgia'],
            ['GH', 37, 'Ghana'],
            ['GM', 38, 'Gambia'],
            ['GN', 39, None],
            ['GR', 40, 'Greece'],
            ['GW', 41, 'Guinea-Bissau'],
            ['HR', 42, 'Croatia'],
            ['HT', 43, 'Haiti'],
            ['HU', 44, 'Hungary'],
            ['ID', 45, 'Indonesia'],
            ['IE', 46, 'Ireland'],
            ['IL', 47, 'Israel'],
            ['IN', 48, None],
            ['IR', 50, 'Ira'],
            ['IQ', 49, 'Iraq'],
            ['IT', 51, 'Italy'],
            ['JM', 52, 'Jamaica'],
            ['JO', 53, 'Jorda'],
            ['K1', 54, None],
            ['KE', 55, 'Kenya'],
            ['KO', 56, None],
            ['KZ', 57, 'Kazakhsta'],
            ['LB', 58, 'Lebano'],
            ['LR', 59, 'Liberia'],
            ['LT', 60, 'Lithuania'],
            ['LV', 61, 'Latvia'],
            ['MA', 62, 'Morocco'],
            ['MD', 63, 'Moldova'],
            ['ME', 64, 'Montenegro'],
            ['MG', 65, 'Madagascar'],
            ['MK', 66, 'Macedonia'],
            ['ML', 67, 'Mali'],
            ['MM', 68, 'Myanmar'],
            ['MX', 69, 'Mexico'],
            ['MZ', 70, 'Mozambique'],
            ['NE', 71, 'Niger'],
            ['NG', 72, 'Nigeria'],
            ['NI', 73, 'Nicaragua'],
            ['NL', 74, 'Netherlands'],
            ['NO', 75, 'Norway'],
            ['PA', 76, 'Panama'],
            ['PE', 77, 'Peru'],
            ['PH', 78, 'Philippines'],
            ['PK', 79, 'Pakista'],
            ['PL', 80, 'Poland'],
            ['PS', 81, 'Palestine'],
            ['PT', 82, 'Portugal'],
            ['RO', 83, 'Romania'],
            ['RS', 84, 'Serbia'],
            ['RU', 85, 'Russia'],
            ['RW', 86, 'Rwanda'],
            ['SA', 87, 'Saudi Arabia'],
            ['SD', 88, 'Suda'],
            ['SE', 89, 'Swede'],
            ['SI', 90, 'Slovenia'],
            ['SL', 91, 'Sierra Leone'],
            ['SN', 92, None],
            ['SS', 93, 'South Suda'],
            ['SY', 94, 'Syria'],
            ['TG', 95, 'To'],
            ['TH', 96, 'Thailand'],
            ['TJ', 97, 'Tajikista'],
            ['TM', 98, 'Turkmenista'],
            ['TN', 99, None],
            ['TR', 100, 'Turkey'],
            ['TZ', 101, 'Tanzania'],
            ['UA', 102, 'Ukraine'],
            ['UG', 103, 'Uganda'],
            ['UZ', 104, 'Uzbekista'],
            ['VC', 105, 'Saint Vincent and the Grenadines'],
            ['VE', 106, 'Venezuela'],
            ['VN', 107, None],
            ['YE', 108, 'Yeme'],
            ['ZM', 109, 'Zambia'],
            ['ZW', 110, 'Zimbabwe'],
            ['LK',111,'Sri Lanka'],
            ['US',112,'United States'],
            ['FR',113,'France'],
            ['GP',114,'Guadeloupe'],
            ['CZ',115,'Czech Republic'],
            ['GF',116,'French Guiana'],
            ['MQ',117,'Martinique']

        ]
    },
    {
        "table_name": "dm_asa_segmentation",
        "version": "/v1",
        "schema": [
            {"name": "segment_asa_id", "type": "IntegerType", "nullable": True},
            {"name": "time", "type": "StringType", "nullable": True}
        ],
        "data": [
                [0, 'NA'],
                [2, '> 1 min - < 2 min'],
                [4, '> 3 min - < 4 min'],
                [6, '> 5 min - < 10 min'],
                [8, '> 20 min - < 30 min'],
                [1, '< 1 min'],
                [3, '> 2 min - < 3 min'],
                [5, '> 4 min - < 5 min'],
                [7, '> 10 min - < 20 min'],
                [9, '> 30min']
            ]
    },
    {
        "table_name": "dm_lang",
        "version": "/v1",
        "schema": [
            {"name": "language_document", "type": "StringType", "nullable": True},
            {"name": "language_document_id", "type": "IntegerType", "nullable": True}
        ],
        "data": [
                    ['DE', 1],
                    ['ES', 3],
                    ['PL', 5],
                    ['EN', 2],
                    ['IT', 4],
                    ['RO', 6],
                    ['FR', 7],
                    ['NL', 8],  # Holandés
                    ['GR', 9],  # Griego
                    ['PT', 10],
                    ['RU', 11],
                    ['UK', 12],  # Ucraniano
                    ['CZ', 13],  # Checo
                    ['HU', 14],  # Húngaro
                    ['SE', 15],  # Sueco
                    ['FI', 16],  # Finlandés
                    ['NO', 17],  # Noruego
                    ['DK', 18],  # Danés
                    ['BG', 19],  # Búlgaro
                    ['HR', 20],  # Croata
                    ['SR', 21],  # Serbio
                    ['SK', 22],  # Eslovaco
                    ['SL', 23],  # Esloveno
                    ['LT', 24],  # Lituano
                    ['LV', 25],  # Letón
                    ['EE', 26],  # Estonio
                    ['IS', 27],  # Islandés
                    ['AL', 28],  # Albanés
                    ['MT', 29],  # Maltés
                    ['MK', 30],  # Macedonio
                    ['BA', 31],  # Bosnio
                    ['ME', 32],  # Montenegrino
                    ['MD', 33],  # Moldavo
                    ['GE', 34],  # Georgiano
                    ['AM', 35],  # Armenio
                    ['AZ', 36],  # Azerí
                    ['CY', 37]   # Chipriota
        
        ]
    },
    {
        "table_name": "dm_qc",
        "version": "/v1",
        "schema": [
            {"name": "qc_id", "type": "IntegerType", "nullable": True},
            {"name": "call_result", "type": "StringType", "nullable": True},
            {"name": "call_status", "type": "StringType", "nullable": True}
        ],
        "data": [   [0, 'Successful process', 'OK'],
                    [1, 'The agent couldn´t see the user', 'Connectivity'],
                    [2, 'The agent couldn´t hear the user', 'Connectivity'],
                    [3, 'The user couldn´t see or hear the agent', 'Connectivity'],
                    [7, 'The user didn´t have the correct ID document', 'Form/Document related'],
                    [8, 'The user´s document was not in good conditions', 'Form/Document related'],
                    [9, 'The user identity didn´t match with the one on the document', 'Fraud'],
                    [10, 'The type of document didn´t match with the one on the form', 'Form/Document related'],
                    [11, 'The number of the document didn´t match', 'Form/Document related'],
                    [12, 'The user´s name was incorrect', 'Form/Document related'],
                    [13, 'The user´s first surname was incorrect', 'Form/Document related'],
                    [14, 'The user´s second surname was incorrect', 'Form/Document related'],
                    [15, 'The document was expired', 'Form/Document related'],
                    [16, 'False document', 'Fraud'],
                    [17, 'User´s photo unsuccessful', 'Photos'],
                    [18, 'Front side photo unsuccessful', 'Photos'],
                    [19, 'Back side photo unsuccessful', 'Photos'],
                    [20, 'The user was under the legal age', 'Form/Document related'],
                    [21, 'The user couldn´t continue with the process: multiple reasons', 'Others'],
                    [22, 'Unstable connectivity', 'Connectivity'],
                    [23, 'The user was not in condition to continue with the process', 'Others'],
                    [98, 'OTP Validation unsuccessful', 'Automatic'],
                    [99, 'MRZ validation unsuccessful', 'Automatic']
]
    },
    {
        "table_name": "dm_sla_dist",
        "version": "/v1",
        "schema": [
            {"name": "sla_dist_id", "type": "IntegerType", "nullable": True},
            {"name": "sla", "type": "StringType", "nullable": True},
            {"name": "sla_n2", "type": "StringType", "nullable": True}
        ],
        "data": [   [0, 'NA', 'NA'],
                    [1, '< 1 min', '0 - 1 min'],
                    [2, '> 1 min - < 2 min', '1 - 2 min'],
                    [3, '> 2 min - < 3 min', '2 - 3 min'],
                    [4, '> 3 min - < 4 min', '3 - 4 min'],
                    [5, '> 4 min - < 5 min', '4 - 5 min'],
                    [6, '> 5 min - < 10 min', '5 - 10 min'],
                    [7, '> 10 min - < 20 min', '10 - 20 min'],
                    [8, '> 20 min - < 30 min', '20 - 30 min'],
                    [9, '> 30min', '> 30']
]
    },
    {
        "table_name": "dm_status",
        "version": "/v1",
        "schema": [
            {"name": "status_id", "type": "IntegerType", "nullable": True},
            {"name": "status", "type": "StringType", "nullable": True}
        ],
        "data": [   [2, 'KO'],
                    [1, 'OK'],
                    [3, 'NQ']
                ]
    },
    {
        "table_name": "dm_time",
        "version": "/v1",
        "schema": [
            {"name": "hour_id", "type": "IntegerType", "nullable": True},
            {"name": "half_interval", "type": "StringType", "nullable": True},
            {"name": "hour", "type": "StringType", "nullable": True}
        ],
        "data": [   [3, '3 - 4', '03'],
                    [7, '7 - 8', '07'],
                    [11, '11 - 12', '11'],
                    [15, '15 - 16', '15'],
                    [19, '19 - 20', '19'],
                    [23, '23 - 24', '23'],
                    [0, '0 - 1', '00'],
                    [4, '4 - 5', '04'],
                    [8, '8 - 9', '08'],
                    [12, '12 - 13', '12'],
                    [16, '16 - 17', '16'],
                    [20, '20 - 21', '20'],
                    [1, '1 - 2', '01'],
                    [5, '5 - 6', '05'],
                    [9, '9 - 10', '09'],
                    [13, '13 - 14', '13'],
                    [17, '17 - 18', '17'],
                    [21, '21 - 22', '21'],
                    [2, '2 - 3', '02'],
                    [6, '6 - 7', '06'],
                    [10, '10 - 11', '10'],
                    [14, '14 - 15', '14'],
                    [18, '18 - 19', '18'],
                    [22, '22 - 23', '22']
            ]
    },
    {
        "table_name": "dm_link_status",
        "version": "/v1",
        "schema": [
            {"name": "link_status_id", "type": "IntegerType", "nullable": True},
            {"name": "link_status", "type": "StringType", "nullable": True}
        ],
            "data": [
                [0, 'Unknown'],
                [1, 'OK'],
                [2, 'KO'],
                [3, 'NQ Atte.'],
                [4, 'Aban.'],
                [5, 'Precall'],
                [6, 'Not Used'],
                [7, 'Unknown']
                ]
    }
]


