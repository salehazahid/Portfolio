from .transformations.raw import VideoIdRawTransformation as raw
from .transformations.curated import VideoIdCuratedTransformation as curated
from .config.etl_config import load_config

job, spark, connections, bucket_in, bucket_out, partitions, env = load_config(local=True)

def run_pipeline(**kwargs):
    """
    Run the ETL (Extract, Transform, Load) pipeline.

    This function runs the RAW and CURATED ETL processes in sequence.
    The RAW process extracts data from the source, transforms it, and loads it into the RAW layer of the data lake.
    The CURATED process extracts data from the RAW layer, transforms it, and loads it into the CURATED layer of the data lake.

    :param spark: Spark session object.
    :param bucket_in: S3 bucket where the input data is stored.
    :param bucket_out: S3 bucket where the output data will be stored.
    :param partitions: Number of partitions to use when writing data.
    :param connections: Dictionary of database connections.
    :param env: Environment ('dev', 'prod', etc.).
    :param etl_type: Type of ETL process to run ('raw', 'curated', or 'both'). Default is 'both'.

    """

    # RUN RAW ETL PROCESS
    """
    Extract data from the source, transform it, and load it into the RAW layer of the data lake.
    """
    days = kwargs.get("days", None)
    hour = kwargs.get("hour", None)
    minutes = kwargs.get("minutes", None)
    dimensions = kwargs.get("dimensions", False)
    etl_type = kwargs.get("etl_type", "both")
    if etl_type in ["raw", "both"]:

        # Add ignoreMissingFiles option when reading raw data from S3
        df = spark.read.option("ignoreMissingFiles", "true") \
                    .option("ignoreCorruptFiles", "true") \
                    .parquet(f"s3a://{bucket_in}/tc/va/videoidentifications/")
        
        result = raw.run_pipeline(spark=spark, 
                            df=df,
                            bucket=bucket_in,
                            partitions = partitions ,
                            connections = connections,
                            days=days,
                            hour=hour,
                            minutes=minutes,
                            dimensions=dimensions
                            )
 
    # RUN CURATED ETL PROCESS
    """
    Extract data from the RAW layer, transform it, and load it into the CURATED layer of the data lake.
    """
    if etl_type in ["curated", "both"]:
        
        curated.run_pipeline(spark=spark, 
                            bucket_in=bucket_in,
                            bucket_out=bucket_out,
                            partitions=partitions,
                            connections=connections,
                            date_event=result,
                            dimensions=dimensions)

    job.commit()
