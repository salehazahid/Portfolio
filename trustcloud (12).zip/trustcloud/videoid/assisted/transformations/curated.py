
from pyspark.sql.functions import split, upper, to_date, col, when, lag,lead,sum, first, date_trunc,row_number, regexp_replace, unix_timestamp, date_format, concat_ws,from_utc_timestamp, year, month, dayofmonth,from_json, col, to_timestamp, round as spark_round,lpad, hour , minute, concat, lit
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, LongType, IntegerType, BooleanType
from datalake_transformation import write_aws, select_cols
from pyspark.sql.functions import current_timestamp, date_format, lit
from datalake_transformation import read_datalake


class VideoIdCuratedTransformation():
    
    @staticmethod
    def __get_calls_metrics(telemetry, calls):
        
        call = calls.select(col("Id").alias("LinkId"), "VerificationStatus", "VideoDuration", col("DateVideoCreated").alias("DateTimeVideoCreated"), to_date("DateVideoCreated").alias("DateVideoCreated"))
        # Convierte la columna EventDate a tipo de dato timestamp
        
        Load_Queue_waiting_page = ["Load Queue waiting page", "Load client page"]
        
        data = telemetry

            
        data = data.join(call.alias("C"), call.LinkId == telemetry.VideoId, how="left").drop("LinkId")

        # Ordena los datos por VideoId y EventDate
        data = data.orderBy("EventDate", "VideoId")

        # Crea una ventana de partición por VideoId y ordena por EventDate
        window_spec = Window.partitionBy("VideoId").orderBy("EventDate")


        # Agrega columnas para calcular el tiempo del evento anterior y el tiempo entre eventos
        data = data.withColumn("tiempo_del_evento_anterior", lag("EventDate").over(window_spec))
        data = data.withColumn("tiempo_del_evento_siguiente", lead("EventDate").over(window_spec))
        data = data.withColumn("DateKey", to_date("EventDate"))
        data = data.withColumn("tiempo_entre_eventos", col("EventDate").cast("long") - col("tiempo_del_evento_anterior").cast("long"))

        # Agrega columnas para el evento anterior y el evento siguiente
        data = data.withColumn("evento_anterior", lag("EventTitle").over(window_spec))
        data = data.withColumn("evento_siguiente", lead("EventTitle").over(window_spec))

        # Identifica los eventos con EventType "CALLBACK"
        data = data.withColumn("is_callback", when(col("EventType") == "CALLBACK", 1).otherwise(0))

        # Crea una columna acumulativa para contar los eventos "CALLBACK" hasta el momento
        data = data.withColumn("callback_count", sum("is_callback").over(window_spec))

        # Crea una nueva columna 'after_callback' con un 1 si hay al menos un evento "CALLBACK" antes del evento actual, de lo contrario coloca un 0
        data = data.withColumn("after_callback",
                            when((col("callback_count") >= 1), 1)
                            .when(col("VerificationStatus").isin("OK", "KO") & (col("DateKey") > col("DateVideoCreated")), 1)
                            .otherwise(0))


        # Calcula el ASA cuando la columna "new_call" es igual a 1 y el "evento_anterior" es "Call answered by agent"
        asa_condition_1 = (col("EventTitle") == "Call answered by agent") & (col("evento_anterior").isin(Load_Queue_waiting_page))
        asa_condition_2 = (col("EventTitle") == "Call answered by agent") & (lag("EventTitle", 2).over(window_spec).isin(Load_Queue_waiting_page)) & (lag("EventTitle", 3).over(window_spec).isNull())
        asa_condition_3 = (col("EventTitle") == "Call answered by agent") & (lag("EventTitle", 1).over(window_spec) == "Session started on client") & (lag("EventTitle", 2).over(window_spec) == "Session started on client") & (lag("EventTitle", 3).over(window_spec).isin(Load_Queue_waiting_page))
        asa_condition_4 = (col("EventTitle") == "Call answered by agent") & (lag("EventTitle", 1).over(window_spec) == "Session started on client") &  (lag("EventTitle", 2).over(window_spec).isin(Load_Queue_waiting_page))
        data = data.withColumn("ASA", when(asa_condition_1, col("tiempo_entre_eventos"))
                            .when(asa_condition_2, col("tiempo_entre_eventos"))
                            .when(asa_condition_3, col("tiempo_entre_eventos"))
                            .when(asa_condition_4, col("tiempo_entre_eventos"))
                            .otherwise(None))
        data = data.withColumn("attended", when(col("ASA") >0 , 1).otherwise(0))
        data = data.withColumn("system_load_time",
                            when(
                                (col("EventTitle") == "Stream created on client") &(col("EventType") == "Client")
                                ,
                                col("tiempo_entre_eventos")
                            ).otherwise(None))


        data = data.withColumn("incoming_call",
                    when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_siguiente") == "Call answered by agent") & (lead(col("ASA"), 1).over(window_spec) > 0), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_siguiente") == "Session started on client") & ((lead(col("ASA"), 3).over(window_spec) > 0) | (lead(col("ASA"), 2).over(window_spec) > 0)), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_anterior") == "Queue page abandoned by client") & (lag("tiempo_entre_eventos", 1).over(window_spec) >= 60), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_anterior") == "Session started on client") & (lag("tiempo_entre_eventos", 1).over(window_spec) >= 60), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_anterior").isNotNull()) & (col("evento_siguiente").isNotNull()), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_siguiente").isNotNull()), 1)
                    .otherwise(when((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("tiempo_entre_eventos") >= 5) & (~col("evento_anterior").isin(["Call answered by agent", "Agent Live Call Page Loaded", "Connectivity Error", "Call joined by agent", "Call answered by agent", "Page Abandoned by Client", "Load Queue waiting page", "Load client page", "Connection Destroyed on Client"])), 1)
                    .otherwise(0))))))))



        # Identifica el abandono y las nuevas llamadas basado en tus criterios
        data = data.withColumn("abandon_reason_stg", 
            when((col("EventTitle") == "Queue page abandoned by client") & (col("tiempo_entre_eventos") >= 60), "Abandoned")
            .when((col("EventTitle") == "Call page abandoned by client") & (col("tiempo_entre_eventos") >= 60), "Abandoned - Call Page")
            .when((col("EventTitle") == "Connectivity Error") & (col("evento_anterior").isin(Load_Queue_waiting_page))  & (col("tiempo_entre_eventos") >= 60) & (col("evento_siguiente").isNull()) , "Precall Conectivity Error")
            .when((col("EventTitle")  == "Connectivity Error") & (col("evento_siguiente").isin(Load_Queue_waiting_page)) & (col("incoming_call") > 0 ) ,"Precall Conectivity Error")
            .when((col("EventTitle")  == "Connectivity Error") & (col("evento_anterior").isin(Load_Queue_waiting_page)) & (col("tiempo_entre_eventos") >= 60) ,"Precall Conectivity Error")
            .otherwise(None))


        # Identifica el abandono y las nuevas llamadas basado en tus criterios
        data = data.withColumn("abandoned",
        when(
            (
                (col("abandon_reason_stg").isNotNull()) &
                (col("VerificationStatus").isNotNull()) &
                ((col("DateKey") <= col("DateVideoCreated")) | (col("DateVideoCreated").isNull()))
            ) | (
                (col("EventTitle").isin(Load_Queue_waiting_page)) &
                (col("evento_siguiente").isin(Load_Queue_waiting_page)) &
                (lead(col("tiempo_entre_eventos"), 1).over(window_spec) >= 5) &
                (col("incoming_call") > 0) &
                (lead(col("ASA"), 1).over(window_spec).isNull())
            ),
            1
        ).otherwise(0)
        )

        data = data.withColumn("abandon_reason", when(col("abandoned")> 0, col("abandon_reason_stg")).otherwise(None)).drop("abandon_reason_stg")
        data = data.withColumn("Precall", when(col("EventType") == 'Precall', 1).otherwise(0))


        data = data.withColumn("not_considered",
            when(
                ((col("incoming_call") == 1) &  (col("evento_siguiente") == "Video recording avalaible and uploaded")) |
                ((col("incoming_call") == 1) &  (col("Abandoned") == 1)) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_siguiente").isNull())) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_siguiente") == 'Connectivity Error')) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (lead(col("abandon_reason"), 1).over(window_spec).isin(["Precall Conectivity Error", "Abandoned <60s", "Abandoned - Call Page"]))) |
                (col("abandon_reason").isin(["Precall Conectivity Error", "Abandoned <60s", "Abandoned - Call Page"])) |
                (col("after_callback") == 1) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("incoming_call") == 1) & (col("evento_siguiente") == "Queue page abandoned by client") & (lead(col("tiempo_entre_eventos"), 1).over(window_spec) < 60 )) |
                ((col("EventTitle") == "Queue page abandoned by client") & (lag(col("EventTitle"), 1).over(window_spec) == "Connectivity Error") & (col("abandoned") == 1)) |
                ((col("EventTitle") == "Queue page abandoned by client") & (lag(col("EventTitle"), 1).over(window_spec) == "Queue page abandoned by client") & (col("abandoned") == 1)) |
                ((col("evento_anterior").isNull()) & (col("evento_siguiente").isNull())) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) &
                    (lead(col("EventTitle"), 1).over(window_spec) == "Queue page abandoned by client") &
                    (lead(col("EventTitle"), 2).over(window_spec) == "Queue page abandoned by client") &
                    (col("incoming_call") == 1)) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_anterior") == "Out page unloaded")  & (lag(col("tiempo_entre_eventos"), 1).over(window_spec) < 60 ) ) |
                #((col("EventTitle") == "Load client page") & (col("evento_anterior") == "Queue page abandoned by client")  & (lag(col("tiempo_entre_eventos"), 1).over(window_spec) < 60 ) ) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & (col("evento_anterior") == "Call page abandoned by client")  & (lag(col("tiempo_entre_eventos"), 1).over(window_spec) < 60 ) ) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Session started on client")  | (col("evento_siguiente") == "Session started on client") )) | 
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_siguiente").isin(Load_Queue_waiting_page)))) | 
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Agent Live Call Page Loaded")) ) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Connection Destroyed on Client")) ) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Agent hung the call")) ) |
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Qualification Requested")  | (col("evento_siguiente") == "Qualification Requested") ) ) | 
                ((col("EventTitle").isin(Load_Queue_waiting_page)) & ((col("evento_anterior") == "Qualification completed") ) | (col("evento_siguiente") == "Qualification completed") ) | 
                ((col("EventTitle") == "Call answered by agent") & (col("EventType") == "Client") ) |
                ((col("EventTitle") == "Call answered by agent") & (col("evento_anterior") == "Call answered by agent") & (col("incoming_call") == 1)) 
            
                , 1).otherwise(0))

        data = data.withColumn("EventData",
                                    regexp_replace(col("EventData"), r"[\\/]", "")
                                    )
        data = data.drop("last_event",
        'VideoDuration',
        'DateTimeVideoCreated',
        'DateVideoCreated',
        'tiempo_del_evento_anterior',
        'tiempo_del_evento_siguiente',
        'evento_anterior',
        'evento_siguiente',)
        

        return data
    
    @staticmethod
    def transfom_consumes(telemetry):

        data = telemetry.filter("EventType == 'CALLBACK'").distinct().cache()
        data = data.withColumn("Event_DateTime_CEST", from_utc_timestamp(col("EventDate"), "Europe/Madrid"))
        data = data.withColumnRenamed("Id", "TelemetryId")
            # Añadir columna con la fecha en la zona horaria de Madrid
        data = data.withColumn("Event_Date_CEST", to_date(col("Event_DateTime_CEST")))
        
        data = data.withColumn("DateKey_CEST", concat_ws("", 
                                                year(col("Event_Date_CEST")), 
                                                lpad(month(col("Event_Date_CEST")), 2, '0'), 
                                                lpad(dayofmonth(col("Event_Date_CEST")), 2, '0')))

        # Extraer la hora y guardarla en una nueva columna 'Event_Hour_CEST'
        data = data.withColumn("Event_Hour_CEST", hour(col("Event_DateTime_CEST")))

        # Calcular el rango de cada media hora y guardarlo en una nueva columna 'Half_Hour_Range_CEST'
        data = data.withColumn(
            "Half_Hour_Range_CEST",
            when(minute(col("Event_DateTime_CEST")) < 30,
                concat_ws("-", 
                        concat(col("Event_Hour_CEST"), lit(":00")), 
                        concat(col("Event_Hour_CEST"), lit(":30"))))
            .otherwise(
                concat_ws("-", 
                        concat(col("Event_Hour_CEST"), lit(":30")), 
                        concat(when(col("Event_Hour_CEST") < 23, (col("Event_Hour_CEST") + 1)).otherwise(0), lit(":00")))
            )
        )

        # Definir el esquema del JSON en la columna 'json_column'
        schema = StructType([
            StructField("_id", StringType(), True),
            StructField("status", StringType(), True),
            StructField("name", StringType(), True),
            StructField("reason", StringType(), True),
            StructField("sessionId", StringType(), True),
            StructField("projectId", IntegerType(), True),
            StructField("createdAt", LongType(), True),
            StructField("size", LongType(), True),
            StructField("duration", IntegerType(), True),
            StructField("outputMode", StringType(), True),
            StructField("hasAudio", BooleanType(), True),
            StructField("hasVideo", BooleanType(), True),
            StructField("certificate", StringType(), True),
            StructField("sha256sum", StringType(), True),
            StructField("password", StringType(), True),
            StructField("updatedAt", LongType(), True),
            StructField("width", IntegerType(), True),
            StructField("height", IntegerType(), True),
            StructField("resolution", StringType(), True),
            StructField("partnerId", IntegerType(), True),
            StructField("_event", StringType(), True)
        ])

        # Convertir la columna JSON en una columna de tipo StructType
        data = data.withColumn("json_struct", from_json(col("EventData"), schema))

        columns_to_drop = ["json_struct", "EventData",  "_id"]
        data = data.select("*", "json_struct.*").drop(*columns_to_drop)

        for column_name in data.columns:
            new_column_name = column_name[0].upper() + column_name[1:]
            data = data.withColumnRenamed(column_name, new_column_name)

        # Convertir las columnas unix timestamp a datetime
        data = data.withColumn("CreatedAt", to_timestamp(col("CreatedAt") / 1000)) \
            .withColumn("UpdatedAt", to_timestamp(col("UpdatedAt") / 1000))

        # Convertir el tamaño del video de kilobytes a megabytes
        data = data.withColumn("Size_MB", spark_round(col("Size") / (1024 * 1024), 2))
        
        column_mapping = {
                            "TelemetryId": "Telemetry_Id",
                            "VideoId": "Link_id",
                            "VerificationStatus": "Verification_Status",
                            "DateKey": "Event_Date",
                            "Event_DateTime_CEST": "Event_DateTime_CEST",
                            "Event_Date_CEST": "Event_Date_CEST",
                            "DateKey_CEST": "DateKey_CEST",
                            "Event_Hour_CEST": "Event_Hour_CEST",
                            "Half_Hour_Range_CEST": "Half_Hour_Range_CEST",
                            "Status": "Status",
                            "Name": "Name",
                            "Reason": "Reason",
                            "SessionId": "Session_Id",
                            "ProjectId": "Project_Id",
                            "CreatedAt": "Created_At",
                            "Size": "Size",
                            "Duration": "Duration",
                            "OutputMode": "Output_Mode",
                            "HasAudio": "Has_Audio",
                            "HasVideo": "Has_Video",
                            "Certificate": "Certificate",
                            "Sha256sum": "Sha256sum",
                            "UpdatedAt": "Updated_At",
                            "Width": "Width",
                            "Height": "Height",
                            "Resolution": "Resolution",
                            "PartnerId": "Partner_Id",
                            "_event": "Event",
                            "Size_MB": "Size_MB",
                            "Appclient": "appclient",
                            "Day" :"day"	,	
                            "Hour"	:"hour"	,
                            "Year":"year"	,
                            "Month": "month"	

                        }

        data = select_cols(data,column_mapping )
                
        
        return data
    
    @staticmethod
    def __transform_telemetry(telemetry):


        # Filtra las filas para cada indicador
        telemetry_filter = telemetry.select(
            'VideoId',
            'EventDate',
            'EventStatus',
            'EventTitle',
            'EventType',
            'Precall',
            'incoming_call',
            'VerificationStatus',
            'ASA',
            'attended',
            'abandoned',
            'abandon_reason',
            'after_callback',
            'DateKey',
            'not_considered',
            'year',
            'month',
            'day',
            'hour',
            'appclient'
        ).filter(to_date(col("EventDate"))>= "2023-01-01").cache()
        asa_rows = telemetry_filter.filter(col("ASA")> 0 ).select('VideoId',"EventDate", "DateKey",'not_considered', 'year','month','day','hour', 'ASA' ,'abandon_reason', 'after_callback','appclient', 'VerificationStatus', 'Precall' )
        attended_rows = telemetry_filter.filter(col("attended") == 1).select('VideoId',"EventDate", "DateKey",'not_considered', 'year','month','day','hour', 'attended','abandon_reason', 'after_callback' ,'appclient', 'VerificationStatus', 'Precall' )
        abandoned_rows = telemetry_filter.filter(col("abandoned") == 1).select('VideoId',"EventDate", "DateKey",'not_considered', 'year','month','day','hour', 'abandoned' ,'abandon_reason', 'after_callback','appclient' , 'VerificationStatus', 'Precall')
        incoming_call_rows = telemetry_filter.filter(col("incoming_call") == 1).select('VideoId',"EventDate", "DateKey",'not_considered', 'year','month','day','hour','incoming_call','abandon_reason', 'after_callback','appclient' , 'VerificationStatus', 'Precall' )
        precall = telemetry_filter.filter(col("Precall") == 1).select('VideoId',"EventDate", "DateKey",'not_considered', 'year','month','day','hour','incoming_call','abandon_reason', 'after_callback','appclient' , 'VerificationStatus', 'Precall' )
        # Unir todos los indicadores en un solo DataFrame
        indicator_rows_union = asa_rows.unionByName(attended_rows, allowMissingColumns= True) \
                                        .unionByName(abandoned_rows, allowMissingColumns= True)  \
                                        .unionByName(incoming_call_rows, allowMissingColumns= True)  
                                        
                                        
        # Truncar 'EventDate' a la hora más cercana
        indicator_rows = indicator_rows_union.withColumn("Event_Date_Hour", date_trunc("hour", col("EventDate")))

        # Agrupa por 'VideoId' y 'event_date_hour' y realiza agregaciones para cada indicador, incluyendo la recopilación de todos los 'EventDate' en una lista
        indicator_rows = indicator_rows.groupBy("VideoId","Event_Date_Hour", "DateKey", 'year','month','day','hour','appclient', 'not_considered', 'VerificationStatus') \
            .agg(
                sum("ASA").alias("average_speed_of_answer"),
                sum("incoming_call").alias("incoming_call"),
                sum("attended").alias("attended"),
                sum("abandoned").alias("abandoned"),
                first("after_callback").alias("after_callback"),
                first("Precall").alias("Precall")
                #concat_ws(",", collect_list("abandon_reason")).alias("abandon_reason_list")

            )
            
            
        indicator_rows = indicator_rows.fillna(0, subset=["incoming_call","attended", "abandoned", "average_speed_of_answer", "after_callback", "Precall" ])

        indicator_rows = indicator_rows.withColumn('Unknow', col("incoming_call") - ((col("attended")) + (col("abandoned"))))


        indicator_rows = indicator_rows.withColumn("incoming_call_rev",
                                                when(col("Unknow") < 0, col("incoming_call") - col("Unknow")).when(col("Unknow") > 0, col("incoming_call") - col("Unknow")).otherwise(col("incoming_call")))
        indicator_rows = indicator_rows.withColumn(
            "abandoned_rev",
            when(
                # Condición: si la suma de las columnas "attended" y "abandoned" no es igual a la columna "incoming_call_rev"
                (col("attended") + col("abandoned") != col("incoming_call_rev")),
                # Si la condición se cumple: "abandoned_rev" = "abandoned" - "Unknow_raw"
                col("abandoned") - col("Unknow")
            ).otherwise(
                # Si la condición no se cumple: "abandoned_rev" = "abandoned"
                col("abandoned")
            )
        )


        indicator_rows = indicator_rows.withColumn("Unknow_Rev",
                                                    when(col("Unknow") < 0, 0).otherwise(col("Unknow")))


        indicator_rows = indicator_rows.withColumn("Link_Status_Id",
                                            when(col('VerificationStatus')== 'OK', 1)
                                        .when((col('VerificationStatus') == 'KO'), lit(2))
                                        .when((col('VerificationStatus') == 'NQ') & (col("Attended") > 0), lit(3))
                                        .when((col('VerificationStatus') == 'NQ') & (col("Abandoned") > 0) & (col("Attended") == 0) & (col("Precall") == 0), lit(4))
                                        .when((col('VerificationStatus') == 'NQ') & (col("Abandoned") >  0) & (col("Attended") == 0)  & (col("Precall") == 1), lit(5))
                                        .otherwise(lit(6)))

        indicator_rows = indicator_rows.withColumn("Verification_Status_Id",
                                    when(col('VerificationStatus')== 'OK', 1)
                                    .when((col('VerificationStatus') == 'KO'), lit(2))
                                    .when((col('VerificationStatus') == 'NQ'), lit(3))
                                    .otherwise(lit(0)))

        indicator_rows = indicator_rows.withColumn("Segment_SLA_Id",
                                                    when((col("average_speed_of_answer") > 0) & (col("average_speed_of_answer") <= 60), 1)
                                                    .when((col("average_speed_of_answer") > 60) & (col("average_speed_of_answer") <= 120), 2)
                                                    .when((col("average_speed_of_answer") > 120) & (col("average_speed_of_answer") <= 180), 3)
                                                    .when((col("average_speed_of_answer") > 180) & (col("average_speed_of_answer") <= 240), 4)
                                                    .when((col("average_speed_of_answer") > 240) & (col("average_speed_of_answer") <= 300), 5)
                                                    .when((col("average_speed_of_answer") > 300) & (col("average_speed_of_answer") <= 600), 6)
                                                    .when((col("average_speed_of_answer") > 600) & (col("average_speed_of_answer") <= 1200), 7)
                                                    .when((col("average_speed_of_answer") > 1200) & (col("average_speed_of_answer") <= 1800), 8)
                                                    .when(col("average_speed_of_answer") > 1800, 9)
                                                    .otherwise(0)
                                                )



        indicator_rows = indicator_rows.filter(col('incoming_call_rev') > 0)



        precall = precall.withColumn("Event_Date_Hour", date_trunc("hour", col("EventDate"))).select("VideoId","Event_Date_Hour", "DateKey", 'year','month','day','hour','appclient', 'not_considered', 'VerificationStatus') \
                                                                                                    .withColumn("Link_Status_Id",lit(5)) \
                                                                                                    .withColumn("Verification_Status_Id", lit(3)) \
                                                                                                    .withColumn("Segment_SLA_Id",lit(0)) 
                                                                                                    
        indicator_rows = indicator_rows.unionByName(precall, allowMissingColumns= True)  


            

        # Añadir columna con la hora en la zona horaria de Madrid
        indicator_rows = indicator_rows.withColumn("Event_DateTime_Hour_CEST", from_utc_timestamp(col("Event_Date_Hour"), "Europe/Madrid"))

        # Añadir columna con la fecha en la zona horaria de Madrid
        indicator_rows = indicator_rows.withColumn("Event_Date_CEST", to_date(col("Event_DateTime_Hour_CEST")))

        indicator_rows = indicator_rows.withColumn("DateKey_CEST", concat_ws("", 
                                                    year(col("Event_Date_CEST")), 
                                                    lpad(month(col("Event_Date_CEST")), 2, '0'), 
                                                    lpad(dayofmonth(col("Event_Date_CEST")), 2, '0')))


        # Extraer la hora y guardarla en una nueva columna 'Event_Hour_CEST'
        indicator_rows = indicator_rows.withColumn("Event_Hour_CEST", hour(col("Event_DateTime_Hour_CEST")))


        # Crear una ventana particionada por 'VideoId' y ordenada por 'Event_DateTime_Hour_CEST' en orden descendente
        window_spec = Window.partitionBy("VideoId").orderBy(col("Event_DateTime_Hour_CEST").desc())

        # Agregar una columna con el número de fila dentro de cada partición 'VideoId'
        indicator_rows = indicator_rows.withColumn("row_num", row_number().over(window_spec))

        # Crear una columna 'is_most_recent' que tenga un 1 si la fila es la más reciente y 0 en caso contrario
        indicator_rows = indicator_rows.withColumn("Lasted", when(col("row_num") == 1, 1).otherwise(0))

        # Opcionalmente, eliminar la columna 'row_num' si no es necesaria
        indicator_rows = indicator_rows.drop("row_num")

        indicator_rows = indicator_rows.select(
            col('VideoId').alias("Link_Id"),
            col("Event_Date_Hour").alias("Event_Date_Hour"),
            "Event_DateTime_Hour_CEST",
            "Event_Date_CEST",
            col("DateKey_CEST").cast('int').alias("DateKey_CEST"),
            col("Event_Hour_CEST").cast('int').alias("Event_Hour_CEST"),
            col('incoming_call').cast('int').alias("Incoming_Call"),
            col('incoming_call_rev').cast('int').alias("Incoming_Call_Rev"),
            col('attended').cast('int').alias("Attended"),
            col('abandoned').cast('int').alias("Abandoned"),
            col('abandoned_rev').cast('int').alias("Abandoned_Rev"),
            col('Unknow').cast('int').alias("Unknow"),
            col('Unknow_Rev').cast('int').alias("Unknow_Rev"),
            col('Segment_SLA_Id').cast('int').alias("Segment_SLA_Id"),
            col('Precall').cast('int').alias("Pre_Call"),
            col('average_speed_of_answer').cast('int').alias("Average_Speed_Of_Answer"),
            col('not_considered').cast('int').alias("Not_Considered"),
            col('after_callback').cast('int').alias("After_Callback"),
            col('Link_Status_Id').cast('int').alias("Link_Status_Id"),
            col('Verification_Status_Id').cast('int').alias("Verification_Status_Id"),
            col("Lasted").cast('int').alias("Lasted"),
            'year', 'month', 'day', 'hour', 'appclient'
        )
        
        window_spec = Window.partitionBy("Link_Id").orderBy(col("Event_DateTime_Hour_CEST").desc())

        indicator_rows = indicator_rows.withColumn("VideoId_Row", row_number().over(window_spec))

        indicator_rows = indicator_rows.withColumn("ActivityDate",current_timestamp())
        indicator_rows = indicator_rows.withColumn("ActivityDate",current_timestamp())


        return indicator_rows
    
    @staticmethod
    def __transform_calls(calls, telemetry):  # Transformación de llamadas VideoID.
        
        telemetry = telemetry.filter("Lasted == 1").select("Link_Id", "Link_Status_Id").cache()
        
            # Añadir columna con la hora en la zona horaria de Madrid
        df_calls = calls.withColumn("Date_Video_Created_CEST", from_utc_timestamp(col("DateVideoCreated"), "Europe/Madrid"))

        # Añadir columna con la fecha en la zona horaria de Madrid
        df_calls = df_calls.withColumn("Date_Video_CEST", to_date(col("Date_Video_Created_CEST")))
        
        df_calls = df_calls.withColumn("Date_Video_Key_CEST", concat_ws("", 
                                                year(col("Date_Video_CEST")), 
                                                lpad(month(col("Date_Video_CEST")), 2, '0'), 
                                                lpad(dayofmonth(col("Date_Video_CEST")), 2, '0')))
        
        
                    # Añadir columna con la hora en la zona horaria de Madrid
        df_calls = df_calls.withColumn("Date_Link_Created_CEST", from_utc_timestamp(col("DateCreated"), "Europe/Madrid"))

        # Añadir columna con la fecha en la zona horaria de Madrid
        df_calls = df_calls.withColumn("Date_Link_CEST", to_date(col("Date_Link_Created_CEST")))
        
        df_calls = df_calls.withColumn("Date_Link_Key_CEST", concat_ws("", 
                                                year(col("Date_Link_CEST")), 
                                                lpad(month(col("Date_Link_CEST")), 2, '0'), 
                                                lpad(dayofmonth(col("Date_Link_CEST")), 2, '0')))
                
        # Extraer la hora y guardarla en una nueva columna 'Event_Hour_CEST'
        df_calls = df_calls.withColumn("Attended_Hour_CEST_Id", hour(col("Date_Video_Created_CEST")))
                # Extraer la hora y guardarla en una nueva columna 'Event_Hour_CEST'
        df_calls = df_calls.withColumn("Link_Hour_Id", hour(col("DateCreated")))
        

        df_calls = df_calls.select("Id",
                                    "DateCreated",
                                    "Name",
                                    "Surname1",
                                    "Surname2",
                                    "DocType",
                                    "DocNumber",
                                    "ClientBusinessId",
                                    "DocCountry",
                                    "TrustCloudFileId",
                                    "VerificationStatus",
                                    "DateVideoCreated",
                                    "DateVideoEnded",
                                    "VideoDuration",
                                    "Agent",
                                    "Device",
                                    "OS",
                                    "Browser",
                                    "DateCallEnded",
                                    "ServiceCountry",
                                    "LanguageDocument",
                                    "PhoneNumber",
                                    "StatusURL",
                                    "KillerQuestions","Date_Link_Key_CEST","Link_Hour_Id","Date_Video_Created_CEST","Date_Video_Key_CEST","Attended_Hour_CEST_Id", 
                                    "VideoApplicationId",
                                    #"TaxID", #TaxID added here 
                                    "appclient", "year", "month", "day", "hour")
        
        
        df_calls = df_calls.na.fill(value=0)

        #df_calls = df_calls.withColumn("TaxID", lit(None)) #TaxID

        df_calls = df_calls.withColumn('LanguageDocument', upper(col('LanguageDocument'))) \
            .withColumn('ServiceCountry', upper(col('ServiceCountry'))) \
            .withColumn("qc_id", when(col("KillerQuestions") == "", lit(0)).otherwise(split(df_calls['KillerQuestions'], ',').getItem(0).cast('int'))) \
            .withColumn("VerificationStatus_Id",
                        when(df_calls.VerificationStatus == 'OK', lit(1))
                        .when(df_calls.VerificationStatus == 'KO', lit(2))
                        .when(df_calls.VerificationStatus == 'NQ', lit(3))
                        .otherwise(lit(0))) \
            .fillna({"DocType": "NA",
                    "DocNumber": "NA",
                    "LanguageDocument": "NA",
                    "ServiceCountry": "NA",
                    "Browser": "NA",
                    "Name": "NA",
                    "SurName1": "NA",
                    "SurName2": "NA",
                    "OS": "NA",
                    "Agent": "NA",
                    "KillerQuestions": "NA",
                    "DocCountry": "NA",
                    "StatusURL": "NA",
                    "Device": "NA",
                    "qc_id": 0})

        df_calls = df_calls.join(telemetry, df_calls.Id == telemetry.Link_Id, how="left").drop("Link_Id")
        
        df_calls = df_calls.withColumn("Link_Status_Id",
                                        when(col('VerificationStatus_Id') == 1, lit(1))
                                        .when(col('VerificationStatus_Id') == 2, lit(2))
                                        .otherwise(col("Link_Status_Id")))
        
        df_calls = df_calls.withColumn("Link_Status_Id",
                                    when(col('Link_Status_Id').isNull(), lit(6))
                                    .otherwise(col("Link_Status_Id")))
        
        
        df_calls = df_calls.select(
            col('Id').alias('Link_Id'),
            col("DateCreated").alias('Date_Link_Created'),
            col("Date_Link_Key_CEST").cast('int').alias('Date_Link_Key_CEST'),
            col("Link_Hour_Id").cast('int').alias('Link_Hour_Id'),
            col("Name").alias('Name'),
            col("Surname1").alias('First_Surname'),
            col("Surname2").alias('Second_Surname'),
            col("DocType").alias('Doc_Type'),
            col("DocNumber").alias('Doc_Number'),
            col("TrustCloudFileId").alias('TrustCloud_File_Id'),
            col("VerificationStatus").alias('Verification_Status'),
            col("VerificationStatus_Id").alias('Verification_Status_Id'),
            col("DateVideoCreated").alias('Date_Video_Created'),
            col("Date_Video_Created_CEST").alias('Date_Video_Created_CEST'),
            col("Date_Video_Key_CEST").cast('int').alias('Date_Video_Key_CEST'),
            col("Attended_Hour_CEST_Id").cast('int').alias('Attended_Hour_CEST_Id'),
            col("DateVideoEnded").alias('Date_Video_Ended'),
            col("DateCallEnded").alias('Date_Call_Ended'),
            col("VideoDuration").cast('int').alias("Video_Duration"),
            "Agent",
            "Device",
            "OS",
            "Browser",
            col("ServiceCountry").alias('Service_Country'),
            col("LanguageDocument").alias('Language_Document'),
            col("PhoneNumber").alias('Phone_Number'),
            col("ClientBusinessId").alias('Client_Business_Id'),
            col("DocCountry").alias('Doc_Country'),
            col("VideoApplicationId").alias('Video_Application_Id'),
            'Link_Status_Id',
            col('StatusURL').alias('Status_URL'),
            col('KillerQuestions').alias('Question_Codes'),
           #col("TaxID"), #TaxID added here
            'qc_id',
            'appclient', 'year', 'month', 'day')

                                       
        return df_calls

    @staticmethod
    def get_tbl_telemetry(df_telemetry):


        telemetry = df_telemetry.select("Id","VideoId","EventDate","EventTitle","EventStatus","EventType","appclient","ActivityDate","year","month", "day", "hour").withColumn("Key",row_number().over(Window.partitionBy("VideoId").orderBy("EventDate")))
        telemetry_by_customer = telemetry.select("VideoId").groupby("VideoId").count().withColumnRenamed("count", "TelemetryCount").withColumn("LastTelemetryKey", lit(1))
        telemetry_by_customer = telemetry_by_customer.select("VideoId", "TelemetryCount","LastTelemetryKey",concat(telemetry.VideoId, "TelemetryCount")).withColumnRenamed("concat(VideoId, TelemetryCount)", "LastTelemetryCountId")
        telemetry_stg = telemetry.select("Id",
                            "VideoId",
                            "EventDate",
                            "EventTitle",
                            "EventStatus",
                            "EventType",
                            "Key",
                                concat(telemetry.VideoId, "Key"),"appclient","year","month", "day", "hour").withColumnRenamed("concat(VideoId, key)", "LastTelemetryCountId")
        telemetry_complete = telemetry_stg.alias('T').join(telemetry_by_customer, telemetry_stg.LastTelemetryCountId == telemetry_by_customer.LastTelemetryCountId, how="left") \
                            .select(col("T.Id").alias("Event_Id"), 
                            col("T.VideoId").alias("Link_Id"),
                            col("T.EventDate").alias("Event_Date"),
                            col("T.EventTitle").alias("Event_Title"),
                            col("T.EventStatus").alias("Status"),
                            col("T.EventType").alias("Event_Type"),
                            col("Key").alias("Event_Key"),
                            col("LastTelemetryKey").alias("Last_Event_Key"),"appclient","year","month", "day",  "hour").na.fill(value=0)
                            
        return telemetry_complete

    @staticmethod
    def transform(dfs, spark=None):
        """
        Transforms calls and telemetry dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        None. The dfs dictionary is updated in place.
        """
        videoidentifications = dfs.get('videoidentifications')
        telemetry = dfs.get('telemetry')

        if videoidentifications is None or telemetry is None:
            raise ValueError("Both calls and telemetry dataframes must be provided")

        telemetry_metrics = VideoIdCuratedTransformation.__get_calls_metrics(telemetry, videoidentifications)
        dfs['video_consumption'] = VideoIdCuratedTransformation.transfom_consumes(telemetry_metrics)
        dfs['calls'] = VideoIdCuratedTransformation.__transform_telemetry(telemetry_metrics)
        dfs['videoidentifications'] = VideoIdCuratedTransformation.__transform_calls(videoidentifications, dfs['calls'])
        
        return dfs

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            "videoidentifications": {"table": dfs.get('videoidentifications'), "type": "fact", "path": "tc/va/", "version": "/v1", 'merge_conditions': 'source.Link_Id == target.Link_Id'},
            "calls": {"table": dfs.get('calls'), "type": "fact", "path": "tc/va/", "version": "/v1", 'merge_conditions': 'source.Link_Id == target.Link_Id AND source.VideoId_Row == target.VideoId_Row'},
            "consumption_video": {"table": dfs.get('video_consumption'), "type": "fact", "path": "tc/va/", "version": "/v1", 'merge_conditions': 'source.Telemetry_Id == target.Telemetry_Id'},
            "customers": {"table": dfs.get('customers'), "type": "fact", "path": "tc/admin/", "version": "/v1", 'merge_conditions': False},
            "agents": {"table": dfs.get('agents'), "type": "fact", "path": "tc/admin/", "version": "/v1", 'merge_conditions': False},
            "evidences": {"table": dfs.get('evidences'), "type": "fact", "path": "tc/vault/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "dm_asa_segmentation": {"table": dfs.get('dm_asa_segmentation'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_country": {"table": dfs.get('dm_country'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_lang": {"table": dfs.get('dm_lang'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_link_status": {"table": dfs.get('dm_link_status'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_qc": {"table": dfs.get('dm_qc'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_sla_dist": {"table": dfs.get('dm_sla_dist'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_status": {"table": dfs.get('dm_status'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
            "dm_time": {"table": dfs.get('dm_time'), "type": "dm", "path": "tc/va/", "version": "/v1", 'merge_conditions': False},
        }


        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items() if v['table'] is not None}

        return dfs_dict

