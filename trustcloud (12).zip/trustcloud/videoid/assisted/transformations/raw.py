import json
from collections import defaultdict
from functools import reduce

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, current_timestamp, date_format, lit, to_date
from pyspark.sql.types import *

from datalake_cloud_unity.aws.service import AwsManager
from datalake_transformation import read_jdbc, timer, write_aws



def add_parition_columns(df: DataFrame, colum_dateTime, customer_value: str) -> DataFrame:
    """
    Añade las columnas relacionadas con la actividad a un DataFrame de PySpark. y particiones

    Parámetros:
        df (DataFrame): DataFrame original al que se le añadirán las columnas.
        customer_value (str): Valor para la columna 'appclient'.

    Devuelve:
        DataFrame: DataFrame con las columnas adicionales.
    """
    
    df_transformed = (
        df
         
        .withColumn("year", date_format(col(colum_dateTime), "yyyy"))
        .withColumn("month", date_format(col(colum_dateTime), "MM"))
        .withColumn("day", date_format(col(colum_dateTime), "dd"))
        .withColumn("hour", date_format(col(colum_dateTime), "HH"))
        .withColumn("appclient", lit(customer_value))
    )
    
    return df_transformed
    

class VideoIdRawTransformation():

    
       
    @staticmethod
    def get_processing_map():
        """
        Provides a mapping of table names to their respective processing functions 
        and additional metadata for processing within the DataLakeRawLayer.

        Returns:
            dict: A dictionary where keys are table names and values are another dictionary 
                containing processing functions, merge conditions, and paths.
        """
        processing_map = {
            'videoidentifications': {
                'function': lambda df, customer: VideoIdRawTransformation.__get_raw_data(df, customer, "DateCreated"),
                'merge_conditions': 'source.Id == target.Id',
                'path': 'tc/va/',
                "version": "/v1",
                "type": "jdbc"
            },
            'customers': {
                'function': lambda df, customer: VideoIdRawTransformation.__get_raw_customers(df),
                'path': 'tc/admin/',
                'database': 'TrusCloudAdmin',
                "version": "/v1",
                "type": "jdbc"
            },
             'agents': {
                'function': lambda df, customer: VideoIdRawTransformation.__get_raw_agents(df),
                'path': 'tc/admin/',
                'database': 'TrustCloudPortalV2',
                "version": "/v1",
                "type": "jdbc"
            },
            'telemetry': {
                'function': lambda df, customer: VideoIdRawTransformation.__get_raw_data(df, customer, "EventDate"),
                'merge_conditions': 'source.Id == target.Id',
                'path': 'tc/va/',
                "version": "/v1",
                "type": "jdbc"
            },
            'evidences': {
                'function': lambda df, customer: VideoIdRawTransformation.__get_raw_data(df, customer, "DateCreated"),
                'merge_conditions': 'source.Id == target.Id',
                'path': 'tc/vault/',
                "version": "/v1",
                "type": "jdbc"
            }
        }
        return processing_map
    

   
    @staticmethod
    def get_raw_customers(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.
        
        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
        .withColumn("ActivityDate", current_timestamp())  # Crea/modifica la columna 'ActivityDate' con el timestamp actual
        )
    
        return df_transformed
    
    @staticmethod
    def get_raw_agents(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.
        
        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
        .withColumn("ActivityDate", current_timestamp())  # Crea/modifica la columna 'ActivityDate' con el timestamp actual
        )
    
        return df_transformed
    


    