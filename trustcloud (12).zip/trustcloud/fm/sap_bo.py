
from datalake_transformation import read_datalake, write_aws
from pyspark.sql.types import IntegerType, DecimalType
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from .sap_bo_ultis import *
from functools import wraps


class DataLakeRawLayer:
    def __init__(self,sbo):
        self.sbo = sbo

    def get_jdt1(self, jdt1,):
        """
        This represents the Journal Entries table in SAP Business One.

        Attributes:
        
            jdt1 (DataFrame): A DataFrame containing data from the JDT1 table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
        
            dataframe (DataFrame): A DataFrame containing the processed data from the JDT1 table.

        Methods:
        
            __init__(self, jdt1, sbo): Constructs all the necessary attributes for the JDT1 object.

        Notes:
        
            The processed DataFrame contains the following columns:
            - RefDate (datetime): The date of the journal entry.
            - TransId (int): The transaction ID.
            - Account (int): The account number.
            - ShortName (str): The name of the account.
            - Debit (decimal): The debit amount.
            - Credit (decimal): The credit amount.
            - LineMemo (str): The line item memo.
            - OcrCode2 (str): The second cost center.
            - OcrCode3 (str): The third cost center.
            - OcrCode4 (str): The fourth cost center.
            - ProfitCode (str): The profit center.
            - sbo (str): The SAP Business One database.
            - Company_Id (int): The ID of the company.
            - year (str): The year of the journal entry.
            - month (str): The month of the journal entry.
            - Account_Key (int): The account key.
            - Account_IC_Key (str): The account intercompany key.

        """
        jdt1 = JDT1(jdt1, self.sbo )
        return jdt1.dataframe
    
    def get_oact(self,oact):
        """
        Represents the G/L Accounts table (OACT) in SAP Business One.

        Attributes:
            oact (DataFrame): A DataFrame containing data from the OACT table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
            dataframe (DataFrame): A DataFrame containing the processed data from the OACT table.

        Methods:
            __init__(self, oact, sbo): Constructs all the necessary attributes for the OACT object.

        Notes:
            The columns in the DataFrame are as follows:
            - AcctCode: G/L account code.
            - AcctName: G/L account name.
            - Postable: Whether the account is postable or not.
            - DataSource: Source of data for the account.
            - LocManTran: Whether local manual transactions are allowed for the account.
            - LocCurrBal: Whether local currency balances are allowed for the account.
            - FrgnCurrBal: Whether foreign currency balances are allowed for the account.
            - ReconAcc: Reconciliation account for the G/L account.
            - CashAcc: Cash account for the G/L account.
            - PnLacct: Whether the account is a profit and loss account.
            - LiableForTax: Whether the account is liable for tax.
            - Active: Whether the account is active or not.

        """
        oact = OACT(oact, self.sbo )
        return oact.dataframe

    def get_oinv(self, oinv):
        """
        This class represents the A/R Invoice table (OINV) in SAP Business One.

        Attributes:
        
            oinv (DataFrame): A DataFrame containing data from the OINV table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
            
            dataframe (DataFrame): A DataFrame containing the processed data from the OINV table.

        Methods:
           
            __init__(self, oinv, sbo): Constructs all the necessary attributes for the OINV object.

        Notes:
            
            The processed DataFrame contains the following columns:
                - TransId (int): The transaction ID.
                - DocNum (str): The document number.
                - DocEntry (int): The document entry.
                - CardCode (str): The customer code.
                - DocStatus (str): The document status.
                - DocDueDate (datetime): The due date of the document.
                - SlpCode (int): The sales employee code.
                - DocTotal (decimal): The total document amount.
                - VatSum (decimal): The total VAT amount.
                - DocDate (datetime): The document date.
                - TaxDate (datetime): The tax date.
                - CardName (str): The customer name.
                - LicTradNum (str): The customer VAT number.
                - Series (int): The document series.
                - sbo (str): The SAP Business One database.
                - Company_Id (int): The ID of the company.
                - year (str): The year of the invoice.
                - month (str): The month of the invoice.
                - DocEntry_Key (int): The document entry key.

    """
        oinv = OINV(oinv, self.sbo )
        return oinv.dataframe

    def get_inv1(self, inv1):
        """
        Represents the A/R Invoice Detail table (INV1) in SAP Business One.

        Attributes:
        
            inv1 (DataFrame): A DataFrame containing data from the INV1 table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
        
            dataframe (DataFrame): A DataFrame containing the processed data from the INV1 table.

        Methods:
            __init__(self, inv1, sbo): Constructs all the necessary attributes for the INV1 object.

        Notes:
        
            The INV1 table contains the following columns:
                - DocEntry (int): Unique identifier for the invoice document.
                - LineNum (int): Line number of the invoice detail.
                - ItemCode (str): Item code.
                - Dscription (str): Item description.
                - Quantity (float): Quantity of the item.
                - Price (float): Price of the item.
                - DiscPrcnt (float): Discount percentage applied to the item price.
                - LineTotal (float): Total price of the invoice detail line.
                - TaxCode (str): Tax code for the item.
                - WhsCode (str): Warehouse code for the item.
                - OcrCode2 (str): Dimension 1 code.
                - OcrCode3 (str): Dimension 2 code.
                
        """
        inv1 = INV1(inv1, self.sbo )
        return inv1.dataframe
    
    def get_rin1(self, rin1):
        """
        Represents the A/R Invoice Lines table (RIN1) in SAP Business One.

        Attributes:
        
            rin1 (DataFrame): A DataFrame containing data from the RIN1 table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
        
            dataframe (DataFrame): A DataFrame containing the processed data from the RIN1 table.

        Methods:
        
            __init__(self, rin1, sbo): Constructs all the necessary attributes for the RIN1 object.

        Notes:
        
            The columns in the DataFrame are as follows:
            - DocEntry: Document entry.
            - LineNum: Line number.
            - ItemCode: Item code.
            - Dscription: Item description.
            - Quantity: Quantity.
            - Price: Price.
            - DiscPrcnt: Discount percentage.
            - LineTotal: Line total.
            - WhsCode: Warehouse code.
            - ShipDate: Shipment date.

        """
        rin1 = RIN1(rin1, self.sbo)
        return rin1.dataframe

    def get_oocr(self, oocr):
        """
        Represents the Cost Center table (OOCR) in SAP Business One.

        Attributes:
            oocr (DataFrame): A DataFrame containing data from the OOCR table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
            dataframe (DataFrame): A DataFrame containing the processed data from the OOCR table.

        Methods:
            __init__(self, oocr, sbo): Constructs all the necessary attributes for the OOCR object.

        Notes:
            The columns in the DataFrame are as follows:
            - PrcCode: Cost center code.
            - PrcName: Cost center name.
            - DimCode: Dimension code for the cost center.
            - Active: Whether the cost center is active or not.

        """
        oocr = OOCR(oocr, self.sbo)
        return oocr.dataframe
    
    def get_ocrd(self, ocrd):
        """
        Represents the Business Partner Master Data table (OCRD) in SAP Business One.

        Attributes:
        
        ocrd (DataFrame): A DataFrame containing data from the OCRD table.
        sbo (str): A string representing the SAP Business One database.

        Properties:
        
        dataframe (DataFrame): A DataFrame containing the processed data from the OCRD table.

        Methods:
        
        __init__(self, ocrd, sbo): Constructs all the necessary attributes for the OCRD object.

        Notes:
        
        The OCRD table contains the following columns:
            - CardCode (str): Unique identifier for the business partner.
            - CardName (str): Name of the business partner.
            - CardType (str): Type of the business partner (customer or vendor).
            - GroupCode (str): Group code of the business partner.
            - Phone1 (str): Primary phone number of the business partner.
            - E_Mail (str): Email address of the business partner.
            - Balance (float): Current balance of the business partner.
            - Currency (str): Currency code for the business partner.
            - LicTradNum (str): Legal identification number of the business partner.
            - DebitorAccount (str): Account code for the business partner.
            - CreditLimit (float): Credit limit for the business partner.
            
        """ 
        ocrd = OCRD(ocrd, self.sbo)
        return ocrd.dataframe

    def get_nnm1(self, nnm1):
        """
        Represents the Number Series table (NNM1) in SAP Business One.

        Attributes:
        
            nnm1 (DataFrame): A DataFrame containing data from the NNM1 table.
            sbo (str): A string representing the SAP Business One database.

        Properties:
        
            dataframe (DataFrame): A DataFrame containing the processed data from the NNM1 table.

        Methods:
        
            __init__(self, nnm1, sbo): Constructs all the necessary attributes for the NNM1 object.

        Notes:
        
            The NNM1 table contains information about number series in SAP Business One, which are used for document numbering.
            The following columns are included in the table:
                - Series: The number series code.
                - SeriesName: The description of the number series.
                - ObjectCode: The object code to which the number series is assigned.
                - FirstNum: The first number in the number series.
                - LastNum: The last number in the number series.
                - NextNum: The next available number in the number series.
                - Locked: Indicates whether the number series is locked.
                - DataSource: The source of the data in the table.
        """
        nmm1 = NNM1(nnm1, self.sbo)
        return nmm1.dataframe
    
    def get_oslp(self, oslp):
        """
        Represents the Sales Employee table (OSLP) in SAP Business One.

        Attributes:
        
        oslp (DataFrame): A DataFrame containing data from the OSLP table.
        sbo (str): A string representing the SAP Business One database.

        Properties:
        
        dataframe (DataFrame): A DataFrame containing the processed data from the OSLP table.

        Methods:
        
        __init__(self, oslp, sbo): Constructs all the necessary attributes for the OSLP object.

        Notes:
        
        The OSLP table contains information about sales employees in SAP Business One.
        The following columns are included in the table:
        - SlpCode: The sales employee code.
        - SlpName: The name of the sales employee.
        - Memo: A memo field for additional information.
        - DataSource: The source of the data in the table.
        
        """
         
        oslp = OSLP(oslp, self.sbo)
        return oslp.dataframe

    
class DataLakeCuratedLayer:
    """
    A class representing the curated layer of the data lake.

    Attributes:
        None
    """
    def __init__(self):
        pass

    def get_annual_opening_balance(self, jdt1, oact):
        """
        Calculates the annual opening balance.

        Args:
            jdt1 (DataFrame): A DataFrame containing the journal details.
            oact (DataFrame): A DataFrame containing the account details.

        Returns:
            DataFrame: A DataFrame containing the annual opening balance.

        Notes:
            The resulting DataFrame contains the following columns:
                - ``Date``: The date of the annual opening balance.
                - ``Openning``: The calculated opening balance for each year.

        """

        years = jdt1.select("RefDate").withColumn(
        'Year', year(jdt1.RefDate)).select("Year").distinct()
        years = years.rdd.flatMap(lambda x: x).collect()
        year_filter = "2017-01-01"
        op_balance = jdt1.filter(((col("Account") >= "572001") & (col("Account") <= "572020")) | (col("Account") >= "520001") & (col("Account") <= "520050")).filter(col("RefDate") <= year_filter) \
            .join(oact, oact.AcctCode == jdt1.Account, how="left") \
            .groupBy("Account").agg((when(col("Account").like("572%"), sum("Debit")-sum("Credit")).otherwise((max("ValidComm")-(sum("Debit") - sum("Credit"))*-1))).cast(DecimalType(18, 2)).alias('Openning')).withColumn("Date", to_date(lit(year_filter)))
        op_balance = op_balance.groupBy("Date").sum(
            "Openning").withColumnRenamed("sum(Openning)", "Openning")
        for y in years:
            if y != 2017:
                year_filter = str(y)+"-01-01"
                op_bl = jdt1.filter(((col("Account") >= "572001") & (col("Account") <= "572020")) | (col("Account") >= "520001") & (col("Account") <= "520050")).filter(col("RefDate") <= year_filter) \
                    .join(oact, oact.AcctCode == jdt1.Account, how="left") \
                    .groupBy("Account").agg((when(col("Account").like("572%"), sum("Debit")-sum("Credit")).otherwise((max("ValidComm")-(sum("Debit") - sum("Credit"))*-1))).cast(DecimalType(18, 2)).alias('Openning')).withColumn("Date", to_date(lit(year_filter)))
                op_bl = op_bl.groupBy("Date").sum(
                    "Openning").withColumnRenamed("sum(Openning)", "Openning")
                if "op_bl" in locals():
                    op_balance = op_balance.unionByName(op_bl)
        return op_balance
        
    def get_opening_balance(self, cash,op_balance):
        """
        Calculates the opening balance.

        Args:
            cash (DataFrame): A DataFrame containing the cash details.
            op_balance (DataFrame): A DataFrame containing the opening balance.

        Returns:
            DataFrame: A DataFrame containing the opening balance.
        """
                        
        cash_op = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias(
        'Month'), "Cash").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
        cash_op = cash_op.groupBy("Date").sum(
        "Cash").withColumnRenamed("sum(Cash)", "MonthlyCash")
        cash_op = cash_op.select("Date", 'MonthlyCash').alias("C").join(
        op_balance, op_balance.Date == cash_op.Date, how="leftouter")
        cash_op = cash_op.select("C.Date", 'MonthlyCash', "Openning").withColumn("MonOP", when(col("Openning").isNotNull(), col("Openning")+col("MonthlyCash")).otherwise(col("MonthlyCash"))).withColumn("Year", year("C.Date"))
        w1 = Window.partitionBy("Year").orderBy("C.Date").rangeBetween(Window.unboundedPreceding, 0)
        w2 = Window.partitionBy("Year").orderBy("C.Date")
        cash_op = cash_op.withColumn('OpeningBalance', sum('MonOP').over(w1))
        cash_op = cash_op.select("Year", "Date", "OpeningBalance", "Openning",lag('OpeningBalance').over(w2).alias("OB")) \
                        .withColumn('Level1', lit("OPENING BALANCE")) \
                        .withColumn("Cash", when(col("OB").isNull(), col("Openning"))
                        .otherwise(col("OB")))
        
        cash_op = cash_op.select("Date", "Cash", 'Level1')
                
        return cash_op
    
    def get_closing_balance(self, cash,op_balance):
        cash_op = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias(
        'Month'), "Cash").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
        cash_op = cash_op.groupBy("Date").sum(
        "Cash").withColumnRenamed("sum(Cash)", "MonthlyCash")
        cash_op = cash_op.select("Date", 'MonthlyCash').alias("C").join(
        op_balance, op_balance.Date == cash_op.Date, how="leftouter")
        cash_op = cash_op.select("C.Date", 'MonthlyCash', "Openning").withColumn("MonOP", when(col("Openning").isNotNull(), col("Openning")+col("MonthlyCash")).otherwise(col("MonthlyCash"))).withColumn("Year", year("C.Date"))
        w1 = Window.partitionBy("Year").orderBy("C.Date").rangeBetween(Window.unboundedPreceding, 0)
        w2 = Window.partitionBy("Year").orderBy("C.Date")
        cash_op = cash_op.withColumn('Cash', sum('MonOP').over(w1))
        cash_op = cash_op.select( "Date", "Cash") \
                        .withColumn('Level1', lit("CLOSING BALANCE"))
                    
        return cash_op

    def get_cash(self, jdt1, oact, ocrd):
        """
        Returns a DataFrame with the cash transactions and their corresponding accounting information.

        :param jdt1: DataFrame with the Journal Entries.
        :type jdt1: :class:`pyspark.sql.DataFrame`

        :param oact: DataFrame with the Account information.
        :type oact: :class:`pyspark.sql.DataFrame`

        :param ocrd: DataFrame with the Business Partner information.
        :type ocrd: :class:`pyspark.sql.DataFrame`

        :return: DataFrame with cash transactions and their corresponding accounting information.
        :rtype: :class:`pyspark.sql.DataFrame`

        :Columns:
            - ``Date``: Date of the cash transaction.
            - ``Operation``: ID of the transaction.
            - ``AccountId``: ID of the account.
            - ``Account_Name``: Name of the account.
            - ``Account_IC``: ID of the Intercompany account.
            - ``Account_Bank``: ID of the Bank account.
            - ``Level3``: Level 3 of the account.
            - ``Account_Name_IC``: Name of the Intercompany account.
            - ``Cash``: Amount of cash.
            - ``Level1``: Level 1 of the account.
            - ``Level2``: Level 2 of the account.
            - ``Type``: Type of the transaction.
            - ``Comments``: Comments of the transaction.
        """


        jdt1_stg = jdt1.select(
        to_date(col("RefDate")).alias("Date"),
        col("TransId"),
        col("Account").alias("Account"),
        col("ShortName").alias("Account_IC"),
        col("Debit"),
        col("Credit"),
        col("LineMemo").alias("Comentarios")).filter("(ShortName >= 520000 and  ShortName <= 520099) OR (ShortName >= 572000 and  ShortName <= 572099)")



        ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])

        cash = jdt1.alias("cash").join(jdt1_stg, jdt1.TransId == jdt1_stg.TransId, how="leftouter").select("cash.RefDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", jdt1_stg.Account_IC.alias("Account_Bank"))
        cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
        .select("cash.RefDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", "cash.Account_Bank", oact.AcctName, oact.FrgnName)
        cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
        .select("cash.RefDate", "cash.TransId", "cash.Account", "cash.Account_Bank", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
        cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                        .withColumn("Cash", when(col("Account_Bank").isNull(), lit(0)) #Mirar facturas por cobrar
                    .otherwise((col("Debit")-col("Credit"))*-1))\
                        .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
        cash = cash.withColumn("Cash", when((col("ShortName").like("520%")) & (col("Account_Bank").like("572%")) & (col("LineMemo").like("Traspaso%")) & (col("Cash") > 0), col("Cash") *-1)
                                .when((col("ShortName") == col("Account_Bank")) & (col("LineMemo").like("Traspaso%")) & (col("Cash") < 0) , col("Cash") *-1 ).otherwise(col("Cash") ))

        cash = cash.withColumn("Type", when((col("Account_Name_IC").like("cc%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("póliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("Banco%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("Poliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("poliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("banco%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when((col("Account_Name_IC").like("%cta. corriente%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                                .when(col("Account_Name_IC").like("cta. corriente%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("Banco%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("cc%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("Poliza%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("poliza%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("Póliza%"), lit("Banking"))
                                .when(col("Account_Name_IC").like("póliza%"), lit("Banking"))
                            .otherwise(lit("CashFlow"))
                            )

        cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")) 
                            .when((col("Account") == "170000") & (col("Cash") > 0), lit("INCOME"))
                            .when((col("ShortName") == col("Account_Bank")) & (col("LineMemo").like("Traspaso%")) , lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                            .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                            .when(col("ShortName").startswith("C"), lit("Sales"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                            .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                            .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                            .when(col("Account") == "465000", lit("Salaries"))
                            .when(col("Account") == "475100", lit("IRPF"))
                            .when(col("Account").like("4751%"), lit("IRPF"))
                            .when(col("Account") == "475000", lit("IVA"))
                            .when(col("Account").like("572%"), lit("Banking"))
                            .when(col("Account").like("520%"), lit("Banking"))
                            .when(col("Account") == "476000", lit("Social Security"))
                            .when(col("Account") == "662300", lit("Banking"))
                            .when(col("Account") == "629700", lit("Corporate Support Suppliers"))
                            .when(col("Account") == "623910", lit("Corporate Support Suppliers"))
                            .when(col("Account") == "629200", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "621100", lit("Office Rent & Maintenance"))
                            .when(col("Account") == "624000", lit("Travel Suppliers"))
                            .when(col("Account") == "627000", lit("Corporate Support Suppliers"))
                            .when(col("Account") == "623600", lit("Corporate Support Suppliers"))
                            .when(col("Account") == "629100", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "629310", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "629800", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "627400", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "242300", lit("Long term investments"))
                            .when(col("Account") == "260000", lit("Long term investments"))
                            .when(col("Account") == "623800", lit("Recruitment Suppliers"))
                            .when(col("Account") == "628100", lit("Utilities Suppliers"))
                            .when(col("Account") == "628200", lit("Utilities Suppliers"))
                            .when(col("Account") == "626000", lit("Banking"))
                            .when(col("Account") == "629001", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "621300", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "621400", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "631000", lit("Other Taxes"))
                            .when(col("Account") == "629500", lit("Office Service & Equipment Suppliers"))
                            .when(col("Account") == "624001", lit("Credit Cards"))
                            .when(col("Account") == "472900", lit("IVA"))
                            .when(col("Account").like("47200%"), lit("IVA"))
                            .when(col("Account").like("47700%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")

        cash = cash.withColumn("Cash", when((col("Level1") == "EXPENDITURE") & (col("LineMemo").like("Traspaso%")) & (col("Cash") > 0 ), col("Cash") *-1).otherwise(col("Cash") ))
            
        cash = cash.select(
        to_date(col("RefDate")).alias("Date"),
        col("TransId").alias("Operation"),
        col("Account").alias("AccountId"),
        col("Account_Name").alias("Account_Name"),
        col("ShortName").alias("Account_IC"),
        col("Account_Bank"),
        col("FrgnName").alias("Level3"),
        col("Account_Name_IC"),
        col("Cash"),"Level1", "Level2","Type",
        col("LineMemo").alias("Comments")).filter("type == 'CashFlow' and Account_Bank <> '520000'").dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"]).filter("cash <> 0")

        return cash

    def get_customer_preliminary(self, jdt1, oact,ocrd):
        """
        Returns a DataFrame with preliminary customer cash data.

        Parameters:
            - jdt1 (DataFrame): DataFrame with cash data
            - oact (DataFrame): DataFrame with account data
            - ocrd (DataFrame): DataFrame with customer data
        
        Returns:
            - cash_no_Payment (DataFrame): DataFrame with preliminary customer cash data, filtered for invoices with no payments.

        Notes:
            - ``Date (date)``: Date of the transaction.
            - ``Operation (str)``: Unique identifier for the transaction.
            - ``AccountId (str)``: Unique identifier for the account.
            - ``Account_Name (str)``: Name of the account.
            - ``Account_IC (str)``: Unique identifier for the intercompany account.
            - ``Account_Bank (str)``: Unique identifier for the bank account.
            - ``Level3 (str)``: Level 3 category of the transaction.
            - ``Account_Name_IC (str)``: Name of the intercompany account.
            - ``Cash (float)``: Amount of cash.
            - ``Type (str)``: Type of transaction, either 'Banking' or 'CashFlow'.
            - ``Level1 (str)``: Level 1 category of the transaction, either 'INCOME' or 'EXPENDITURE'.
            - ``Level2 (str)``: Level 2 category of the transaction.
            - ``Comments (str)``: Comments about the transaction.
            - ``Payment (float)``: Amount of payment received for the transaction, if applicable.
        """
        jdt1_stg = jdt1.select(
        to_date(col("DueDate")).alias("Date"),
        col("TransId"),
        col("Account").alias("Account"),
        col("ShortName").alias("Account_IC"),
        col("Debit"),
        col("Credit"),
        col("LineMemo").alias("Comentarios")).filter("(ShortName >= 520000 and  ShortName <= 520099) OR (ShortName >= 572000 and  ShortName <= 572099)").withColumn("Account_Bank_Type", when(col("Account_IC").startswith("572%"), lit("Bank")).otherwise(lit("Credit")))
        
        
        
        ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])
        cash = jdt1.alias("cash").join(jdt1_stg, jdt1.TransId == jdt1_stg.TransId, how="leftouter").select("cash.DueDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", jdt1_stg.Account_IC.alias("Account_Bank"), jdt1_stg.Account_Bank_Type)
        cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
        .select("cash.DueDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", "cash.Account_Bank", oact.AcctName, oact.FrgnName)
        cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
        .select("cash.DueDate", "cash.TransId", "cash.Account", "cash.Account_Bank", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
        cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                    .withColumn("Cash", (col("Debit")-col("Credit")))\
                    .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
        
        cash = jdt1_stg.withColumn("Account_Bank_Type", when(col("Account_Bank").startswith("572%"), lit("Bank")).otherwise(lit("Credit")))
        
            
        cash = cash.withColumn("Type", when((col("Account_Name_IC").like("cc%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                        .when((col("Account_Name_IC").like("póliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                        .when((col("Account_Name_IC").like("Banco%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                        .when((col("Account_Name_IC").like("%cta. corriente%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                        .when(col("Account_Name_IC").like("%cta. corriente%%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("Banco%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("cc%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("Poliza%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("poliza%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("Póliza%"), lit("Banking"))
                        .when(col("Account_Name_IC").like("póliza%"), lit("Banking"))
                        .otherwise(lit("CashFlow"))
                        )
        
        cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE")) \
                            .when((col("Account") == "170000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                            .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                            .when(col("ShortName").startswith("C"), lit("Sales"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                            .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                            .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                            .when(col("Account") == "465000", lit("Salaries"))
                            .when(col("Account") == "475100", lit("IRPF"))
                            .when(col("Account") == "476000", lit("Social Security"))
                            .when(col("Account").like("47200%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")
    
                
        cash = cash.select(
        to_date(col("DueDate")).alias("Date"),
        col("TransId").alias("Operation"),
        col("Account").alias("AccountId"),
        col("Account_Name").alias("Account_Name"),
        col("ShortName").alias("Account_IC"),
        col("Account_Bank"),
        col("FrgnName").alias("Level3"),
        col("Account_Name_IC"),
        col("Cash"),"Type",
        "Level1", "Level2",
        col("LineMemo").alias("Comments")).dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"])
        
        cash_payment = cash.select( col("Cash").alias("Payment"), "Comments").filter(col("Comments").like("Cobros%"))
        
        
        cash_no_Payment = cash.filter((col("Comments").like("Facturas de clientes%")) | (col("Comments").like("Facturas de Clientes%"))) \
                                .filter((col("Account_IC").startswith("C")) & (col("Level2") == "Sales") )
                                
        cash_no_Payment = cash_no_Payment.alias("C").join(cash_payment, cash_payment.Payment == cash_no_Payment.Cash, how="leftouter") \
                                                    .select("C.*") \
                                                    .filter((col("Date") >= dt.datetime.utcnow()) & (col("Payment").isNull()))
    
        return cash_no_Payment
           
    def get_document_preliminary(self, btf1,obtf, oact,ocrd):
        """
        Returns a preliminary dataframe of financial transactions related to documents such as invoices, credit notes, 
        and debit notes.

        Args:
        
            - btf1: A DataFrame with the financial transactions table (BTF1 in SAP B1).
            - obtf: A DataFrame with the financial transactions table for outgoing payments (OBTI in SAP B1).
            - oact: A DataFrame with the chart of accounts table (OACT in SAP B1).
            - ocrd: A DataFrame with the business partners table (OCRD in SAP B1).

        Returns:
        
            - cash: A DataFrame with the preliminary financial transactions related to documents.

        Notes:
            - The following columns are added to the resulting DataFrame:
                - 'Date': The due date of the document.
                - 'Operation': The transaction ID of the document.
                - 'AccountId': The account ID of the transaction.
                - 'Account_Name': The name of the account of the transaction.
                - 'Account_IC': The short name of the account of the transaction.
                - 'FrgnName': The foreign name of the business partner.
                - 'Level3': The level 3 category of the transaction.
                - 'Account_Name_IC': The name of the account of the transaction or the name of the business partner.
                - 'Cash': The amount of the transaction.
                - 'Level1': The level 1 category of the transaction.
                - 'Level2': The level 2 category of the transaction.
                - 'Comments': The line memo of the transaction.
            - The 'Status' column of the 'obtf' DataFrame is used to filter for outgoing payments in the 'btf1' DataFrame.
            - The 'Pnl1' and 'Pnl2' columns of the 'oact' DataFrame are split from the 'Details' column and used as level 1 and 
            level 2 categories, respectively.
            
        """
        obtf = obtf.select(
        to_date(col("RefDate")).alias("Date"),
        col("TransId"),
        col("BtfStatus").alias("Status")).filter("Status == 'O'")
        
        
        
        ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])
        mapping = oact.select("AcctCode","AcctName", "FrgnName","Details") 
        cols = split(mapping['Details'], ',')
        mapping = mapping.withColumn('Pnl1', cols.getItem(0)).withColumn('Pnl2', cols.getItem(1))
        mapping = mapping.select("AcctCode",col("AcctName").alias("Account_Name"),"FrgnName", "Pnl1","Pnl2") 
        
        
        
        
        #Obtain Mapping for level 2

        
        cash = btf1.alias("cash").join(obtf, btf1.TransId == obtf.TransId, how="inner").select("cash.RefDate", "cash.DueDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", obtf.Status)
        cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
        .select("cash.RefDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", oact.AcctName, oact.FrgnName)
        cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
        .select("cash.RefDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
        cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                    .withColumn("Cash", (col("Debit")-col("Credit"))*-1)\
                    .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
        

        cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                            .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                            .when(col("ShortName").startswith("C"), lit("Sales"))
                            .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                            .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                            .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                            .when(col("Account") == "465000", lit("Salaries"))
                            .when(col("Account") == "475100", lit("IRPF"))
                            .when(col("Account") == "476000", lit("Social Security"))
                            .when(col("Account").like("47200%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")
    
                
        cash = cash.select(
        to_date(col("RefDate")).alias("Date"),
        col("TransId").alias("Operation"),
        col("Account").alias("AccountId"),
        col("Account_Name").alias("Account_Name"),
        col("ShortName").alias("Account_IC"),
        col("FrgnName").alias("Level3"),
        col("Account_Name_IC"),
        col("Cash"),"Level1", "Level2",
        col("LineMemo").alias("Comments")).dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"]).withColumn("Operation",lit(0))
        
    
        return cash

    def get_customer_payments(self, odrf, orcp,ocrd):
        """
        Return a DataFrame with cash information.
        
        :param jdt1: DataFrame with journal entries
        :param oact: DataFrame with chart of accounts
        :param ocrd: DataFrame with business partners information
        :return: DataFrame with cash information
        
        Example Usage:
        >>> cash_df = get_cash(jdt1_df, oact_df, ocrd_df)
        
        Columns:
        - ``Date``: Date of the transaction
        - ``Operation``: Transaction ID
        - ``AccountId``: Account ID
        - ``Account_Name``: Account Name
        - ``Account_IC``: Account IC
        - ``Account_Bank``: Bank account
        - ``Level3``: Level 3
        - ``Account_Name_IC``: Business partner name or account name
        - ``\033[1mCash\033[0m``: Cash
        - ``Level1``: Level 1
        - ``Level2``: Level 2
        - ``Type``: Type of transaction
        - ``Comments``: Comments
        """
        
        odrf = odrf.select(col("DocTotal").alias("Cash"), col("CardCode").alias("Account_IC"),"DocEntry", col("CardName").alias("Account_Name_IC")).filter(col("CardCode").startswith("P"))
        orcp = orcp.select("Remind", "DraftEntry", "StartDate","EndDate")
        odrf = odrf.alias("C").join(orcp, orcp.DraftEntry == odrf.DocEntry , how='leftouter').select("C.*", col("Remind"), to_date(col("StartDate")).alias("StartDate"), to_date(col("EndDate")).alias("EndDate"))
        odrf = odrf.withColumn("Remind", when(col("Remind") > 1000,(col("Remind") -1000 ).cast(IntegerType())).otherwise(col("Remind"))) \
                .withColumn("months_to_add", months_between(current_date(),col("StartDate") ).cast(IntegerType())+1) \
                .withColumn("CurrentDate",current_date() )\
                .withColumn("Date", when(col("CurrentDate")<= to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add),'yyyy-MM')"),date_format("StartDate", "dd"))),
                                        to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add),'yyyy-MM')"),date_format("StartDate", "dd")))).otherwise(to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add+1),'yyyy-MM')"),date_format("StartDate", "dd")))))
                        #.withColumn("date2",months_between(to_date(lit('2023-02-06')),col("StartDate") ).cast(IntegerType())+1) \
        odrf = odrf.alias("C").join(ocrd, odrf.Account_IC == ocrd.CardCode, how="leftouter").select("C.*", col("Notes").alias("Level2"))
        odrf = odrf.withColumn("Level1", lit("EXPENDITURE")).withColumn("Level3", lit("Suppliers"))
        odrf = odrf.select("Cash", "Account_IC", "Account_Name_IC", "Date", "Level1", "Level2", "Level3", "EndDate")
        customer_payments = odrf.withColumn("To",when(col("EndDate").isNotNull(),to_date("EndDate")).otherwise(add_months("Date", 18)))
        customer_payments  = customer_payments.withColumn("arr",expr("sequence(date, To, interval 1 month)")).select(explode("arr").alias("Date"),"Account_IC","Account_Name_IC","Level1","Level2", "Level3","Cash")
        customer_payments = customer_payments.withColumn("Type", lit("Forecast")).withColumn("Cash", col("Cash")*-1)
        return customer_payments

    def generate_cash_flow(self, jdt1, oact, ocrd,odrf, orcp, sbo):
        """
            Returns a DataFrame containing cash flow information.

                :param jdt1: A DataFrame containing journal entry data.
                :param oact: A DataFrame containing chart of accounts data.
                :param ocrd: A DataFrame containing customer data.
                :param odrf: A DataFrame containing payment data.
                :param orcp: A DataFrame containing payment reminder data.
                :param sbo: A string representing the company ID.

            :return: A DataFrame containing cash flow information.

            - Notes:

            - The returned DataFrame includes the following columns:
                - ``Date``: The date of the transaction.
                - ``Operation``: The transaction ID.
                - ``AccountId``: The account ID.
                - ``Account_Name``: The name of the account.
                - ``Account_IC``: The internal code for the account.
                - ``Account_Bank``: The internal code for the bank account.
                - ``Level3``: The third level of account hierarchy.
                - ``Account_Name_IC``: The name of the account with the internal code.
                - ``Cash``: The cash flow amount.
                - ``Level1``: The first level of account hierarchy.
                - ``Level2``: The second level of account hierarchy.
                - ``Type``: The type of transaction (either "Banking" or "CashFlow").
                - ``Comments``: Any additional comments related to the transaction.


            - The returned DataFrame includes only transactions of type "CashFlow" and with a bank account that is not "520000".
            - The method filters out any duplicate transactions based on the "Operation", "Account_IC", and "Account_Name_IC" columns.
            - If the "LineMemo" column contains the word "Traspaso" and the "Cash" column is positive for an expenditure transaction, the "Cash" amount is multiplied by -1.

        """
        ob = self.get_annual_opening_balance(jdt1,oact)
        cash_flow = self.get_cash(jdt1, oact,ocrd)
        ob_o = self.get_opening_balance(cash_flow, ob)
        ob_c = self.get_closing_balance(cash_flow, ob) 
        #pre_cash_flow = get_document_preliminary(btf1,obtf, oact,ocrd)
        #pre_customer_cash_flow = get_customer_preliminary(jdt1, oact,ocrd)
        #customer_payments = get_customer_payments(odrf, orcp,ocrd)
        #cash = cash_flow.unionByName(pre_cash_flow, allowMissingColumns=True)
        #cash = cash.unionByName(pre_customer_cash_flow, allowMissingColumns=True)
        #cash = cash_flow.unionByName(customer_payments, allowMissingColumns=True)
        cash = cash_flow.unionByName(ob_o, allowMissingColumns=True)
        cash = cash.unionByName(ob_c, allowMissingColumns=True)
        cash = cash.withColumn("sbo", lit(sbo)) 
        cash = cash.withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))
        cash = cash.withColumn("Company", when(col("Company_Id") == 1, "Branddocs S.L").when(col("Company_Id") == 2, "Branddocs SAGE").when(col("Company_Id") == 3, "Branddocs_SL").when(col("Company_Id") == 4, "Branddocs VideoID S.L").otherwise("Branddocs Tech S.L"))
        cash = cash.withColumn('execution_date',current_timestamp()) \
                    .withColumn("year", date_format(col("Date"), "yyyy").cast(IntegerType())) \
                    .withColumn("month", date_format(col("Date"), "MM").cast(IntegerType()))
        cash = cash.select("Date",
                    col("Operation").cast(IntegerType()),
                    col("AccountId").cast(IntegerType()),	
                    "Account_Name",
                    "Account_IC",
                    col("Account_Bank").cast(IntegerType()),
                    "Account_Name_IC" ,
                    col("Cash").alias("Total").cast('decimal(12,2)'),
                    "Level1" 	,
                    "Level2" ,
                    "Level3",
                    "Type" ,
                    "Comments" ,
                    "Company_Id",
                    "Company" ,
                    "execution_date", 
                    "year",
                    "month",
                    "sbo"

        ) 
        cash = cash.withColumn("Type_Id", (lit(1))).withColumn("Type", (lit("CashFlow"))) \
        .withColumn('Account_Key', (concat(col("AccountId").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
        .withColumn('Account_IC_Key', (concat(col("Account_IC"),col("Company_Id").cast("string"))).cast("string"))
        return cash

    def generate_credit(self, jdt1, oact, sbo):
        """
        Returns a DataFrame containing credit information.

        :param jdt1: A DataFrame containing journal entry data.
        :param oact: A DataFrame containing chart of accounts data.
        :param sbo: A string representing the company ID.

        :return: A DataFrame containing credit information.

        :notes:

        - The returned DataFrame includes the following columns:
            - ``Account``: The account ID.
            - ``Account_IC``: The internal code for the account.
            - ``Credit``: The credit amount.
            - ``Credit_Line``: The credit line amount.
            - ``Balance``: The balance amount.
            - ``Type``: The type of transaction (either "Credit Bank" or "Credit Line").
            - ``Total``: The total amount.
            - ``sbo``: The company ID.
            - ``Company_Id``: The ID of the company (parsed from the sbo parameter).
            - ``Account_Key``: The account ID combined with the company ID.
            - ``Execution_date``: The current date.

        - The returned DataFrame includes only transactions with accounts in the range of 520000-520099 and 572000-572099.
        - The method calculates the balance amount as the difference between the debit and credit amounts.
        - The method calculates the total amount as follows:
            - If the transaction is of type "Credit Bank", the total amount is the balance amount multiplied by -1.
            - If the transaction is of type "Credit Line", the total amount is the credit line amount minus the balance amount.
        """
        cash = jdt1.select(
        to_date(col("RefDate")).alias("Date"),
        col("TransId"),
        col("Account").cast('int').alias("Account"),
        col("ShortName").alias("Account_IC"),
        col("Debit"),  col("Credit"),
        col("LineMemo").alias("Comentarios")).filter("(ShortName >= 520000 and  ShortName <= 520099) OR (ShortName >= 572000 and  ShortName <= 572099)")
        saldos = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias('Month'), "Debit","Credit", "Account").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
        cash_op = saldos.groupBy("Account").agg(((sum("Debit")-sum("Credit"))*-1).cast('decimal(12,2)').alias("Balance"))
        cash_op = cash_op.alias("C").join(oact, oact.AcctCode == cash_op.Account, how="inner").select("C.*", col("Validcomm").alias("Credit_Line"))
        cash_op = cash_op.withColumn("Type", when(col("Account").like("57%"), "Credit Bank").otherwise("Credit Line"))
        cash_op = cash_op.withColumn("Total", when(col("Type") == "Credit Bank", col("Balance")*-1).otherwise(col("Credit_Line")- col("Balance")).cast('decimal(12,2)'))
        cash_op = cash_op.withColumn("Balance", when(col("Type") == "Credit Bank", col("Balance")*-1).otherwise(col("Balance")))
        cash_op = cash_op.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())).withColumn('Account_Key', (concat(col("Account").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
                .withColumn('Execution_date',current_date()) 
        return cash_op

    def generate_budget(self, obgt,bgt1,sbo):
        """
        Returns a DataFrame containing budget information.

        :param obgt: A DataFrame containing budget header data.
        :param bgt1: A DataFrame containing budget line data.
        :param sbo: A string representing the company ID.

        :return: A DataFrame containing budget information.

        :notes:

        - The returned DataFrame includes the following columns:
            - `BudgId`: The budget ID.
            - `Line_ID`: The budget line ID.
            - `AccountId`: The account ID.
            - `DebLTotal`: The total debit amount for the budget line.
            - `CredLTotal`: The total credit amount for the budget line.
            - `Total`: The total budget line amount.
            - `Date`: The date of the budget line.
            - `sbo`: The company ID.
            - `Company_Id`: The company ID as an integer.
            - `Account_Key`: The account ID concatenated with the company ID.

        """
        obgt = obgt.select(col('AbsId').cast("int"),to_date('FinancYear', 'yyy-MM-dd').alias('FinancYear'))
        bgt1 = bgt1.select(col('BudgId').cast("int"),
                        col('Line_ID').cast("int"),
                        col('AcctCode').cast("int").alias("AccountId"),
                        'DebLTotal','CredLTotal').groupBy('BudgId','Line_ID','AccountId') \
                            .agg(sum('DebLTotal').cast('decimal(12,2)').alias('DebLTotal'),
                                    sum('CredLTotal').cast('decimal(12,2)').alias('CredLTotal') ,
                                    ((sum('DebLTotal') - sum('CredLTotal'))*-1).cast('decimal(12,2)').alias('Total')) 
        bgt1 = bgt1.join(obgt, obgt.AbsId == bgt1.BudgId, how='inner') 
        bgt1 = bgt1.withColumn("Date", expr("add_months(FinancYear,Line_ID )")).drop('AbsId')
        bgt1 = bgt1.withColumn("sbo", lit(sbo)) \
                    .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
                    .withColumn('Account_Key', (concat(col("AccountId").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
        return bgt1
            
    def check_required_args(required_args):
        def decorator(func):
            def wrapper(self, **kwargs):
                local = kwargs.get("local", False)
                if not local:
                    missing_args = [arg for arg in required_args if arg not in kwargs]
                    if missing_args:
                        raise ValueError(f"Missing required arguments: {', '.join(missing_args)}")
                return func(self, **kwargs)
            return wrapper
        return decorator

    @check_required_args(["spark", "schemas", "path_in","bucket_in", "bucket_out", "path_out", "part_1"])
    def extract_transform(self, **kwargs):
        spark = kwargs.get("spark")
        schemas = kwargs.get("schemas")
        path_in = kwargs.get("path_in")
        bucket_out = kwargs.get("bucket_out")
        bucket_in = kwargs.get("bucket_in")
        path_out = kwargs.get("path_out")
        part_1 = kwargs.get("part_1")
        local = kwargs.get("local", False)

        check = False
        for sbo in schemas:
            """
            ETL pipeline for processing multiple schemas and generating curated tables for each one.

            Parameters:
            -----------
            spark : SparkSession
                SparkSession object to interact with Spark.
            schemas : list of str
                List of schemas to process.
            path_in : str
                Path in Data Lake where the raw data is stored.
            bucket_out : str
                Name of the bucket where the curated data will be stored.
            path_out : str
                Path in the bucket where the curated data will be stored.
            part_1 : str
                Part 1 of the path in the bucket where the curated data will be stored.
            Local : boolean
                Set to True for local developement

            Returns:
            --------
            None
            """
            
            
            raw_layer = DataLakeRawLayer(sbo)
            jdt1 = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/jdt1", format='parquet')
            oact = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/oact", format='parquet')
            ocrd = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/ocrd", format='parquet')
            rin1 = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/rin1", format='parquet')
            nnm1 = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/nnm1", format='parquet')
            oocr = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/oocr", format='parquet')
            orcp = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/orcp", format='parquet')
            odrf = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/odrf", format='parquet')
            oinv = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/oinv", format='parquet')
            inv1 = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/inv1", format='parquet')
            oslp = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/oslp", format='parquet')
            obgt = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/obgt", format='parquet')
            bgt1 = read_datalake(spark=spark, basepath=bucket_in, path=path_in + sbo + "/bgt1", format='parquet')


            
            if check != True:
                jdt1_curated = raw_layer.get_jdt1(jdt1)
                oact_curated = raw_layer.get_oact(oact)
                ocrd_curated = raw_layer.get_ocrd(ocrd)
                oinv_curated = raw_layer.get_oinv(oinv)
                inv1_curated = raw_layer.get_inv1(inv1)
                nnm1_curated = raw_layer.get_nnm1(nnm1)
                oslp_curated = raw_layer.get_oslp(oslp)
                oocr_curated = raw_layer.get_oocr(oocr)
                rin1_curated = raw_layer.get_rin1(rin1)
                cash_curated = self.generate_cash_flow(jdt1, oact, ocrd,odrf, orcp, sbo)
                credit_curated = self.generate_credit(jdt1, oact, sbo)
                budget_curated = self.generate_budget(obgt, bgt1,sbo)
            else:
                jdt1_stg = raw_layer.get_jdt1(jdt1)
                oinv_stg = raw_layer.get_oinv(oinv)
                inv1_stg = raw_layer.get_inv1(inv1)
                oact_stg = raw_layer.get_oact(oact)
                ocrd_stg = raw_layer.get_ocrd(ocrd)
                nnm1_stg = raw_layer.get_nnm1(nnm1)
                oslp_stg = raw_layer.get_oslp(oslp)
                rin1_stg = raw_layer.get_rin1(rin1)
                oocr_stg = raw_layer.get_oocr(oocr)
                jdt1_curated = jdt1_curated.unionByName(jdt1_stg, allowMissingColumns=True)
                oact_curated = oact_curated.unionByName(oact_stg, allowMissingColumns=True)
                ocrd_curated = ocrd_curated.unionByName(ocrd_stg, allowMissingColumns=True)
                oinv_curated = oinv_curated.unionByName(oinv_stg, allowMissingColumns=True)
                inv1_curated = inv1_curated.unionByName(inv1_stg, allowMissingColumns=True)
                nnm1_curated = nnm1_curated.unionByName(nnm1_stg, allowMissingColumns=True)
                oslp_curated = oslp_curated.unionByName(oslp_stg, allowMissingColumns=True)
                rin1_curated = rin1_curated.unionByName(rin1_stg, allowMissingColumns=True)
                oocr_curated = oocr_curated.unionByName(oocr_stg, allowMissingColumns=True)
                cash_stg = self.generate_cash_flow(jdt1, oact, ocrd,odrf, orcp, sbo)
                cash_curated = cash_curated.unionByName(cash_stg, allowMissingColumns=True)
                credit_stg = self.generate_credit(jdt1, oact, sbo)
                credit_curated = credit_curated.unionByName(credit_stg, allowMissingColumns=True)
                budget_stg = self.generate_budget(obgt, bgt1,sbo)
                budget_curated = budget_curated.unionByName(budget_stg, allowMissingColumns=True)
                
            if sbo == "a20444_bdsl_p01":
                check = True

        if local == False:
            
            write_aws(df=jdt1_curated, bucket=bucket_out, prefix=path_out + "jdt1", partitions=part_1)
            write_aws(df=oinv_curated, bucket=bucket_out, prefix=path_out + "oinv", partitions=part_1)
            write_aws(df=inv1_curated, bucket=bucket_out, prefix=path_out + "inv1", partitions=part_1)
            write_aws(df=rin1_curated, bucket=bucket_out, prefix=path_out + "rin1", partitions=part_1)
            write_aws(df=oact_curated, bucket=bucket_out, prefix=path_out + "oact", partitions=part_1)
            write_aws(df=oslp_curated, bucket=bucket_out, prefix=path_out + "oslp", partitions=part_1)
            write_aws(df=nnm1_curated, bucket=bucket_out, prefix=path_out + "nnm1", partitions=part_1)
            write_aws(df=ocrd_curated, bucket=bucket_out, prefix=path_out + "ocrd", partitions=part_1)
            write_aws(df=oocr_curated, bucket=bucket_out, prefix=path_out + "oocr", partitions=part_1)
            write_aws(df=cash_curated, bucket=bucket_out, prefix=path_out + "cfs", partitions=part_1)
            write_aws(df=credit_curated, bucket=bucket_out, prefix=path_out + "cdit", partitions=part_1)
            write_aws(df=budget_curated, bucket=bucket_out, prefix=path_out + "bgt", partitions=part_1)

            
        else:
            return cash_curated

