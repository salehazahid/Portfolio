from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark import SparkConf



def glue_context(sc):
    
    glueContext = GlueContext(sc)
    
    return glueContext



def get_spark():
    #spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    
    global sc
    sc = SparkContext.getOrCreate()
    spark = glue_context(sc).spark_session
    spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    spark.conf.set("spark.sql.sources.partitionColumnTypeInference.enabled","false")
    return spark


def get_spark_s3a_commit(bucket, mode):
    #spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    sconf = SparkConf()
    sconf.set(
        "spark.sql.sources.commitProtocolClass",
        "org.apache.spark.internal.io.cloud.PathOutputCommitProtocol"
    )
    sconf.set(
        "spark.sql.parquet.output.committer.class",
        "org.apache.spark.internal.io.cloud.BindingParquetOutputCommitter"
    )
    sconf.set("spark.sql.sources.partitionColumnTypeInference.enabled","false")
    # register hadoop s3a filesystem
    sconf.set("spark.hadoop.fs.s3.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
    sconf.set("spark.hadoop.fs.defaultFS", 's3a://{}/'.format(bucket))
    sconf.set("spark.hadoop.fs.s3a.committer.name", "partitioned")
    sconf.set("spark.hadoop.fs.s3a.committer.staging.conflict-mode", mode)
    global sc
    sc = SparkContext.getOrCreate(conf=sconf)
    spark = glue_context(sc).spark_session

    return spark


def get_job():
    
    glueContext = glue_context(sc)
    job = Job(glueContext)
    
    return job

