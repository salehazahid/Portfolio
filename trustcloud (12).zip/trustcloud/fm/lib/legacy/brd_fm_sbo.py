

from datalake_transformation import read_datalake, write_aws
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType,IntegerType
from pyspark.sql.functions import *



# %% get_annual_opening_balance
def get_annual_opening_balance(jdt1,oact):
    
    years = jdt1.select("RefDate").withColumn(
    'Year', year(jdt1.RefDate)).select("Year").distinct()
    years = years.rdd.flatMap(lambda x: x).collect()
    year_filter = "2017-01-01"
    op_balance = jdt1.filter(((col("Account") >= "572001") & (col("Account") <= "572020")) | (col("Account") >= "520001") & (col("Account") <= "520050")).filter(col("RefDate") <= year_filter) \
        .join(oact, oact.AcctCode == jdt1.Account, how="left") \
        .groupBy("Account").agg((when(col("Account").like("572%"), sum("Debit")-sum("Credit")).otherwise((max("ValidComm")-(sum("Debit") - sum("Credit"))*-1))).cast(DecimalType(18, 2)).alias('Openning')).withColumn("Date", to_date(lit(year_filter)))
    op_balance = op_balance.groupBy("Date").sum(
        "Openning").withColumnRenamed("sum(Openning)", "Openning")
    for y in years:
        if y != 2017:
            year_filter = str(y)+"-01-01"
            op_bl = jdt1.filter(((col("Account") >= "572001") & (col("Account") <= "572020")) | (col("Account") >= "520001") & (col("Account") <= "520050")).filter(col("RefDate") <= year_filter) \
                .join(oact, oact.AcctCode == jdt1.Account, how="left") \
                .groupBy("Account").agg((when(col("Account").like("572%"), sum("Debit")-sum("Credit")).otherwise((max("ValidComm")-(sum("Debit") - sum("Credit"))*-1))).cast(DecimalType(18, 2)).alias('Openning')).withColumn("Date", to_date(lit(year_filter)))
            op_bl = op_bl.groupBy("Date").sum(
                "Openning").withColumnRenamed("sum(Openning)", "Openning")
            if "op_bl" in locals():
                op_balance = op_balance.unionByName(op_bl)
    return op_balance

# %% get_jdt1


def get_jdt1(jdt1, sbo):
    jdt1 = jdt1.select(
        to_date(col("RefDate"), "yyyy-MM-dd").alias("RefDate"),
        col("TransId").cast(IntegerType()),
        col("Account").cast(IntegerType()),
        col("ShortName"),
        col("Debit").cast('decimal(12,2)'),
        col("Credit").cast('decimal(12,2)'),
        col("LineMemo"),
        "OcrCode2",
        "OcrCode3",
        "OcrCode4",
        "ProfitCode")
    jdt1 = jdt1.withColumn("sbo", lit(sbo)) \
        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
        .withColumn("year", date_format(col("RefDate"), "yyyy")) \
        .withColumn("month", date_format(col("RefDate"), "MM")) \
        .withColumn('Account_Key', (concat(col("Account").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
        .withColumn('Account_IC_Key', (concat(col("ShortName").cast("string"), col("Company_Id").cast("string"))).cast("string")) 
        

    return jdt1



def get_oinv(oinv, sbo):
    oinv = oinv.select(col("TransId").cast('int'), "DocNum", col("DocEntry").cast('int'), "CardCode", "DocStatus", to_date("DocDueDate", "yyyy-MM-dd").alias("DocDueDate"), col("SlpCode").cast('int'), col("DocTotal").cast('decimal(12,2)'), col("VatSum").cast('decimal(12,2)'), to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), to_date("TaxDate", "yyyy-MM-dd").alias("TaxDate"), "CardName","LicTradNum",col("Series").cast('int'))
    oinv = oinv.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    return oinv


def get_inv1(inv1, sbo):
    if sbo == "a20444_bdsl_p01":
        inv1 = inv1.select(col("DocEntry").cast('int'), "LineStatus", col("Quantity").cast('int'), to_date("ShipDate", "yyyy-MM-dd").alias("ShipDate"), col("OpenQty").cast('decimal(12,2)'), 
                        col("Price").cast('decimal(12,2)'),  col("LineTotal").cast('decimal(12,2)'), col("OpenSum").cast('decimal(12,2)'),  col("AcctCode").cast('int'),  to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), 
                        col("PriceBefDi").cast('decimal(12,2)'),col("GrossBuyPr").cast('decimal(12,2)'),  col("VatSum").cast('decimal(12,2)'),  col("CredOrigin").cast('decimal(12,2)'),"CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3", "U_ADVTIC_PROD_SF", "U_ADVTIC_UNI", "U_ADVTIC_FR_PG")
        inv1 = inv1.withColumn("sbo", lit(sbo)) \
            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
            .withColumn("year", date_format(col("DocDate"), "yyyy")) \
            .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    else :
        inv1 = inv1.select(col("DocEntry").cast('int'), "LineStatus", col("Quantity").cast('int'), to_date("ShipDate", "yyyy-MM-dd").alias("ShipDate"), col("OpenQty").cast('decimal(12,2)'), 
                    col("Price").cast('decimal(12,2)'),  col("LineTotal").cast('decimal(12,2)'), col("OpenSum").cast('decimal(12,2)'),  col("AcctCode").cast('int'),  to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), 
                    col("PriceBefDi").cast('decimal(12,2)'),col("GrossBuyPr").cast('decimal(12,2)'),  col("VatSum").cast('decimal(12,2)'),  col("CredOrigin").cast('decimal(12,2)'),"CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3")
        inv1 = inv1.withColumn("sbo", lit(sbo)) \
            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
            .withColumn("year", date_format(col("DocDate"), "yyyy")) \
            .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
            
    return inv1

def get_rin1(rin1, sbo):
    rin1 = rin1.select( col("DocEntry").cast('int'), "ItemCode", "Dscription", col("LineTotal").cast('decimal(12,2)'), col("BaseDocNum").cast("int"), to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), col("VatPrcnt").cast('decimal(12,2)'), "VatGroup", col("VatSum").cast('decimal(12,2)'), "BasePrice")
    rin1 = rin1.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    return rin1

def get_oocr(oocr, sbo):
    oocr = oocr.select( col("DimCode").cast('int'), "OcrCode", "OcrName")
    oocr = oocr.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
                .withColumn('DimCode_Key', (concat(col("DimCode").cast("string"), col("Company_Id").cast("string"))).cast("int"))
    return oocr


def get_oact(oact, sbo):
    oact = oact.select(col("AcctCode").cast('int'), col("AcctCode").alias('AcctCodeStr'),"AcctName", "FatherNum","FrgnName","Details","GrpLine","Levels", length('FatherNum').alias('length'))


    cols = split(oact['Details'], ',')
    oact = oact.withColumn('Pnl1', cols.getItem(0)) \
            .withColumn('Pnl2', cols.getItem(1))\
            .withColumn('Pnl3', cols.getItem(2))\
            .withColumn('Pnl4', cols.getItem(3))\
            .withColumn('Balance_1', cols.getItem(7))\
            .withColumn('Balance_2', cols.getItem(8))\
            .withColumn('Balance_3', cols.getItem(9))
    oact = oact.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
                .withColumn("sort", when(col("length") == 5, 1).otherwise(col("length"))).withColumn('Account_Key', (concat(col("AcctCode").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    return oact 

def get_ocrd(ocrd,sbo):
    ocrd = ocrd.select("CardCode", "CardName","GroupCode", "CardType", "Notes").na.fill("Other",["Notes"])
    ocrd = ocrd.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
                .withColumn('Account_IC_Key', concat(col("CardCode"), col("Company_Id").cast("string")))
    return ocrd


def get_nnm1(nnm1, sbo):
    nnm1 = nnm1.select("ObjectCode",col("Series").cast('int'), "SeriesName", "SeriesType")
    nnm1 = nnm1.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                .withColumn('ObjectCode_Key', (concat(col("ObjectCode").cast("string"), col("Company_Id").cast("string")))) 
    return nnm1

def get_oslp(oslp, sbo):
    oslp = oslp.select(col("SlpCode").cast('int'), "SlpName", "Active") 
    oslp = oslp.withColumn("sbo", lit(sbo)) \
            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
            .withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    return oslp



def get_cash(jdt1, oact,ocrd):
     #Obtain Mapping for account bank
    jdt1_stg = jdt1.select(
    to_date(col("RefDate")).alias("Date"),
    col("TransId"),
    col("Account").alias("Account"),
    col("ShortName").alias("Account_IC"),
    col("Debit"),
    col("Credit"),
    col("LineMemo").alias("Comentarios")).filter("ShortName LIKE '52%' OR ShortName LIKE '572%'")
    
    
    
    ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])
    
    cash = jdt1.alias("cash").join(jdt1_stg, jdt1.TransId == jdt1_stg.TransId, how="leftouter").select("cash.RefDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", jdt1_stg.Account_IC.alias("Account_Bank"))
    cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
    .select("cash.RefDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", "cash.Account_Bank", oact.AcctName, oact.FrgnName)
    cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
    .select("cash.RefDate", "cash.TransId", "cash.Account", "cash.Account_Bank", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
    cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                  .withColumn("Cash", when(col("Account_Bank").isNull(), lit(0)) #Mirar facturas por cobrar
                .otherwise((col("Debit")-col("Credit"))*-1))\
                  .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
    
    cash = cash.withColumn("Type", when((col("Account_Name_IC").like("cc%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("póliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("Banco%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("%cta. corriente%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when(col("Account_Name_IC").like("%cta. corriente%%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Banco%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("cc%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Poliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("poliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Póliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("póliza%"), lit("Banking"))
                       .otherwise(lit("CashFlow"))
                       )
    
    cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")) 
                        .when((col("Account") == "170000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                        .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                        .when(col("ShortName").startswith("C"), lit("Sales"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                        .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                        .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                        .when(col("Account") == "465000", lit("Salaries"))
                        .when(col("Account") == "475100", lit("IRPF"))
                        .when(col("Account").like("4751%"), lit("IRPF"))
                        .when(col("Account") == "475000", lit("IVA"))
                        .when(col("Account").like("572%"), lit("Banking"))
                        .when(col("Account").like("520%"), lit("Banking"))
                        .when(col("Account") == "476000", lit("Social Security"))
                        .when(col("Account") == "662300", lit("Banking"))
                        .when(col("Account") == "629700", lit("Corporate Support Suppliers"))
                        .when(col("Account") == "623910", lit("Corporate Support Suppliers"))
                        .when(col("Account") == "629200", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "621100", lit("Office Rent & Maintenance"))
                        .when(col("Account") == "624000", lit("Travel Suppliers"))
                        .when(col("Account") == "627000", lit("Corporate Support Suppliers"))
                        .when(col("Account") == "623600", lit("Corporate Support Suppliers"))
                        .when(col("Account") == "629100", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "629310", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "629800", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "627400", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "242300", lit("Long term investments"))
                        .when(col("Account") == "260000", lit("Long term investments"))
                        .when(col("Account") == "623800", lit("Recruitment Suppliers"))
                        .when(col("Account") == "628100", lit("Utilities Suppliers"))
                        .when(col("Account") == "628200", lit("Utilities Suppliers"))
                        .when(col("Account") == "626000", lit("Banking"))
                        .when(col("Account") == "629001", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "621300", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "621400", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "631000", lit("Other Taxes"))
                        .when(col("Account") == "629500", lit("Office Service & Equipment Suppliers"))
                        .when(col("Account") == "624001", lit("Credit Cards"))
                        .when(col("Account") == "472900", lit("IVA"))
                        .when(col("Account").like("47200%"), lit("IVA"))
                        .when(col("Account").like("47700%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")
   
            
    cash = cash.select(
    to_date(col("RefDate")).alias("Date"),
    col("TransId").alias("Operation"),
    col("Account").alias("AccountId"),
    col("Account_Name").alias("Account_Name"),
    col("ShortName").alias("Account_IC"),
    col("Account_Bank"),
    col("FrgnName").alias("Level3"),
    col("Account_Name_IC"),
    col("Cash"),"Level1", "Level2","Type",
    col("LineMemo").alias("Comments")).filter("type == 'CashFlow' and Account_Bank <> '520000'").dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"]).filter("cash <> 0")

    return cash
    

# %% get_customer_preliminary
def get_customer_preliminary(jdt1, oact,ocrd):
     #Obtain Mapping for account bank
    jdt1_stg = jdt1.select(
    to_date(col("DueDate")).alias("Date"),
    col("TransId"),
    col("Account").alias("Account"),
    col("ShortName").alias("Account_IC"),
    col("Debit"),
    col("Credit"),
    col("LineMemo").alias("Comentarios")).filter("ShortName LIKE '52%' OR ShortName LIKE '572%'").withColumn("Account_Bank_Type", when(col("Account_IC").startswith("572%"), lit("Bank")).otherwise(lit("Credit")))
    
    
    
    ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])
    cash = jdt1.alias("cash").join(jdt1_stg, jdt1.TransId == jdt1_stg.TransId, how="leftouter").select("cash.DueDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", jdt1_stg.Account_IC.alias("Account_Bank"), jdt1_stg.Account_Bank_Type)
    cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
    .select("cash.DueDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", "cash.Account_Bank", oact.AcctName, oact.FrgnName)
    cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
    .select("cash.DueDate", "cash.TransId", "cash.Account", "cash.Account_Bank", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
    cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                  .withColumn("Cash", (col("Debit")-col("Credit")))\
                  .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
    
    cash = jdt1_stg.withColumn("Account_Bank_Type", when(col("Account_Bank").startswith("572%"), lit("Bank")).otherwise(lit("Credit")))
       
        
    cash = cash.withColumn("Type", when((col("Account_Name_IC").like("cc%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("póliza%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("Banco%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when((col("Account_Name_IC").like("%cta. corriente%")) & (col("LineMemo").like("Traspaso%")), lit("CashFlow"))
                       .when(col("Account_Name_IC").like("%cta. corriente%%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Banco%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("cc%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Poliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("poliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("Póliza%"), lit("Banking"))
                       .when(col("Account_Name_IC").like("póliza%"), lit("Banking"))
                       .otherwise(lit("CashFlow"))
                       )
    
    cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE")) \
                        .when((col("Account") == "170000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                        .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                        .when(col("ShortName").startswith("C"), lit("Sales"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                        .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                         .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                        .when(col("Account") == "465000", lit("Salaries"))
                        .when(col("Account") == "475100", lit("IRPF"))
                        .when(col("Account") == "476000", lit("Social Security"))
                        .when(col("Account").like("47200%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")
   
            
    cash = cash.select(
    to_date(col("DueDate")).alias("Date"),
    col("TransId").alias("Operation"),
    col("Account").alias("AccountId"),
    col("Account_Name").alias("Account_Name"),
    col("ShortName").alias("Account_IC"),
    col("Account_Bank"),
    col("FrgnName").alias("Level3"),
    col("Account_Name_IC"),
    col("Cash"),"Type",
   "Level1", "Level2",
    col("LineMemo").alias("Comments")).dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"])
    
    cash_payment = cash.select( col("Cash").alias("Payment"), "Comments").filter(col("Comments").like("Cobros%"))
    
    
    cash_no_Payment = cash.filter((col("Comments").like("Facturas de clientes%")) | (col("Comments").like("Facturas de Clientes%"))) \
                              .filter((col("Account_IC").startswith("C")) & (col("Level2") == "Sales") )
                              
    cash_no_Payment = cash_no_Payment.alias("C").join(cash_payment, cash_payment.Payment == cash_no_Payment.Cash, how="leftouter") \
                                                  .select("C.*") \
                                                  .filter((col("Date") >= dt.datetime.utcnow()) & (col("Payment").isNull()))
  
    return cash_no_Payment
    
    

# %% get_document_preliminary
def get_document_preliminary(btf1,obtf, oact,ocrd):
     #Obtain Mapping for account bank
    obtf = obtf.select(
    to_date(col("RefDate")).alias("Date"),
    col("TransId"),
    col("BtfStatus").alias("Status")).filter("Status == 'O'")
    
    
    
    ocrd = ocrd.select("CardCode", "CardName", "Notes").na.fill("Other",["Notes"])
    mapping = oact.select("AcctCode","AcctName", "FrgnName","Details") 
    cols = split(mapping['Details'], ',')
    mapping = mapping.withColumn('Pnl1', cols.getItem(0)).withColumn('Pnl2', cols.getItem(1))
    mapping = mapping.select("AcctCode",col("AcctName").alias("Account_Name"),"FrgnName", "Pnl1","Pnl2") 
    
    
    
    
     #Obtain Mapping for level 2

    
    cash = btf1.alias("cash").join(obtf, btf1.TransId == obtf.TransId, how="inner").select("cash.RefDate", "cash.DueDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", obtf.Status)
    cash = cash.alias("cash").join(oact, cash.Account == oact.AcctCode, how="leftouter") \
    .select("cash.RefDate", "cash.TransId","cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", oact.AcctName, oact.FrgnName)
    cash = cash.alias("cash").join(ocrd, cash.ShortName == ocrd.CardCode, how="leftouter") \
    .select("cash.RefDate", "cash.TransId", "cash.Account", "cash.ShortName", "cash.Debit", "cash.Credit", "cash.LineMemo", col("AcctName").alias("Account_Name"), "FrgnName", "Notes",ocrd.CardName, ocrd.Notes)
    cash = cash.withColumn("Account_Name_IC", when(col("CardName").isNull(), col("Account_Name")).otherwise(col("CardName")))\
                  .withColumn("Cash", (col("Debit")-col("Credit"))*-1)\
                  .withColumn("Level2", when(col("Notes").isNull(), "Other").otherwise(col("Notes")))
    

    cash = cash.alias("cash").withColumn("Level1", when(col("ShortName") == "C0000057", lit("INCOME")).when(col("ShortName").startswith("C"), lit("INCOME"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("INCOME")).otherwise(lit("EXPENDITURE"))) \
                        .withColumn("Level2", when(col("ShortName") == "C0000057", lit("Sales (BS)"))
                        .when(col("ShortName").startswith("C"), lit("Sales"))
                        .when((col("Account") == "520000") & (col("Cash") > 0), lit("Loan Income"))
                        .when((col("Account") == "520000") & (col("Cash") < 0), lit("Loan Repayments"))
                        .when((col("Account") == "170000") & (col("Cash") > 0), lit("Loan Income"))
                        .when(col("Account") == "465000", lit("Salaries"))
                        .when(col("Account") == "475100", lit("IRPF"))
                        .when(col("Account") == "476000", lit("Social Security"))
                        .when(col("Account").like("47200%"), lit("IVA")).otherwise(col("Level2"))).select("cash.*" , "Level1", "Level2")
   
            
    cash = cash.select(
    to_date(col("RefDate")).alias("Date"),
    col("TransId").alias("Operation"),
    col("Account").alias("AccountId"),
    col("Account_Name").alias("Account_Name"),
    col("ShortName").alias("Account_IC"),
    col("FrgnName").alias("Level3"),
    col("Account_Name_IC"),
    col("Cash"),"Level1", "Level2",
    col("LineMemo").alias("Comments")).dropDuplicates(["Operation", "Account_IC", "Account_Name_IC"]).withColumn("Operation",lit(0))
    
  
    return cash

# %% get_opening_balance
def get_opening_balance(cash,op_balance):
    cash_op = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias(
    'Month'), "Cash").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
    cash_op = cash_op.groupBy("Date").sum(
    "Cash").withColumnRenamed("sum(Cash)", "MonthlyCash")
    cash_op = cash_op.select("Date", 'MonthlyCash').alias("C").join(
    op_balance, op_balance.Date == cash_op.Date, how="leftouter")
    cash_op = cash_op.select("C.Date", 'MonthlyCash', "Openning").withColumn("MonOP", when(col("Openning").isNotNull(), col("Openning")+col("MonthlyCash")).otherwise(col("MonthlyCash"))).withColumn("Year", year("C.Date"))
    w1 = Window.partitionBy("Year").orderBy("C.Date").rangeBetween(Window.unboundedPreceding, 0)
    w2 = Window.partitionBy("Year").orderBy("C.Date")
    cash_op = cash_op.withColumn('OpeningBalance', sum('MonOP').over(w1))
    cash_op = cash_op.select("Year", "Date", "OpeningBalance", "Openning",lag('OpeningBalance').over(w2).alias("OB")) \
                    .withColumn('Level1', lit("OPENING BALANCE")) \
                    .withColumn("Cash", when(col("OB").isNull(), col("Openning"))
                    .otherwise(col("OB")))
    
    cash_op = cash_op.select("Date", "Cash", 'Level1')
            
    return cash_op

# %% get_closing_balance
def get_closing_balance(cash,op_balance):
    cash_op = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias(
    'Month'), "Cash").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
    cash_op = cash_op.groupBy("Date").sum(
    "Cash").withColumnRenamed("sum(Cash)", "MonthlyCash")
    cash_op = cash_op.select("Date", 'MonthlyCash').alias("C").join(
    op_balance, op_balance.Date == cash_op.Date, how="leftouter")
    cash_op = cash_op.select("C.Date", 'MonthlyCash', "Openning").withColumn("MonOP", when(col("Openning").isNotNull(), col("Openning")+col("MonthlyCash")).otherwise(col("MonthlyCash"))).withColumn("Year", year("C.Date"))
    w1 = Window.partitionBy("Year").orderBy("C.Date").rangeBetween(Window.unboundedPreceding, 0)
    w2 = Window.partitionBy("Year").orderBy("C.Date")
    cash_op = cash_op.withColumn('Cash', sum('MonOP').over(w1))
    cash_op = cash_op.select( "Date", "Cash") \
                    .withColumn('Level1', lit("CLOSING BALANCE"))
                   
    return cash_op

# %% get_customer_payments
def get_customer_payments(odrf, orcp,ocrd):
    odrf = odrf.select(col("DocTotal").alias("Cash"), col("CardCode").alias("Account_IC"),"DocEntry", col("CardName").alias("Account_Name_IC")).filter(col("CardCode").startswith("P"))
    orcp = orcp.select("Remind", "DraftEntry", "StartDate")
    odrf = odrf.alias("C").join(orcp, orcp.DraftEntry == odrf.DocEntry , how='leftouter').select("C.*", col("Remind"), to_date(col("StartDate")).alias("StartDate"))
    odrf = odrf.withColumn("Remind", when(col("Remind") > 1000,(col("Remind") -1000 ).cast(IntegerType())).otherwise(col("Remind"))) \
                .withColumn("months_to_add", months_between(current_date(),col("StartDate") ).cast(IntegerType())+1) \
                .withColumn("CurrentDate",to_date(current_date()) )\
                .withColumn("Date", when(to_date(lit('2023-02-06')) <= to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add),'yyyy-MM')"),"Remind")),to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add),'yyyy-MM')"),"Remind"))).otherwise(to_date(concat_ws("-", expr("date_format(add_months(StartDate, months_to_add+1),'yyyy-MM')"),"Remind"))))
                 #.withColumn("date2",months_between(to_date(lit('2023-02-06')),col("StartDate") ).cast(IntegerType())+1) \
    odrf = odrf.alias("C").join(ocrd, odrf.Account_IC == ocrd.CardCode, how="leftouter").select("C.*", col("Notes").alias("Level2"))
    odrf = odrf.withColumn("Level1", lit("EXPENDITURE")).withColumn("Level3", lit("Suppliers"))
    odrf = odrf.select("Cash", "Account_IC", "Account_Name_IC", "Date", "Level1", "Level2", "Level3")
    return odrf


# %% generate_cash_flow
def generate_cash_flow(jdt1, oact, ocrd,odrf, orcp, sbo):
    ob = get_annual_opening_balance(jdt1,oact)
    cash_flow = get_cash(jdt1, oact,ocrd)
    ob_o = get_opening_balance(cash_flow, ob)
    ob_c = get_closing_balance(cash_flow, ob) 
    #pre_cash_flow = get_document_preliminary(btf1,obtf, oact,ocrd)
    #pre_customer_cash_flow = get_customer_preliminary(jdt1, oact,ocrd)
    #customer_payments = get_customer_payments(odrf, orcp,ocrd)
    #cash = cash_flow.unionByName(pre_cash_flow, allowMissingColumns=True)
    #cash = cash.unionByName(pre_customer_cash_flow, allowMissingColumns=True)
    #cash = cash_flow.unionByName(customer_payments, allowMissingColumns=True)
    cash = cash_flow.unionByName(ob_o, allowMissingColumns=True)
    cash = cash.unionByName(ob_c, allowMissingColumns=True)
    cash = cash.withColumn("sbo", lit(sbo)) 
    cash = cash.withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))
    cash = cash.withColumn("Company", when(col("Company_Id") == 1, "Branddocs S.L").when(col("Company_Id") == 2, "Branddocs SAGE").when(col("Company_Id") == 3, "Branddocs_SL").when(col("Company_Id") == 4, "Branddocs VideoID S.L").otherwise("Branddocs Tech S.L"))
    cash = cash.withColumn('execution_date',current_timestamp()) \
                .withColumn("year", date_format(col("Date"), "yyyy").cast(IntegerType())) \
                .withColumn("month", date_format(col("Date"), "MM").cast(IntegerType()))
    cash = cash.select("Date",
                col("Operation").cast(IntegerType()),
                col("AccountId").cast(IntegerType()),	
                "Account_Name",
                "Account_IC",
                col("Account_Bank").cast(IntegerType()),
                "Account_Name_IC" ,
                col("Cash").alias("Total").cast('decimal(12,2)'),
                "Level1" 	,
                "Level2" ,
                "Level3",
                "Type" ,
                "Comments" ,
                "Company_Id",
                "Company" ,
                "execution_date", 
                "year",
                "month",
                "sbo"

    ) 
    cash = cash.withColumn("Type_Id", (lit(1))).withColumn("Type", (lit("CashFlow"))) \
    .withColumn('Account_Key', (concat(col("AccountId").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
    .withColumn('Account_IC_Key', (concat(col("Account_IC"),col("Company_Id").cast("string"))).cast("string"))

    return cash


# %% generate_credit
def generate_credit(jdt1, oact, sbo):
    cash = jdt1.select(
    to_date(col("RefDate")).alias("Date"),
    col("TransId"),
    col("Account").cast('int').alias("Account"),
    col("ShortName").alias("Account_IC"),
    col("Debit"),  col("Credit"),
    col("LineMemo").alias("Comentarios")).filter("ShortName LIKE '52%' OR ShortName LIKE '572%'")
    saldos = cash.select(year(cash.Date).alias('Year'), month(cash.Date).alias('Month'), "Debit","Credit", "Account").withColumn("Date", to_date(concat_ws("-", "Year", "Month", lit("01"))))
    cash_op = saldos.groupBy("Account").agg(((sum("Debit")-sum("Credit"))).cast('decimal(12,2)').alias("Balance"))
    cash_op = cash_op.alias("C").join(oact, oact.AcctCode == cash_op.Account, how="inner").select("C.*", col("Validcomm").alias("Credit_Line"))
    cash_op = cash_op.withColumn("Type", when(col("Account").like("57%"), "Credit Bank").otherwise("Credit Line"))
    cash_op = cash_op.withColumn("Total", when(col("Type") == "Credit Bank", col("Balance")).otherwise(col("Credit_Line")- col("Balance")).cast('decimal(12,2)'))
    cash_op = cash_op.withColumn("sbo", lit(sbo)) \
            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())).withColumn('Account_Key', (concat(col("Account").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
            .withColumn('Execution_date',current_date()) 
    return cash_op


def generate_budget(obgt,bgt1,sbo):
    obgt = obgt.select(col('AbsId').cast("int"),to_date('FinancYear', 'yyy-MM-dd').alias('FinancYear'))
    bgt1 = bgt1.select(col('BudgId').cast("int"),
                       col('Line_ID').cast("int"),
                       col('AcctCode').cast("int").alias("AccountId"),
                       'DebLTotal','CredLTotal').groupBy('BudgId','Line_ID','AccountId') \
                           .agg(sum('DebLTotal').cast('decimal(12,2)').alias('DebLTotal'),
                                sum('CredLTotal').cast('decimal(12,2)').alias('CredLTotal') ,
                                ((sum('DebLTotal') - sum('CredLTotal'))*-1).cast('decimal(12,2)').alias('Total')) 
    bgt1 = bgt1.join(obgt, obgt.AbsId == bgt1.BudgId, how='inner') 
    bgt1 = bgt1.withColumn("Date", expr("add_months(FinancYear,Line_ID )")).drop('AbsId')
    bgt1 = bgt1.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType())) \
                .withColumn('Account_Key', (concat(col("AccountId").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
    return bgt1
        
# %% data_lake_fm_sbo
