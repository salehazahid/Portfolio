from fm_sap_bo.sap_bo import DataLakeCuratedLayer

data_lake_curated_layer = DataLakeCuratedLayer()