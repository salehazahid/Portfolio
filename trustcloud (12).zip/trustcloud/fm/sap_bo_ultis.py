

from pyspark.sql.types import IntegerType
from pyspark.sql.functions import *


class JDT1:
    """
    This class represents the Journal Entries table in SAP Business One.

    Attributes:
    
        jdt1 (DataFrame): A DataFrame containing data from the JDT1 table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the JDT1 table.

    Methods:
    
        __init__(self, jdt1, sbo): Constructs all the necessary attributes for the JDT1 object.

    Notes:
    
        The processed DataFrame contains the following columns:
            - RefDate (datetime): The date of the journal entry.
            - TransId (int): The transaction ID.
            - Account (int): The account number.
            - ShortName (str): The name of the account.
            - Debit (decimal): The debit amount.
            - Credit (decimal): The credit amount.
            - LineMemo (str): The line item memo.
            - OcrCode2 (str): The second cost center.
            - OcrCode3 (str): The third cost center.
            - OcrCode4 (str): The fourth cost center.
            - ProfitCode (str): The profit center.
            - sbo (str): The SAP Business One database.
            - Company_Id (int): The ID of the company.
            - year (str): The year of the journal entry.
            - month (str): The month of the journal entry.
            - Account_Key (int): The account key.
            - Account_IC_Key (str): The account intercompany key.

    """
    def __init__(self, jdt1, sbo):
        self.jdt1 = jdt1
        self.sbo = sbo
        df_jdt1 = self.jdt1.select(
            to_date(col("RefDate"), "yyyy-MM-dd").alias("RefDate"),
            col("TransId").cast(IntegerType()),
            col("Account").cast(IntegerType()),
            col("ShortName"),
            col("Debit").cast('decimal(12,2)'),
            col("Credit").cast('decimal(12,2)'),
            col("LineMemo"),
            "OcrCode2",
            "OcrCode3",
            "OcrCode4",
            "ProfitCode")
        df_jdt1 = df_jdt1.withColumn("sbo", lit(sbo)) \
            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
            .withColumn("year", date_format(col("RefDate"), "yyyy")) \
            .withColumn("month", date_format(col("RefDate"), "MM")) \
            .withColumn('Account_Key', (concat(col("Account").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
            .withColumn('Account_IC_Key', (concat(col("ShortName").cast("string"), col("Company_Id").cast("string"))).cast("string")) 
        

        self.dataframe = df_jdt1

class OINV:
    """
    This class represents the A/R Invoice table in SAP Business One.

    Attributes:
        
        oinv (DataFrame): A DataFrame containing data from the OINV table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
        
        dataframe (DataFrame): A DataFrame containing the processed data from the OINV table.

    Methods:
    
        __init__(self, oinv, sbo): Constructs all the necessary attributes for the OINV object.

     Notes:
     
        The processed DataFrame contains the following columns:
            - TransId (int): The transaction ID.
            - DocNum (str): The document number.
            - DocEntry (int): The document entry.
            - CardCode (str): The customer code.
            - DocStatus (str): The document status.
            - DocDueDate (datetime): The due date of the document.
            - SlpCode (int): The sales employee code.
            - DocTotal (decimal): The total document amount.
            - VatSum (decimal): The total VAT amount.
            - DocDate (datetime): The document date.
            - TaxDate (datetime): The tax date.
            - CardName (str): The customer name.
            - LicTradNum (str): The customer VAT number.
            - Series (int): The document series.
            - sbo (str): The SAP Business One database.
            - Company_Id (int): The ID of the company.
            - year (str): The year of the invoice.
            - month (str): The month of the invoice.
            - DocEntry_Key (int): The document entry key.
            
    """
    def __init__(self, oinv, sbo):
        self.oinv = oinv
        self.sbo = sbo
        df_oinv  = self.oinv.select(col("TransId").cast('int'), 
                                "DocNum",
                                col("DocEntry").cast('int'),
                                "CardCode", 
                                "DocStatus", 
                                to_date("DocDueDate", "yyyy-MM-dd").alias("DocDueDate"),
                                col("SlpCode").cast('int'),
                                col("DocTotal").cast('decimal(12,2)'),
                                col("VatSum").cast('decimal(12,2)'),
                                to_date("DocDate", "yyyy-MM-dd").alias("DocDate"),
                                to_date("TaxDate", "yyyy-MM-dd").alias("TaxDate"), 
                                "CardName",
                                "LicTradNum",
                                col("Series").cast('int')
                                )
        
        df_oinv  = df_oinv .withColumn("sbo", lit(self.sbo )) \
                .withColumn("Company_Id", regexp_replace(split(lit(self.sbo ), '_').getItem(2),"p","").cast(IntegerType()))\
                .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                .withColumn("month", date_format(col("DocDate"), "MM")) \
                .withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
                
        self.dataframe = df_oinv

class INV1:
    """
    Represents the A/R Invoice Detail table (INV1) in SAP Business One.

    Attributes:
    
        inv1 (DataFrame): A DataFrame containing data from the INV1 table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the INV1 table.

    Methods:
    
        __init__(self, inv1, sbo): Constructs all the necessary attributes for the INV1 object.

    Notes:
    
        The INV1 table contains the following columns:
            - DocEntry (int): Unique identifier for the invoice document.
            - LineNum (int): Line number of the invoice detail.
            - ItemCode (str): Item code.
            - Dscription (str): Item description.
            - Quantity (float): Quantity of the item.
            - Price (float): Price of the item.
            - DiscPrcnt (float): Discount percentage applied to the item price.
            - LineTotal (float): Total price of the invoice detail line.
            - TaxCode (str): Tax code for the item.
            - WhsCode (str): Warehouse code for the item.
            - OcrCode2 (str): Dimension 1 code.
            - OcrCode3 (str): Dimension 2 code.
            
    """
    def __init__(self, inv1, sbo):
        self.inv1 = inv1
        self.sbo = sbo

        if sbo == "a20444_bdsl_p01":
            df_inv1 = self.inv1.select(col("DocEntry").cast('int'),col("LineNum").cast('int'), "BaseCard", "LineStatus", col("Quantity").cast('int'), to_date("ShipDate", "yyyy-MM-dd").alias("ShipDate"), col("OpenQty").cast('decimal(12,2)'), 
                            col("Price").cast('decimal(12,2)'),  col("LineTotal").cast('decimal(12,2)'), col("OpenSum").cast('decimal(12,2)'),  col("AcctCode").cast('int'),  to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), 
                            col("PriceBefDi").cast('decimal(12,2)'),col("GrossBuyPr").cast('decimal(12,2)'),  col("VatSum").cast('decimal(12,2)'),  col("CredOrigin").cast('decimal(12,2)'),"CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3", "U_ADVTIC_PROD_SF", "U_ADVTIC_UNI", "U_ADVTIC_FR_PG", col("SlpCode").cast('int'))
            
            df_inv1 = df_inv1.withColumn("sbo", lit(sbo)) \
                            .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                            .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                            .withColumn("month", date_format(col("DocDate"), "MM")) \
                            .withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
                            .withColumn('Account_IC_Key', (concat(col("BaseCard").cast("string"), col("Company_Id").cast("string"))).cast("string")) \
                            .withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
        else :
            df_inv1 = self.inv1.select(col("DocEntry").cast('int'), col("LineNum").cast('int'), "BaseCard", "LineStatus", col("Quantity").cast('int'), to_date("ShipDate", "yyyy-MM-dd").alias("ShipDate"), col("OpenQty").cast('decimal(12,2)'), 
                        col("Price").cast('decimal(12,2)'),  col("LineTotal").cast('decimal(12,2)'), col("OpenSum").cast('decimal(12,2)'),  col("AcctCode").cast('int'),  to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), 
                        col("PriceBefDi").cast('decimal(12,2)'),col("GrossBuyPr").cast('decimal(12,2)'),  col("VatSum").cast('decimal(12,2)'),  col("CredOrigin").cast('decimal(12,2)'),"CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3", col("SlpCode").cast('int'))
            
            df_inv1 = df_inv1.withColumn("sbo", lit(sbo)) \
                .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                .withColumn("month", date_format(col("DocDate"), "MM")) \
                .withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")) \
                .withColumn('Account_IC_Key', (concat(col("BaseCard").cast("string"), col("Company_Id").cast("string"))).cast("string")) \
                .withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
            
        self.dataframe = df_inv1   

class RIN1:
    """
    Represents the A/R Invoice Lines table (RIN1) in SAP Business One.

    Attributes:
    
        rin1 (DataFrame): A DataFrame containing data from the RIN1 table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the RIN1 table.

    Methods:
    
        __init__(self, rin1, sbo): Constructs all the necessary attributes for the RIN1 object.

    Notes:
    
        The columns in the DataFrame are as follows:
        - DocEntry: Document entry.
        - LineNum: Line number.
        - ItemCode: Item code.
        - Dscription: Item description.
        - Quantity: Quantity.
        - Price: Price.
        - DiscPrcnt: Discount percentage.
        - LineTotal: Line total.
        - WhsCode: Warehouse code.
        - ShipDate: Shipment date.

    """
    def __init__(self, rin1, sbo):
        self.rin1 = rin1
        self.sbo = sbo
        
        if sbo == "a20444_bdsl_p01":
            df_rin1 = self.rin1.select( col("DocEntry").cast('int'),col("BaseEntry").cast('int'), col("BaseLine").cast('int'), "BaseCard", "ItemCode", "Dscription", col("LineTotal").cast('decimal(12,2)'), col("BaseDocNum").cast("int"), to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), col("VatPrcnt").cast('decimal(12,2)'), "VatGroup", col("VatSum").cast('decimal(12,2)'), "BasePrice","CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3", "U_ADVTIC_PROD_SF", "U_ADVTIC_UNI", "U_ADVTIC_FR_PG",col("SlpCode").cast('int'))
            df_rin1 = df_rin1.withColumn("sbo", lit(self.sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(self.sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                        .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                        .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")).withColumn('Account_IC_Key', (concat(col("BaseCard").cast("string"), col("Company_Id").cast("string"))).cast("string")).withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int"))   
        else:
            df_rin1 = self.rin1.select( col("DocEntry").cast('int'),col("BaseEntry").cast('int'), col("BaseLine").cast('int'), "BaseCard", "ItemCode", "Dscription", col("LineTotal").cast('decimal(12,2)'), col("BaseDocNum").cast("int"), to_date("DocDate", "yyyy-MM-dd").alias("DocDate"), col("VatPrcnt").cast('decimal(12,2)'), "VatGroup", col("VatSum").cast('decimal(12,2)'), "BasePrice","CogsOcrCod" ,"CogsOcrCo2" ,"CogsOcrCo3",col("SlpCode").cast('int'))
            df_rin1 = df_rin1.withColumn("sbo", lit(self.sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(self.sbo), '_').getItem(2),"p","").cast(IntegerType()))\
                        .withColumn("year", date_format(col("DocDate"), "yyyy")) \
                        .withColumn("month", date_format(col("DocDate"), "MM")).withColumn('DocEntry_Key', (concat(col("DocEntry").cast("string"), col("Company_Id").cast("string"))).cast("int")).withColumn('Account_IC_Key', (concat(col("BaseCard").cast("string"), col("Company_Id").cast("string"))).cast("string")).withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int")) 
        
        self.dataframe = df_rin1

class OOCR:
    """
    
    Represents the Cost Center table (OOCR) in SAP Business One.

    Attributes:
    
        oocr (DataFrame): A DataFrame containing data from the OOCR table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the OOCR table.

    Methods:
    
        __init__(self, oocr, sbo): Constructs all the necessary attributes for the OOCR object.

    Notes:
    
        The columns in the DataFrame are as follows:
        - PrcCode: Cost center code.
        - PrcName: Cost center name.
        - DimCode: Dimension code for the cost center.
        - Active: Whether the cost center is active or not.

    """
    def __init__(self, oocr, sbo):
        self.oocr = oocr
        self.sbo = sbo
        df_oocr = oocr.select(col("DimCode").cast('int'), "OcrCode", "OcrName")
        df_oocr = df_oocr.withColumn("sbo", lit(sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2), "p", "").cast(IntegerType())) \
                        .withColumn('DimCode_Key', (concat(col("DimCode").cast("string"), col("Company_Id").cast("string"))).cast("int"))
        self.dataframe = df_oocr

class OACT:
    """
    Represents the G/L Accounts table (OACT) in SAP Business One.

    Attributes:
    
        oact (DataFrame): A DataFrame containing data from the OACT table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the OACT table.

    Methods:
    
        __init__(self, oact, sbo): Constructs all the necessary attributes for the OACT object.

    Notes:
    
        The columns in the DataFrame are as follows:
        - AcctCode: G/L account code.
        - AcctName: G/L account name.
        - Postable: Whether the account is postable or not.
        - DataSource: Source of data for the account.
        - LocManTran: Whether local manual transactions are allowed for the account.
        - LocCurrBal: Whether local currency balances are allowed for the account.
        - FrgnCurrBal: Whether foreign currency balances are allowed for the account.
        - ReconAcc: Reconciliation account for the G/L account.
        - CashAcc: Cash account for the G/L account.
        - PnLacct: Whether the account is a profit and loss account.
        - LiableForTax: Whether the account is liable for tax.
        - Active: Whether the account is active or not.

    """

    def __init__(self, oact, sbo):
        self.oact = oact
        self.sbo = sbo
        df_oact = oact.select(col("AcctCode").cast('int'), col("AcctCode").alias('AcctCodeStr'), "AcctName", "FatherNum", "FrgnName", "Details", "GrpLine", "Levels", length('FatherNum').alias('length'))

        cols = split(df_oact['Details'], ',')
        df_oact = df_oact.withColumn('Pnl1', cols.getItem(0)) \
                        .withColumn('Pnl2', cols.getItem(1))\
                        .withColumn('Pnl3', cols.getItem(2))\
                        .withColumn('Pnl4', cols.getItem(3))\
                        .withColumn('Balance_1', cols.getItem(7))\
                        .withColumn('Balance_2', cols.getItem(8))\
                        .withColumn('Balance_3', cols.getItem(9))
        df_oact = df_oact.withColumn("sbo", lit(sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2), "p", "").cast(IntegerType())) \
                        .withColumn("sort", when(col("length") == 5, 1).otherwise(col("length"))).withColumn('Account_Key', (concat(col("AcctCode").cast("string"), col("Company_Id").cast("string"))).cast("int"))

        self.dataframe = df_oact

class OCRD:
    """
    Represents the Business Partner Master Data table (OCRD) in SAP Business One.

    Attributes:
    
        ocrd (DataFrame): A DataFrame containing data from the OCRD table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the OCRD table.

    Methods:
    
        __init__(self, ocrd, sbo): Constructs all the necessary attributes for the OCRD object.

    Notes:
    
        The OCRD table contains the following columns:
            - CardCode (str): Unique identifier for the business partner.
            - CardName (str): Name of the business partner.
            - CardType (str): Type of the business partner (customer or vendor).
            - GroupCode (str): Group code of the business partner.
            - Phone1 (str): Primary phone number of the business partner.
            - E_Mail (str): Email address of the business partner.
            - Balance (float): Current balance of the business partner.
            - Currency (str): Currency code for the business partner.
            - LicTradNum (str): Legal identification number of the business partner.
            - DebitorAccount (str): Account code for the business partner.
            - CreditLimit (float): Credit limit for the business partner.
            
    """ 
    def __init__(self, ocrd, sbo):
        self.ocrd = ocrd
        self.sbo = sbo
        df_ocrd = ocrd.select("CardCode", "CardName", "GroupCode", "CardType", "Notes").na.fill("Other", ["Notes"])

        df_ocrd = df_ocrd.withColumn("sbo", lit(sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2), "p", "").cast(IntegerType())) \
                        .withColumn('Account_IC_Key', concat(col("CardCode"), col("Company_Id").cast("string")))

        self.dataframe = df_ocrd
        
class NNM1:
    """
    Represents the Number Series table (NNM1) in SAP Business One.

    Attributes:
    
        nnm1 (DataFrame): A DataFrame containing data from the NNM1 table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the NNM1 table.

    Methods:
    
        __init__(self, nnm1, sbo): Constructs all the necessary attributes for the NNM1 object.

    Notes:
    
        The NNM1 table contains information about number series in SAP Business One, which are used for document numbering.
        The following columns are included in the table:
            - Series: The number series code.
            - SeriesName: The description of the number series.
            - ObjectCode: The object code to which the number series is assigned.
            - FirstNum: The first number in the number series.
            - LastNum: The last number in the number series.
            - NextNum: The next available number in the number series.
            - Locked: Indicates whether the number series is locked.
            - DataSource: The source of the data in the table.
    """

    def __init__(self, nnm1, sbo):
        self.nnm1 = nnm1
        self.sbo = sbo
        df_nnm1 = nnm1.select("ObjectCode", col("Series").cast('int'), "SeriesName", "SeriesType")

        df_nnm1 = df_nnm1.withColumn("sbo", lit(sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2), "p", "").cast(IntegerType()))\
                        .withColumn('ObjectCode_Key', (concat(col("ObjectCode").cast("string"), col("Company_Id").cast("string"))))

        self.dataframe = df_nnm1

class OSLP:
    """
    Represents the Sales Employee table (OSLP) in SAP Business One.

    Attributes:
    
        oslp (DataFrame): A DataFrame containing data from the OSLP table.
        sbo (str): A string representing the SAP Business One database.

    Properties:
    
        dataframe (DataFrame): A DataFrame containing the processed data from the OSLP table.

    Methods:
    
        __init__(self, oslp, sbo): Constructs all the necessary attributes for the OSLP object.

    Notes:
    
        The OSLP table contains information about sales employees in SAP Business One.
        The following columns are included in the table:
            - SlpCode: The sales employee code.
            - SlpName: The name of the sales employee.
            - Memo: A memo field for additional information.
            - DataSource: The source of the data in the table.
            
    """
    def __init__(self, oslp, sbo):
        self.oslp = oslp
        self.sbo = sbo
        df_oslp = oslp.select(col("SlpCode").cast('int'), "SlpName", "Active")

        df_oslp = df_oslp.withColumn("sbo", lit(sbo)) \
                        .withColumn("Company_Id", regexp_replace(split(lit(sbo), '_').getItem(2), "p", "").cast(IntegerType())) \
                        .withColumn('SlpCode_Key', (concat(col("SlpCode").cast("string"), col("Company_Id").cast("string"))).cast("int"))

        self.dataframe = df_oslp
