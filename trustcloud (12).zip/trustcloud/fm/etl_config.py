import sys
from ast import literal_eval
from awsglue.utils import getResolvedOptions
from datalake_cloud_unity.aws.spark import get_job
from datalake_cloud_unity.aws.spark import get_job,get_spark_s3a_commit

def load_config(callback=None, islocal=False, layer="raw"):
    # Append command line arguments
    
    if islocal == True:
        sys.argv.extend([
            '--JOB_NAME', 'ETL_SAP',
            '--bucket_in', 'datalake-raw-661213884153',
            '--bucket_out', f'trustcloud-datalake-curated-661213884153',
            '--env', '/dev',
            '--parts1', '["appclient", "year", "month", "day"]',
            '--parts2', '["appclient", "year", "month", "day"]',
            '--schemas', '["a20444_bdsl_p01","a20444_bdsl_p02","a20444_bdsl_p03","a20444_bdsl_p04","a20444_bdsl_p05"]',
            '--key', '/sap/',
        ])


    # Get resolved options
    args = getResolvedOptions(sys.argv, [
        "JOB_NAME", "bucket_in",'bucket_out', "env", "parts1", "parts2", "schemas", "key"
    ])

    # Assign variables
    job_name = args['JOB_NAME']
    bucket_in = args['bucket_in']
    bucket_out = args['bucket_out']
    path_in =  args['key']
    path_out = "/tc/fm/"
    part_1 = literal_eval(args['parts1'])
    part_2 = literal_eval(args['parts2'])
    schemas = literal_eval(args['schemas'])
    
    spark = get_spark_s3a_commit(bucket_out, "replace")
    # Initialize job
    job = get_job()
    job.init(job_name, args)
    


    return job, spark, path_in, path_out, bucket_in, bucket_out, schemas, part_1, part_2
