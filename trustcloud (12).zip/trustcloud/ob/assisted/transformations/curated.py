
from pyspark.sql.functions import *
from pyspark.sql.window import Window

class OBCuratedTransformation:
    
    @staticmethod
    def transform(dfs, spark=None):

        try:
            dfs["videoidentificationprecalltestlite"].createOrReplaceTempView("VideoIdentificationPreCallTestLite")
            dfs["videoidentification"].createOrReplaceTempView("VideoIdentification")
            dfs["videonotificationstatusclient"].createOrReplaceTempView("VideoNotificationStatusClient")
            dfs["branddocsfile"].createOrReplaceTempView("BranddocsFile")
            dfs["incomingcall"].createOrReplaceTempView("IncomingCall")
            dfs["videoidentificationstatus"].createOrReplaceTempView("VideoIdentificationStatus")
            dfs["videoevidence"].createOrReplaceTempView("VideoEvidence")
            dfs["otherdocumentation"].createOrReplaceTempView("OtherDocumentation")
            dfs["signingevidence"].createOrReplaceTempView("SigningEvidence")

        
            print("Proceso ETL Started")
            C = spark.sql("SELECT to_date(C.DateCreated, 'yyyy-MM-dd') AS FechaURL, RANK() OVER(PARTITION BY to_date(C.DateCreated, 'yyyy-MM-dd') ORDER BY DocNumber) AS Nro_Clientes,DocNumber FROM VideoIdentification C LEFT JOIN  VideoIdentificationPreCallTestLite P ON P.IdVideoIdentification = C.ID WHERE to_date(C.DateCreated, 'yyyy-MM-dd') > '2019-07-01' AND (VerificationStatus <> 'NQ' OR StatusCode IS NOT NULL) GROUP BY to_date(C.DateCreated, 'yyyy-MM-dd'), DocNumber")
            C.createOrReplaceTempView("Calls")

            print("Proceso ETL CertificadoVideo")

            CertificadoVideo = spark.sql("SELECT to_date(DateVideoCreated, 'yyyy-MM-dd') as Fecha, " +
                                        "ID, "+
                    "BranddocsCertificatePath as Certificado "+
                    "FROM VideoIdentification " 
                    "WHERE	to_date(DateVideoCreated, 'yyyy-MM-dd') > '2017-06-09' ")

            CertificadoVideo.createOrReplaceTempView("CertVideo")


            EvidenciasVideo = spark.sql("SELECT  "+
                    "to_date(Date, 'yyyy-MM-dd') as Fecha, " +
                    "FilePath as Certificado ,"+
                    "Type as Categoria ,"+
                    "VideoIdentificationID as ID "+
                    "FROM VideoEvidence " + 
                    "WHERE	to_date(Date, 'yyyy-MM-dd') > '2017-06-09' ")
                    
            print("Proceso ETL CertificadoVideo")
            EvidenciasVideo.createOrReplaceTempView("EviVideo")


            print("Proceso ETL FirmaCertVideo")
            FirmaCertVideo = spark.sql("SELECT  "+
                    "to_date(Date, 'yyyy-MM-dd') as Fecha, " +
                    "ID ,"+
                    "BranddocsCertificatePath as Certificado "+
                    "FROM SigningEvidence " + 
                    "WHERE	to_date(Date, 'yyyy-MM-dd')  > '2017-06-09' ")


            FirmaCertVideo.createOrReplaceTempView("FirmaCerVideo")
            print("Proceso ETL Uploads")
            Uploads = spark.sql("SELECT  "+
                    "to_date(DateCreated , 'yyyy-MM-dd') as Fecha, " +
                    "ID "+
                    "FROM OtherDocumentation " + 
                    "WHERE	to_date(DateCreated , 'yyyy-MM-dd')  > '2017-06-09' ")

            Uploads.createOrReplaceTempView("Uploads")


            print("Proceso ETL evidences")
            evidences = spark.sql("SELECT ID, Categoria from EviVideo").groupby("ID").pivot("Categoria").count().na.fill(value=0)

            evidences.createOrReplaceTempView("Evidn")


            print("Proceso ETL 1")
            VE = spark.sql("SELECT  "+
                    "VideoIdentificationID," +
                    "VideoControlID,"+
                    "ROW_NUMBER() OVER (PARTITION BY VideoIdentificationID  ORDER BY VideoIdentificationID ) AS Dp "+
                    "FROM VideoIdentificationStatus")

            VE.createOrReplaceTempView("VE")


            VEI = spark.sql("SELECT  "+
                    "IdVideoIdentification," +
                            "StatusCode," +
                        "Title," +
                        "OS," +
                        "Device," +
                        "Browser," +
                    "ROW_NUMBER() OVER (PARTITION BY IdVideoIdentification  ORDER BY IdVideoIdentification ) AS Dp "+
                    "FROM VideoIdentificationPreCallTestLite")
                    

            VEI.createOrReplaceTempView("VEI")

            ST = spark.sql("SELECT DISTINCT "+
                    "StatusCode," +
                    "StatusDescription " +
                    "FROM VideoNotificationStatusClient")
                    
            print("Proceso ETL 2")
            ST.createOrReplaceTempView("ST")

            #COMPROBAR EL PARTITION 
            IC = spark.sql("SELECT  "+
                    "VideoIdentificationID," +
                            "VideoPlatformCallId," +
                            "Language," +
                        "Date," +
                    "ROW_NUMBER() OVER (PARTITION BY VideoIdentificationID  ORDER BY VideoIdentificationID ) AS Dp "+
                    "FROM IncomingCall")


            IC.createOrReplaceTempView("IC")


            print("Proceso ETL 4")

            df = spark.sql(
            "SELECT VI.ID " +
                ",DateCreated " +
                ",Name" +
                ",DocNumber " +
                ",Country " +
                ",BranddocsFileID " +
                ",VideoApplicationPlatform " +
                ",VideoApplicationID " +
                ",VerificationStatus " +
                ",VerificationStatusDescription " +
                ",DateVideoCreated " +
                ",DateVideoEnded " +
                    ",DateCallEnded" +
                ",IC.Date" +
                ",VideoDuration " +
                ",Agent " +
                ",VI.Device " +
                ",VI.OS " +
                ",VI.Browser " +
                ",GPS " +
                ",Comments " +
                ",BranddocsCertificatePath " +
                ",ClientNotified " +
                ",CustomerTechnicalInfo " +
                ",DateCallEnded " +
                ",ServiceCountry " +
                ",LanguageDocument " +
                ",VE.VideoControlID " +
                ",VEI.StatusCode as StCode " +
                ",VEI.Title " +
                ",VEI.OS  as OST" +
                ",VEI.Device as DeviceT " +
                ",VEI.Browser as BrowserT " +
                ",EV.Image " +
                ",EV.Video " +
                ",IC.Language " +
            "FROM VideoIdentification VI " +
            "left outer join (SELECT * FROM VE WHERE dp = '1') VE on VI.ID = VE.VideoIdentificationID "+
            "left outer join (SELECT * FROM VEI WHERE dp = '1') VEI on VI.ID = VEI.IdVideoIdentification " +
                "left outer join (SELECT * FROM IC WHERE dp = '1') IC on VI.ID = IC.VideoIdentificationID AND  VI.VideoApplicationID = IC.VideoPlatformCallId  " +
                "left outer join Evidn EV on VI.ID = EV.ID ")

            df.createOrReplaceTempView("STC")

            print("Proceso ETL 5")

            dfc = spark.sql(    
                "SELECT DISTINCT " +
                    "ROW_NUMBER() OVER(ORDER BY FechaURL ASC, Nro_Clientes ASC, VI.DateCreated DESC) AS ID, " +
                    "Nro_Clientes, " +
                    "VI.ID as LlamadaId, " +
                    "VI.DocNumber AS Documento, " +
                    "Agent AS Agente, " +
                    "FechaURL, " +
                    "VI.DateCreated as Hora_URL, " +
                    "VI.VideoDuration as AHT, " +
                    "ClientReference AS IBAN, " +
                    "CASE VerificationStatus " +
                        "WHEN 'NQ' THEN 'KO' " +
                        "ELSE VerificationStatus " +
                    "END AS Status, " +
                    "CASE  " +
                        "WHEN VerificationStatusDescription = '5' THEN  " +
                            "CASE VI.VideoControlID " +
                                "WHEN '1' THEN '51' " +
                                "WHEN '2' THEN '52' " +
                                "WHEN '3' THEN '53' " +
                                "WHEN '22' THEN '54' " +
                                "ELSE '54' " +
                            "END " +
                        "WHEN VerificationStatusDescription = '5, 3' THEN '53' " +
                        "WHEN VerificationStatusDescription = '5, 6' THEN '6' " +
                        "WHEN VerificationStatusDescription = '5, 10' THEN '10' " +
                        "WHEN VerificationStatusDescription = '' THEN " +
                        "CASE STRING(VI.StCode)" +
                        "WHEN '56' THEN " +
                            "CASE VI.Title " +
                                                "WHEN 'CODEC_NOT_SUPPORTED' THEN '58' " +
                                                "ELSE '56'	" +
                                            "END " +
                                "ELSE STRING(VI.StCode) " +
                            "END " +
                        "WHEN VerificationStatusDescription IS NULL THEN " +
                            "CASE STRING(VI.StCode)  " +
                                "WHEN '56' THEN " +
                                            "CASE VI.Title " +
                                                "WHEN 'CODEC_NOT_SUPPORTED' THEN '58' " +
                                                "ELSE '56' " +	
                                            "END " +
                            "ELSE STRING(VI.StCode) " +
                            "END " +
                        "ELSE VerificationStatusDescription " +
                    "END AS StatusCode, " + 
                "CASE " + 
                        "WHEN VerificationStatusDescription = '0' THEN 'KO /Técnico' " +
                        "WHEN VerificationStatusDescription = '15' THEN 'OK (15)' " +
                        "WHEN VerificationStatusDescription = '5' THEN  " +
                            "CASE  VI.VideoControlID " +
                                "WHEN '1' THEN 'KO /No se ve bien al usuario (est.51)' " +
                                "WHEN '2' THEN 'KO /No se oye bien al usuario (est.52)' " +
                                "WHEN '3' THEN 'KO /No se ve ni se oye bien al usuario (est.53)' " +
                                "WHEN '22' THEN 'KO /Conectividad insuficiente del usuario (est.54)' " +
                                "ELSE  " +
                                    "CASE VerificationStatusDescription " +
                                        "WHEN '5, 3' THEN 'KO /No se ve ni se oye bien al usuario (est.53)' " +
                                        "WHEN '5, 6' THEN 'KO /Elemento ID no Disponible (est.6)' " +
                                        "WHEN '5, 10' THEN 'KO /Imagen no OK (est.10)' " +
                                        "ELSE 'KO /Conectividad insuficiente del usuario (est.54)' " +
                                    "END " +
                            "END " +
                        "WHEN VerificationStatusDescription = '' THEN " +
                            "CASE STRING(VI.StCode) " +
                                "WHEN '55' THEN 'KO /No se concedieron los permisos necesarios (est.55)' " +
                                "WHEN '56' THEN " +
                                            "CASE VI.Title " +
                                                "WHEN 'CODEC_NOT_SUPPORTED' THEN 'KO /Codec no soportado (est.58)' " +
                                            "ELSE 'KO /Hardware no detectado (est.56)' " +
                                            "END " +
                                "WHEN '57' THEN 'KO /No se pudo establecer la conexión (est.57)' " +		
                            "END " +
                        "WHEN VerificationStatusDescription IS NULL THEN " +
                            "CASE STRING(VI.StCode) " +
                                "WHEN '55' THEN 'KO /No se concedieron los permisos necesarios (est.55)' " +
                                "WHEN '56' THEN  " +
                                            "CASE VI.Title " +
                                                "WHEN 'CODEC_NOT_SUPPORTED' THEN 'KO /Codec no soportado (est.58)' " +
                                                "ELSE 'KO /Hardware no detectado (est.56)'	 " +
                                            "END " +
                                "WHEN '57' THEN 'KO /No se pudo establecer la conexión (est.57)'  " +		
                            "END " +
                    "ELSE VerificationStatus || ' /' || " + 
                                "CASE  substr(VerificationStatusDescription, 1, 2) " +
                                    "WHEN '9,' THEN 'Número de ID no coincide' " +
                                    "WHEN '8,' THEN 'Nombre y apellidos erróneos' " +
                                    "WHEN '3,' THEN 'Videoconferencia Cancelada' " +
                                    "WHEN '6,' THEN 'Elemento ID no Disponible' " +
                                    "WHEN '7,' THEN 'Nombre y apellidos no coinciden' " +
                                    "WHEN '5,' THEN 'Conectividad Insuficiente Usuario' " +
                                    "WHEN '9' THEN 'Número de ID no coincide' " +
                                    "WHEN '8' THEN 'Nombre y apellidos erróneos' " +
                                    "WHEN '3' THEN 'Videoconferencia Cancelada' " +
                                    "WHEN '6' THEN 'Elemento ID no Disponible' " +
                                    "WHEN '7' THEN 'Nombre y apellidos no coinciden' " +
                                    "WHEN '5' THEN 'Conectividad Insuficiente Usuario' " +
                                    "WHEN '11' THEN 'ID deteriorado' " +
                                    "WHEN '10' THEN 'Imagen no OK' " +
                                    "WHEN '12' THEN 'ID Manipulado' " +
                                    "WHEN '13' THEN 'Elemento ID Caducado' " +
                                    "WHEN '14' THEN 'Persona No Se Parece' " +
                                    "WHEN '17' THEN 'No Apto' " +
                                "ELSE  substr(VerificationStatusDescription, 1, 2) " +
                                    "END " +
                                " || ' (est.' || substr(VerificationStatusDescription, 1, 2) || ')' " +
                    "END AS Resultado_Llamada, " +
                "nvl(Device, VI.DeviceT) AS Device, " +
                "nvl(OS, VI.OST) AS OS, " +
                "nvl(Browser, VI.BrowserT) AS Browser, " +
                "ServiceCountry, " +
                "VI.Image, " +
                "VI.Video, " +
                "LanguageDocument, " +
                "VI.Language " +
                "FROM Calls " +
                "INNER JOIN STC VI ON Calls.DocNumber = VI.DocNumber AND to_date(VI.DateCreated, 'yyyy-MM-dd') = Calls.FechaURL " +
                "INNER JOIN BranddocsFile BF ON BranddocsFileID = BF.ID " +
            "WHERE	VerificationStatus <> 'NQ' 	" +
                    "OR (SELECT count(statusCode) FROM VideoIdentificationPreCallTestLite WHERE IdVideoIdentification = VI.ID) > 0 " +
            "ORDER BY Hora_URL ASC, Nro_Clientes ASC"

            )

            print("Proceso ETL 6")
            tcall = spark.sql( "SELECT  *, "  +
                    " dense_rank() OVER (PARTITION BY VideoIdentificationId ORDER BY DateCreated DESC) AS rank " +
                " FROM IncomingCall  where  RecordingId <> '00000000-0000-0000-0000-000000000000' AND RecordingId <> '' " )
                
            tcall.createOrReplaceTempView("Caller")
            dfs["videoidentification"].createOrReplaceTempView("VideoIdentifica")

            print("Proceso ETL 7")
            sla = spark.sql("select	vi.ID as LlamadaId,  " +
                    "vi.docnumber, " +
                    "to_date(VI.DateCreated, 'yyyy-MM-dd') as Fecha_URL, " +
                    "IC.DateCreated as Hora_URL, " +
                    "IC.Date as Hora_Atendida, " +
                    " unix_timestamp(ic.Date) - unix_timestamp(ic.Datecreated) AS SLA, " +
                    "Verificationstatus " +
                "from	VideoIdentifica VI " +
                        "left join (select * from Caller WHERE rank = 1 ) IC" +
            " on VI.ID = IC.VideoIdentificationId and VI.Agent = IC.AgentId and (VI.VideoApplicationID = IC.VideoPlatformCallId OR VI.VideoApplicationID IS NULL) " +
                "where vi.VideoApplicationPlatform = 'TokBox' " +
                    "and VerificationStatus <> 'NQ'  "   )     
                    
            dfc.createOrReplaceTempView("CallFinal")
            sla.createOrReplaceTempView("SLA")

            print("Proceso ETL 8")     
            dfcFinal = spark.sql("SELECT C.ID as Id, " +
            "C.Nro_Clientes, " +
            "C.IBAN, " +
            "C.FechaURL, " +
            "C.Hora_URL, " +
            "S.SLA, " +
            "CASE C.Status WHEN 'OK' THEN 1 WHEN 'KO' THEN 0 END AS Status, " + 
            "C.StatusCode, " +
            "C.ServiceCountry, " +
            "INT(C.Image), " +
            "INT(C.Video), " +
            "C.Agente, " +
            "C.AHT, " +
            "C.Documento " +
            " FROM CallFinal C LEFT OUTER JOIN SLA S ON C.LlamadaId = S.LlamadaId ORDER BY Id ASC")

        

            dfcFinal = dfcFinal.withColumn("id", col("id").cast("int")) \
                .withColumn("nro_clientes", col("nro_clientes").cast("int")) \
                .withColumn("iban", col("iban").cast("string")) \
                .withColumn("fechaurl", col("fechaurl").cast("date")) \
                .withColumn("hora_url", col("hora_url").cast("timestamp")) \
                .withColumn("sla", col("sla").cast("bigint")) \
                .withColumn("status", col("status").cast("int")) \
                .withColumn("statuscode", col("statuscode").cast("string")) \
                .withColumn("servicecountry", col("servicecountry").cast("string")) \
                .withColumn("image", col("image").cast("int")) \
                .withColumn("video", col("video").cast("int")) \
                .withColumn("agente", col("agente").cast("string")) \
                .withColumn("aht", col("aht").cast("int")) \
                .withColumn("documento", col("documento").cast("string")) \
                .withColumn("year", date_format(col("fechaurl"), "yyyy")) \
                .withColumn("month", date_format(col("fechaurl"), "MM"))

            print("Guardar Llamadas")  

            dfcFinal = dfcFinal.withColumn("TypeId",lit(1))
            dfs["calls"] = dfcFinal


            print("Guardar Estados")  
            estados = dfc.select("StatusCode", "Resultado_Llamada").distinct().withColumn("statuskey",row_number().over(Window.partitionBy().orderBy("StatusCode")))


            estadosfinal = estados.withColumn("statuskey", col("statuskey").cast("int")) \
                .withColumn("statuscode", col("statuscode").cast("string")) \
                .withColumn("resultado_llamada", col("resultado_llamada").cast("string"))
                
            estadosfinal = estadosfinal.select("statuskey","statuscode", "resultado_llamada")
            estadosfinal = estadosfinal.withColumn("TypeId",lit(1))
            dfs["status"] = estadosfinal

            agentes = dfc.filter(dfc.Agente.isNotNull()).select("Agente").distinct().withColumn("Id",row_number().over(Window.partitionBy().orderBy("Agente")))

            agentes = agentes.withColumn("id", col("id").cast("int")) \
                .withColumnRenamed("agente", "nombre")


   
            
            agentes = agentes.select("id", "nombre")

            agentes = agentes.withColumn("TypeId",lit(1))
            
            dfs["agent"]    = agentes     
        

            a =  CertificadoVideo.select("ID", "Fecha","Certificado",lit("Video Certificado").alias("Tipo"),lit("Evidencia Video").alias("Categoria"))

            b =  EvidenciasVideo.select("ID", "Fecha",lit(" ").alias("Certificado"), lit("Video Evidencia").alias("Tipo"), "Categoria")

            c =  FirmaCertVideo.select("ID", "Fecha",lit(" ").alias("Certificado"), lit("Firma").alias("Tipo"),lit("Firma Digital").alias("Categoria"))

            d =  Uploads.select("ID", "Fecha",lit(" ").alias("Certificado"), lit("Upload").alias("Tipo"),lit("Upload").alias("Categoria"))


            evidences = a.union(b).union(c).union(d)


            dfe = evidences.groupby("Fecha","Tipo","Categoria").agg({'ID':'count', 'Certificado':'count'}).withColumnRenamed("count(Certificado)", "Certificado").withColumnRenamed("count(ID)", "Evidencia").withColumn("Id",row_number().over(Window.partitionBy().orderBy("Fecha")))


            evidencesf = dfe.withColumn("id", col("id").cast("int")) \
                .withColumn("fecha", col("fecha").cast("date")) \
                .withColumn("tipo", col("tipo").cast("string")) \
                .withColumn("categoria", col("categoria").cast("string")) \
                .withColumn("certificado", col("certificado").cast("bigint")) \
                .withColumn("evidencia", col("evidencia").cast("bigint"))  \
                .withColumn("year", date_format(col("fecha"), "yyyy")) \
                .withColumn("month", date_format(col("fecha"), "MM"))
                
            
            evidencesf = evidencesf.select("id","fecha","tipo","categoria", "certificado", "evidencia")

            dfs["consumption"] = evidencesf
        except  Exception as e:
                    print(e)

        return dfs

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            
            "calls": {"table": dfs.get('calls'), "type": "fact", "path": "ob/va/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "status": {"table": dfs.get('status'), "type": "dm", "path": "ob/va/", "version": "/v1", 'merge_conditions': 'source.statuskey == target.statuskey AND source.statuscode == target.statuscode'},
            "agent": {"table": dfs.get('agent'), "type": "dm", "path": "ob/va/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id AND source.nombre == target.nombre'},
            "consumption": {"table": dfs.get('consumption'), "type": "fact", "path": "ob/va/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id AND source.Fecha == target.Fecha'}
        }


        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items() if v['table'] is not None}

        return dfs_dict
   