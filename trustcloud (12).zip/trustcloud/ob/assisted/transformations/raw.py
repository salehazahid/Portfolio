from pyspark.sql import DataFrame
from pyspark.sql.functions import current_timestamp



class BOtRawTransformation():

    
    
    @staticmethod
    def get_raw_table(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.
        
        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
        .withColumn("ActivityDate", current_timestamp())  # Crea/modifica la columna 'ActivityDate' con el timestamp actual
        )
    
        return df_transformed
 

    