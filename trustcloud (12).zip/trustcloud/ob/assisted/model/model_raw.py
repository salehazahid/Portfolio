from trustcloud.aws_glue import Pipeline
from ..transformations.raw import BOtRawTransformation

OB_MODEL = {
    "source_paths": {

        'videoidentification': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        },

        'videoidentificationprecalltestlite': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        },

        'videonotificationstatusclient': {
            'function': lambda df: BOtRawTransformation.get_raw_table(df),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc",
            "dm" : True
        },

        'branddocsfile': {
            'function': lambda df: BOtRawTransformation.get_raw_table(df),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc",
            "dm" : True
        },

        'incomingcall': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        },

        'videoidentificationstatus': {
            'function': lambda df: BOtRawTransformation.get_raw_table(df),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc",
            "dm" : True
        },

        'videoevidence': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        },

        'otherdocumentation': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        },

        'signingevidence': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/va/',
            "version": "/v1",
            "type": "jdbc"
        }
    },

    "delta_paths": {
        "videoidentification": {"path": "ob/va/videoidentification/", "filter": True},
        "videoidentificationprecalltestlite": {"path": "ob/va/videoidentificationprecalltestlite/", "filter": True},
        "videonotificationstatusclient": {"path": "ob/va/videonotificationstatusclient/", "filter": True, "type": "dm"},
        "branddocsfile": {"path": "ob/va/branddocsfile/", "filter": True, "type": "dm"},
        "incomingcall": {"path": "ob/va/incomingcall/", "filter": True},
        "videoidentificationstatus": {"path": "ob/va/videoidentificationstatus/", "filter": True, "type": "dm"},
        "videoevidence": {"path": "ob/va/videoevidence/", "filter": True},
        "otherdocumentation": {"path": "ob/va/otherdocumentation/", "filter": True},
        "signingevidence": {"path": "ob/va/signingevidence/", "filter": True}
    }
}
