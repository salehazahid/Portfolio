from trustcloud.aws_glue import Pipeline
from trustcloud.aws_glue.config.etl_config import load_config
from trustcloud.ob.assisted.model.model_raw import OB_MODEL
from trustcloud.ob.assisted.transformations import OBCuratedTransformation


def run_etl(**kwargs):
    """
    Execute the ETL (Extract, Transform, Load) pipeline.

    This function orchestrates the execution of the RAW and CURATED ETL processes in sequence.
    The RAW process extracts data from the source, transforms it, and loads it into the RAW layer of the data lake.
    The CURATED process extracts data from the RAW layer, transforms it, and loads it into the CURATED layer of the data lake.

    Parameters:
    :param spark (pyspark.sql.session.SparkSession, optional): Spark session object. Defaults to None.
    :param bucket_in (str, optional): S3 bucket where the input data is stored. Defaults to None.
    :param bucket_out (str, optional): S3 bucket where the output data will be stored. Defaults to None.
    :param partitions (int, optional): Number of partitions to use when writing data. Defaults to None.
    :param connections (dict, optional): Dictionary of database connections. Defaults to None.
    :param env (str, optional): Environment ('dev', 'prod', etc.). Defaults to None.
    :param etl_type (str, optional): Type of ETL process to run ('raw', 'curated', or 'both'). Default is 'both'.
    :param days (int, optional): Number of days for which to run the ETL. Defaults to None.
    :param hour (int, optional): Specific hour at which to run the ETL. Defaults to None.
    :param minutes (int, optional): Specific minute at which to run the ETL. Defaults to None.
    :param dimensions (bool, optional): Flag to determine whether to run dimensional processing. Defaults to False.
    :param islocal (bool, optional): Flag to determine if the ETL is run locally. Defaults to False.

    Returns:
    None

    Raises:
    Exception: An exception can be thrown if ETL processing fails.

    """
    days = kwargs.get("days", None)
    hours = kwargs.get("hours", None)
    minutes = kwargs.get("minutes", None)
    dimensions = kwargs.get("dimensions", False)
    etl_type = kwargs.get("etl_type", "both")
    islocal = kwargs.get("islocal", False)
    env = kwargs.get("env", "pro")
    transformation_layers = [OBCuratedTransformation]
    job, spark, connections, bucket_in, bucket_out, partitions, env = load_config(islocal=islocal, env = env)
    result = False
    if etl_type in ["raw", "both"]:

        result = Pipeline.run(spark=spark,
                              bucket=bucket_in,
                              bucket_in = bucket_in,
                              partitions=["year", "month"],
                              connections=connections,
                              processing_map=OB_MODEL.get("source_paths"),
                              layer="raw",
                              days=days,
                              hours=hours,
                              minutes=minutes,
                              dimensions=dimensions,
                              product='ob_va'
                              )

    # RUN CURATED ETL PROCESS
    """
    Extract data from the RAW layer, transform it, and load it into the CURATED layer of the data lake.
    """
    if etl_type in ["curated", "both"]:

        Pipeline.run(spark=spark,
                     bucket_in=bucket_in,
                     bucket_out=bucket_out,
                     partitions=["year", "month"],
                     connections=connections,
                     table_paths=OB_MODEL.get("delta_paths"),
                     layer="curated",
                     transformation_layers = transformation_layers,
                     date_event= result,
                     dimensions=dimensions,
                     product='ob_va')

    job.commit()
