from pyspark.sql import DataFrame
from pyspark.sql.functions import current_timestamp


class OBVURawTransformation():

    @staticmethod
    def transform(dfs, spark=None):

        return dfs

    @staticmethod
    def get_raw_table(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.

        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.

        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
            # Crea/modifica la columna 'ActivityDate' con el timestamp actual
            .withColumn("ActivityDate", current_timestamp())
        )

        return df_transformed

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {

            "identificationrequest": {"table": dfs.get('identificationrequest'), "type": "fact", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "identification": {"table": dfs.get('identification'), "type": "fact", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "identificationstatus": {"table": dfs.get('identificationstatus'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "identificationstatusclient": {"table": dfs.get('identificationstatusclient'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'},
            "identificationevidence": {"table": dfs.get('identificationevidence'), "type": "fact", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id == target.Id'}

        }

        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items()
                    if v['table'] is not None}

        return dfs_dict
