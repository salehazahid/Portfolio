from pyspark.sql import DataFrame
from pyspark.sql.functions import current_timestamp, date_format, col, lit, lpad, from_utc_timestamp, hour, year, month, concat_ws, dayofmonth


class OBVUCuratedTransformation():

    @staticmethod
    def transform(dfs, spark=None):

        if "identificationrequest" in dfs:
            dfs["identificationrequest"].createOrReplaceTempView("IdentificationRequest")

        if "identification" in dfs:
            dfs["identification"].createOrReplaceTempView("Identification")

        if "identificationstatus" in dfs:
            dfs["identificationstatus"].createOrReplaceTempView("IdentificationStatus")

        if "identificationstatusclient" in dfs:
            dfs["identificationstatusclient"].createOrReplaceTempView("IdentificationStatusClient")

        if "identificationevidence" in dfs:
            dfs["identificationevidence"].createOrReplaceTempView("IdentificationEvidence")

        if "branddocsfile" in dfs:
            dfs["branddocsfile"].createOrReplaceTempView("BranddocsFile")

        calls = spark.sql(
            """
                WITH	UnassistedCalls
                AS (
                    SELECT CAST(DateCreated AS DATE) AS Fecha,
                            RANK() OVER(PARTITION BY CAST(DateCreated AS DATE) ORDER BY I.DocNumber) AS Nro_Clientes,
                            I.DocNumber
                    FROM	Identification I
                                INNER JOIN IdentificationRequest IR ON IR.TransactionContextId = I.ID
                    GROUP BY CAST(DateCreated AS DATE), I.DocNumber
                )
                
                SELECT	DISTINCT
                        ROW_NUMBER() OVER(ORDER BY Fecha ASC, Nro_Clientes ASC, DateCreated DESC) AS ID,
                        Fecha,
                        Nro_Clientes,
                        ID AS IdentificationId,
                        ClientReference AS IBAN,
                        Name AS Nombre,
                        Surname1 AS Apellido1,
                        Surname2 AS Apellido2,
                        DocNumber AS Documento,
                        DocType,
                        DateCreated AS FechaHora,
                        StatusCode,
                        StatusDescription AS Resultado_Llamada,
                        ServiceCountry,
                        LanguageDocument,
                        StatusBackOffice,
                        DateBackOffice AS FechaBackOffice,
                        UserBackOffice AS UsuarioBackOffice,
                        StatusDescBackOffice,
                        Device,
                        Browser
                FROM	(
                            SELECT	DISTINCT
                                    Fecha,
                                    Nro_Clientes,
                                    I.ID,
                                    ClientReference,
                                    I.Name,
                                    I.Surname1,
                                    I.Surname2,
                                    I.DocNumber,
                                    I.DocType,
                                    DateCreated,
                                    VerificationStatus,
                                    COALESCE(IdentificationStatusID, VerificationStatusDescription) AS StatusCode,
                                    StatusDescription,
                                    ServiceCountry,
                                    LanguageDocument,
                                    StatusBackOffice,
                                    DateBackOffice,
                                    UserBackOffice,
                                    StatusDescBackOffice,
                                    Device,
                                    Browser
                            FROM	UnassistedCalls
                                        INNER JOIN Identification I ON UnassistedCalls.DocNumber = I.DocNumber AND CAST(DateCreated AS DATE) = Fecha
                                        INNER JOIN BranddocsFile BF ON BranddocsFileID = BF.ID
                                        LEFT JOIN (
                                                SELECT IdentificationID, IdentificationStatusID, StatusDescription
                                                FROM	IdentificationStatus
                                                            INNER JOIN IdentificationStatusClient ISC ON IdentificationStatusID = ISC.ID
                                                WHERE	IdentificationStatusID <> 16
                                                UNION
                                                SELECT	ID, COALESCE(VerificationStatusDescription, 26), 
                                                CASE COALESCE(VerificationStatusDescription, 26)
                                                    WHEN 15 THEN 'OK'
                                                    WHEN 26 THEN 'Verificación incorrecta del motor'
                                                END
                                                FROM	Identification
                                                WHERE	((VerificationStatus = 'KO' AND VerificationStatusDescription NOT IN ('15', '25') AND DateVideoCreated < '20210728') OR (VerificationStatus = 'OK' AND VerificationStatusDescription = 15)) --AND DateVideoCreated < '20210728'
                                        ) A ON I.ID = A.IdentificationID 
                            WHERE	COALESCE(VerificationStatus, 'NQ') NOT IN ('NQ', 'UNDEFINED')
                        UNION
                            SELECT	CAST(IR.RecordCreationDate AS DATE) AS Fecha, 
                                    Nro_Clientes,
                                    I.ID, 
                                    BF.ClientReference, 
                                    I.Name, 
                                    I.Surname1, 
                                    I.Surname2, 
                                    I.DocNumber, 
                                    I.DocType,
                                    IR.RecordCreationDate,
                                    'NQ',
                                    NULL,
                                    'Abandono con vídeo',
                                    I.ServiceCountry, 
                                    I.LanguageDocument,
                                    StatusBackOffice,
                                    DateBackOffice,
                                    UserBackOffice,
                                    StatusDescBackOffice,
                                    IR.Device,
                                    IR.Browser
                            FROM	UnassistedCalls
                                        INNER JOIN Identification I ON UnassistedCalls.DocNumber = I.DocNumber 
                                        INNER JOIN IdentificationRequest IR ON I.ID = IR.TransactionContextId
                                        INNER JOIN BranddocsFile BF ON I.BranddocsFileID = BF.ID
                            WHERE VerificationStatus IS NULL AND RecordingId IS NOT NULL AND CAST(IR.RecordCreationDate AS DATE) = Fecha
                        UNION
                            SELECT	CAST(IR.RecordCreationDate AS DATE) AS Fecha, 
                                    Nro_Clientes,
                                    I.ID as Id, 
                                    BF.ClientReference, 
                                    I.Name, 
                                    I.Surname1, 
                                    I.Surname2, 
                                    I.DocNumber, 
                                    I.DocType,
                                    IR.RecordCreationDate AS RecordCreationDate,
                                    'NQ',
                                    NULL,
                                    'Abandono sin vídeo',
                                    I.ServiceCountry, 
                                    I.LanguageDocument,
                                    StatusBackOffice,
                                    DateBackOffice,
                                    UserBackOffice,
                                    StatusDescBackOffice,
                                    IR.Device,
                                    IR.Browser
                            FROM	UnassistedCalls
                                        INNER JOIN Identification I ON UnassistedCalls.DocNumber = I.DocNumber 
                                        INNER JOIN IdentificationRequest IR ON I.ID = IR.TransactionContextId
                                        INNER JOIN BranddocsFile BF ON I.BranddocsFileID = BF.ID
                            WHERE VerificationStatus IS NULL AND RecordingId IS  NULL AND CAST(IR.RecordCreationDate AS DATE) = Fecha 
                        ) Unassisted
                ORDER BY Fecha ASC, Nro_Clientes ASC
                """
        )

        # Convert DateCreated from UTC to Central European Standard Time
        calls = calls.withColumn(
            "FechaHoraCEST", from_utc_timestamp("FechaHora", "Europe/Madrid"))

        calls = calls.withColumn("year", date_format(col("FechaHoraCEST"), "yyyy")) \
            .withColumn("month", date_format(col("FechaHoraCEST"), "MM")) \
            .withColumn("day", date_format(col("FechaHoraCEST"), "dd")) \
            .withColumn("hour", date_format(col("FechaHoraCEST"), "HH"))
            
        calls = calls.withColumn("DateKeyCest", concat_ws("", 
                                                    year(col("FechaHoraCEST")), 
                                                    lpad(month(col("FechaHoraCEST")), 2, '0'), 
                                                    lpad(dayofmonth(col("FechaHoraCEST")), 2, '0')))

        calls = calls.withColumn(
            "Day_of_week", date_format(col("FechaHoraCEST"), "EEEE"))
        
        calls = calls.withColumn( "TypeId",lit(2))
        dfs["calls"] = calls

        agent = calls.select("UsuarioBackOffice").distinct()
        agent = agent.withColumn( "TypeId",lit(2))

        dfs["agent"] = agent
        status = calls.select("StatusCode", col("Resultado_Llamada").alias("Status")).distinct()
        status = status.withColumn( "TypeId",lit(2))
        status = status.withColumn( "StatusKey",concat_ws("", col("StatusCode"),col("TypeId")))
        
        dfs["status"] = status

        Device = calls.select("Device").distinct()

        dfs["device"] = Device


        DocType = calls.select("DocType").distinct()

        dfs["doctype"] = DocType

        
        consumption = dfs["identificationevidence"].select(
            "ID", "IdentificationID", "Date", "CertificateExpiration", "Type", "LTACustodyID", "LTACustodyDate")
        
          # Convert DateCreated from UTC to Central European Standard Time
        consumption = consumption.withColumn(
            "DateCEST", from_utc_timestamp("Date", "Europe/Madrid"))

        consumption = consumption.withColumn("year", date_format(col("DateCEST"), "yyyy")) \
            .withColumn("month", date_format(col("DateCEST"), "MM")) \
            .withColumn("day", date_format(col("DateCEST"), "dd")) \
            .withColumn("hour", date_format(col("DateCEST"), "HH"))
            
        dfs["consumption"] =consumption
        
        type_ = [{"TypeId": 1, "Type": "Assisted"}, {"TypeId": 2, "Type": "Unassisted"}]
        type_ = spark.createDataFrame(type_)
        dfs["type"] =type_
        return dfs

    @staticmethod
    def get_raw_table(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.

        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.

        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
            # Crea/modifica la columna 'ActivityDate' con el timestamp actual
            .withColumn("ActivityDate", current_timestamp())
        )

        return df_transformed

    @staticmethod
    def get_processing_map(dfs):
        """
        Generates a processing map for given dataframes.

        Parameters:
        - dfs (dict): Dictionary containing all the required dataframes.

        Returns:
        dict: A dictionary containing the table name as key and its properties.
        """
        dfs_dict = {
            
            "calls": {"table": dfs.get('calls'), "type": "fact", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id = target.Id and source.IdentificationId = target.IdentificationId'},
            "agent": {"table": dfs.get('agent'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.UsuarioBackOffice = target.UsuarioBackOffice'},
            "status": {"table": dfs.get('status'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.StatusCode = target.StatusCode and source.Status = target.Status'},
            "consumption": {"table": dfs.get('consumption'), "type": "fact", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.Id = target.Id'},
            "doctype": {"table": dfs.get('doctype'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.doctype = target.doctype'},
            "device": {"table": dfs.get('device'), "type": "dm", "path": "ob/vu/", "version": "/v1", 'merge_conditions': 'source.device = target.device'},
            "type": {"table": dfs.get('type'), "type": "dm", "path": "ob/vu/", "version": "/v1"}


        }

        # Remove any items where the table is None
        dfs_dict = {k: v for k, v in dfs_dict.items()
                    if v['table'] is not None}

        return dfs_dict
