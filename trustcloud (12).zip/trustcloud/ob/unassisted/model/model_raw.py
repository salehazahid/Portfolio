from trustcloud.aws_glue import Pipeline
from ..transformations.raw import OBVURawTransformation

OB_MODEL = {
    "source_paths": {

        'identificationevidence': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "Date"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/vu/',
            "version": "/v1",
            "type": "jdbc"
        },


        'identification': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "DateCreated"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/vu/',
            "version": "/v1",
            "type": "jdbc"
        },


        'identificationstatus': {
            'function': lambda df: OBVURawTransformation.get_raw_table(df),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/vu/',
            "version": "/v1",
            "type": "jdbc",
            "dm": True
        },

        'identificationstatusclient': {
            'function': lambda df: OBVURawTransformation.get_raw_table(df),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/vu/',
            "version": "/v1",
            "type": "jdbc",
            "dm": True
        },


        'identificationrequest': {
            'function': lambda df, customer: Pipeline.get_raw_data(df, customer, "RecordCreationDate"),
            'merge_conditions': 'source.Id == target.Id',
            'path': 'ob/vu/',
            "version": "/v1",
            "type": "jdbc"
        },

    },

    "delta_paths": {
        "identificationrequest": {"path": "ob/vu/identificationrequest/", "filter": True},
        "identification": {"path": "ob/vu/identification/", "filter": True},
        "identificationstatus": {"path": "ob/vu/identificationstatus/", "filter": True, "type": "dm"},
        "identificationstatusclient": {"path": "ob/vu/identificationstatusclient/", "filter": True, "type": "dm"},
        "identificationevidence": {"path": "ob/vu/identificationevidence/", "filter": True},
        "branddocsfile": {"path": "ob/va/branddocsfile/", "filter": False}

    }
}
