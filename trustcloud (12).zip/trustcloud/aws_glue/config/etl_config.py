import sys
from ast import literal_eval
from awsglue.utils import getResolvedOptions
from datalake_cloud_unity.aws.spark import get_job, get_spark, spark_inst
import boto3

def get_current_account_id():
    # Crear un cliente STS
    sts_client = boto3.client('sts')

    # Obtener el identificador de la cuenta usando el cliente STS
    try:
        account_id = sts_client.get_caller_identity()["Account"]
    except Exception as e:
        print(f"Error al obtener el ID de la cuenta: {e}")
        return None

    return account_id




def load_config(**kwargs):
    """
    Configure and load initial settings for an AWS Glue job.
    
    :param islocal: Bool, whether the job is executed in local mode. Default is False.
    :param layer: str, the ETL process layer. Default is "raw".
    :param default: Bool, determine whether to use default settings. Default is False.
    :return: Tuple containing configurations and objects needed for the ETL process.
    """
    
    if not kwargs:
        raise ValueError("No arguments were provided to the function.")
    
    islocal = kwargs.get('islocal', False)
    default = kwargs.get('default', True)
    env = kwargs.get('env', 'pro')
    # Set default arguments if running locally
    if islocal:
        
        
        sys.argv.extend([
            '--JOB_NAME', 'ETL_test_Callss',
            '--connections', f"{env}/Datalake/VideoID",
            '--bucket_in', f'trustcloud-datalake-raw-euwest1-{get_current_account_id()}',
            '--bucket_out', f'trustcloud-datalake-raw-euwest1-{get_current_account_id()}',
            '--env', f'{env}/',
            '--parts1', '["appclient", "year", "month"]',
            '--parts2', '["appclient", "year", "month", "day","hour"]',
        ])
        spark = get_spark()

    # Get resolved options from arguments
    args = getResolvedOptions(sys.argv, [
        "JOB_NAME", "connections", "bucket_in", 'bucket_out', "env", "parts1", "parts2"
    ])

    # Assign variables from arguments
    job_name = args['JOB_NAME']
    connections =args['connections']
    bucket_in = args['bucket_in']
    bucket_out = args['bucket_out']
    partitions = literal_eval(args['parts1'])
    env = args['env']
    if not islocal:
        spark = spark_inst()

        spark.catalog.clearCache()

        spark.sql(f"REFRESH 's3a://trustcloud-datalake-raw-euwest1-375935085649/tc/va/videoidentifications'")
        
    job = get_job()
    job.init(job_name, args)

    return job, spark, connections, bucket_in, bucket_out, partitions, env
