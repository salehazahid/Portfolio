import json
import re
from collections import defaultdict
from functools import reduce
import logging

from pyspark.sql import DataFrame, SparkSession, Window

from pyspark.sql.functions import col, current_timestamp, date_format, lit, when, expr, regexp_extract, from_json, split, udf, row_number, desc
from pyspark.sql.types import *

from datalake_cloud_unity.aws.service import AwsManager
from datalake_transformation import read_jdbc, timer, write_aws, read_datalake, flatten, select_cols



def add_parition_columns(df: DataFrame, datetime_column, customer_value: str) -> DataFrame:
    """
    Añade las columnas relacionadas con la actividad a un DataFrame de PySpark. y particiones

    Parámetros:
        df (DataFrame): DataFrame original al que se le añadirán las columnas.
        customer_value (str): Valor para la columna 'appclient'.

    Devuelve:
        DataFrame: DataFrame con las columnas adicionales.
    """
    if datetime_column:
        df_transformed = (
            df
            
            .withColumn("year", date_format(col(datetime_column), "yyyy"))
            .withColumn("month", date_format(col(datetime_column), "MM"))
            .withColumn("day", date_format(col(datetime_column), "dd"))
            .withColumn("hour", date_format(col(datetime_column), "HH"))
            .withColumn("appclient", lit(customer_value))
        )
    else: 
         df_transformed = (
            df
            .withColumn("appclient", lit(customer_value))
        )
    return df_transformed
    

class Pipeline():
 
    @staticmethod
    def get_raw_data(df, customer, column_datetime="DateCreated", table_name=None):
        """
        Adds partition columns to the DataFrame based on the provided customer value.
        
        Args:
        - df (pyspark.sql.DataFrame): Original DataFrame.
        - customer (str): Value for the 'appclient' column to be used in partitioning.
        - column_datetime (str): Name of the datetime column in the df.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        #if 'TaxID' in df.columns:
            #df = df.drop('TaxID')
        from pyspark.sql import SparkSession

        spark = SparkSession.builder.getOrCreate()
        
        spark.catalog.clearCache()
        
        if table_name == "videoidentifications":
            if 'TaxID' not in df.columns:
                logging.info("Adding 'TaxID' as NULL for historical data")
                df = df.withColumn('TaxID', lit(None).cast("string"))  # Ensure 'Taxid' exists for all data
            
        return add_parition_columns(df=df, datetime_column=column_datetime, customer_value=customer)
    
    @staticmethod
    def get_landing_data(spark:SparkSession, df: DataFrame, trustcloud_type: str, env="pro"):
        """
        Processes a DataFrame containing DynamoDB events, assumed to be from the landing layer of the datalake. 
        This function transforms the data for loading into the raw layer. It extracts JSON content, filters the data 
        based on a specified TrustCloud event type, and cleans up column names by removing designated prefixes and substrings. 
        The result is a standardized DataFrame suitable for further processing and analysis.

        Parameters:
        spark (SparkSession): Spark session instance.
        df (DataFrame): The input DataFrame with DynamoDB data.
        trustcloud_type (str): The specific type of TrustCloud event to filter by.

        Returns:
        DataFrame: A transformed DataFrame with cleaned column names and data filtered as specified.
        """
        
        def handle_dynamodb_json_string(dbjson_string):
            """
            Helper function to format a dynamodb json string to a regular python json string
            """
    
            def convert_dynamodb_to_regular(dynamodb_data):
                if isinstance(dynamodb_data, dict):
                    # Check for DynamoDB type annotations and extract the value
                    if "N" in dynamodb_data:
                        return int(dynamodb_data["N"])
                    elif "S" in dynamodb_data:
                        return dynamodb_data["S"]
                    elif "BOOL" in dynamodb_data:
                        return bool(dynamodb_data["BOOL"])
                    elif "NULL" in dynamodb_data:
                        return None
                    elif "L" in dynamodb_data:
                        # Process lists within dictionaries
                        return [convert_dynamodb_to_regular(element) for element in dynamodb_data["L"]]
                    elif "M" in dynamodb_data:
                        # Process maps within dictionaries
                        return {key: convert_dynamodb_to_regular(value) for key, value in dynamodb_data["M"].items()}
                    # Recursively process nested dictionaries
                    return {key: convert_dynamodb_to_regular(value) for key, value in dynamodb_data.items()}
                elif isinstance(dynamodb_data, list):
                    # Recursively process lists
                    return [convert_dynamodb_to_regular(element) for element in dynamodb_data]
                else:
                    return dynamodb_data
                
            # Fix some formatting issues
            dbjson_string = re.sub(r'"n"', '"N"', dbjson_string)
            dbjson_string = re.sub(r'"s"', '"S"', dbjson_string)
            dbjson_string = re.sub(r'"bool"', '"BOOL"', dbjson_string)
            dbjson_string = re.sub(r'"null"', '"NULL"', dbjson_string)
            dbjson_string = re.sub(r'"l"', '"L"', dbjson_string)
            dbjson_string = re.sub(r'"m"', '"M"', dbjson_string)
            
            # Parse DynamoDB JSON string using json.loads
            dynamodb_data = json.loads(dbjson_string)

            # Convert DynamoDB JSON to regular JSON
            regular_json_data = convert_dynamodb_to_regular(dynamodb_data)

            # Convert the resulting Python object back to a JSON string
            regular_json_string = json.dumps(regular_json_data, indent=2)
            
            regular_json_string.replace('\n', '')
            output_string = ''.join(regular_json_string.split())
            return output_string
        
        
        pattern = r'"type":\{"s":"([^"]+)"\}'
        df = df.withColumn('ModuleType', regexp_extract(col('dynamodb'), pattern, 1))
        df = df.filter(f"ModuleType == '{trustcloud_type}'")
        
        # Register the UDF
        to_json_udf = udf(handle_dynamodb_json_string, StringType())

        # Apply the UDF to the DataFrame column
        df = df.withColumn("dynamodb", to_json_udf("dynamodb"))

        extracted_json_df = spark.read.json(df.rdd.map(lambda row: row.dynamodb))
        json_schema = extracted_json_df.schema
        df = df.withColumn('dynamodb', from_json(col('dynamodb'), json_schema))
        df = df.withColumn('appclient',split(col("eventsourcearn"),"/").getItem(1)) 
        df = flatten(df)
        df = df.drop('type') # Drop the type column as it will be a duplicate once we flatten

        # Fix any columns names
        prefixes = ['dynamodb_', 'newimage_', 'events_']
        for column in df.columns:
            new_name = column
            for prefix in prefixes:
                new_name = new_name[len(prefix):] if new_name.startswith(prefix) else new_name
            df = df.withColumnRenamed(column, new_name)
         
        # The event data that we are currently ingesting has a row for each action performed on the dynamodb entry. Therefore there are multiple
        # rows with the same key because that data would have been modified. We only want to ingest the most recent entry so we sort and keep the latest   
        window_spec = Window.partitionBy("id").orderBy(desc("approximatecreationdatetime"))
        df = df.withColumn("row_number", row_number().over(window_spec))
        df = df.filter("row_number = 1").drop("row_number")
        
        
        raw_column_names = [
            'id', #unique identifier   
            'trustcloudfileid',
            'backdocumentpath',
            'callbackurl',
            'clientreference',
            'engine',
            'eventtimestamp',
            'facedocumentpath',
            'frontdocumentpath',
            'reference',
            'status',
            'summarydocumentpath',
            'timestamp',
            'trustcloudidentityid',
            'ModuleType',
            'usecaseid',
            'usecasename',
            'iddocumentprocessentitydata_address',
            'iddocumentprocessentitydata_authority',
            'iddocumentprocessentitydata_birthdate',
            'iddocumentprocessentitydata_birthplace',
            'iddocumentprocessentitydata_city',
            'iddocumentprocessentitydata_concordanceratio',
            'iddocumentprocessentitydata_documentnumber',
            'iddocumentprocessentitydata_documentprocessresult',
            'iddocumentprocessentitydata_error',
            'iddocumentprocessentitydata_expeditor',
            'iddocumentprocessentitydata_expirydate',
            'iddocumentprocessentitydata_facematchresult',
            'iddocumentprocessentitydata_id',
            'iddocumentprocessentitydata_idcountry',
            'iddocumentprocessentitydata_identificationnumber',
            'iddocumentprocessentitydata_idtype',
            'iddocumentprocessentitydata_issuingdate',
            'iddocumentprocessentitydata_modelid',
            'iddocumentprocessentitydata_mrz',
            'iddocumentprocessentitydata_name',
            'iddocumentprocessentitydata_nationality',
            'iddocumentprocessentitydata_parents',
            'iddocumentprocessentitydata_serviceproviderdocumentid',
            'iddocumentprocessentitydata_sex',
            'iddocumentprocessentitydata_side',
            'iddocumentprocessentitydata_sidesnumber',
            'iddocumentprocessentitydata_state',
            'iddocumentprocessentitydata_streetaddress',
            'iddocumentprocessentitydata_surname',
            'iddocumentprocessentitydata_warning',
            'iddocumentprocessentitydata_documentvalidationtest_colorimage',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzbirthdate',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzdocumentnumber',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzexpirydate',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzidentificationnumber',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzname',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzsex',
            'iddocumentprocessentitydata_documentvalidationtest_correspondencevisiblemrzsurname',
            'iddocumentprocessentitydata_documentvalidationtest_expirydate',
            'iddocumentprocessentitydata_documentvalidationtest_globalauthenticityratio',
            'iddocumentprocessentitydata_documentvalidationtest_identificationnumberchecksum',
            'iddocumentprocessentitydata_documentvalidationtest_isglobalauthenticityvalid',
            'iddocumentprocessentitydata_documentvalidationtest_mrzfieldbirthdate',
            'iddocumentprocessentitydata_documentvalidationtest_mrzfielddocumentnumber',
            'iddocumentprocessentitydata_documentvalidationtest_mrzfieldexpirydate',
            'iddocumentprocessentitydata_documentvalidationtest_mrzglobalintegrity',
            'iddocumentprocessentitydata_documentvalidationtest_sidecorrespondence',
            'iddocumentprocessentitydata_facematchtest_ratio',
            'iddocumentprocessentitydata_facematchtest_reason',
            'iddocumentprocessentitydata_facematchtest_result',
            'appclient',
            'year',
            'month',
            'day', 
            'hour'
            ]
        
        df = select_cols(df,raw_column_names)
        df = df.withColumnRenamed('ModuleType','type')
        # df = add_parition_columns(df=df, datetime_column='eventtimestamp',)

        return df
    

    @staticmethod
    def format_timestamp_column(df: DataFrame, timestamp_columns: list, customer: str) -> DataFrame:
        """
        Formats a timestamp column to have exactly 3 milliseconds of precision.
        
        Parameters:
            df (DataFrame): The original DataFrame.
            timestamp_column (str): The name of the timestamp column to format.
        
        Returns:
            DataFrame: The DataFrame with the formatted timestamp column.
        """
        
        for timestamp_column in timestamp_columns:
            df = df.withColumn(
                timestamp_column,
                when(
                    expr(f"year({timestamp_column}) >= 1000"),  # Suponiendo que cualquier año menor a 1000 es incorrecto
                    col(timestamp_column)
                )
                .otherwise(None)
            )
    
        # Choose one of the timestamp columns as the column for partitioning.
        # This is just an example. Modify it based on your actual requirements.
        partition_column = timestamp_columns[0] if timestamp_columns else "CreationDate"
        df_transformed = add_parition_columns(df=df, datetime_column=partition_column, customer_value=customer)
        
        return df_transformed
    
    
    @staticmethod
    def get_raw_customers(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.
        
        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
        .withColumn("ActivityDate", current_timestamp())  # Crea/modifica la columna 'ActivityDate' con el timestamp actual
        )
    
        return df_transformed
    
    @staticmethod
    def get_raw_agents(df) -> DataFrame:
        """
        Adds partition columns to the evidences DataFrame based on the provided customer value.
        
        Args:
        - df_evidences (pyspark.sql.DataFrame): Original DataFrame containing evidence data.
        - customer (str): Customer value for partitioning.
        
        Returns:
        - pyspark.sql.DataFrame: Transformed DataFrame with added partition columns.
        """
        df_transformed = (
            df
        .withColumn("ActivityDate", current_timestamp())  # Crea/modifica la columna 'ActivityDate' con el timestamp actual
        )
    
        return df_transformed
    
    @staticmethod
    def __validate_parameters(kwargs):
        """
        Validates if the required parameters are present in the given keyword arguments.

        Args:
            kwargs (dict): A dictionary of keyword arguments.

        Raises:
            ValueError: If required parameters are not provided.
        """
        if kwargs.get("layer") in ["raw", "landing"]:
            required_params = ['spark', 'bucket', 'bucket_in','connections', 'layer', 'processing_map', 'product']
        else:
            required_params = ['spark', 'bucket_in', 'bucket_out', 'partitions', 'date_event', 'table_paths', 'transformation_layers', 'product']

        missing_params = [param for param in required_params if param not in kwargs]

        if missing_params:
            raise ValueError(f"Parameters {', '.join(missing_params)} must be provided.")
    @staticmethod
    def __extract_common_parameters(kwargs):
        """
        Extracts and returns common parameters required for the ETL pipeline from the given keyword arguments.

        Args:
            kwargs (dict): A dictionary of keyword arguments.

        Returns:
            tuple: A tuple containing various parameters required for the ETL.
        """
        common_params = {
            'spark': kwargs['spark'],
            'upsert': kwargs.get('upsert', True),
            'env': kwargs.get('env', ""),
            'dimensions': kwargs.get('dimensions', False),
            'layer': kwargs.get('layer', False),
            'product': kwargs.get('product', None),
            'errors': []
        }

        if kwargs.get("layer")  in ["raw", "landing"]:
            common_params.update({
                'bucket': kwargs['bucket'],
                'bucket_in': kwargs['bucket_in'],
                'days': kwargs.get('days', False),
                'hours': kwargs.get('hours', False),
                'partitions': kwargs.get('partitions', False),
            })
        else:
            common_params.update({
                'bucket_in': kwargs['bucket_in'],
                'bucket_out': kwargs['bucket_out'],
                'table_paths': kwargs['table_paths'],
                'partitions': kwargs.get('partitions', False),
                'date_event': kwargs.get('date_event', None),
                 'days': kwargs.get('days', False),
                'hours': kwargs.get('hours', False),
            })

        return tuple(common_params.values())

    @staticmethod
    def __initialize_configs(kwargs):
        """
        Initializes configurations for the ETL process from AWS Secrets Manager and the provided arguments.

        Args:
            kwargs (dict): Dictionary of keyword arguments passed to the `run_pipeline` method.

        Returns:
            tuple: A tuple containing:
                - dict: SQL parameters fetched from AWS Secrets Manager.
                - list: List of endpoint configurations.
                - dict: Dictionary containing global queries.
                - dict: A dictionary containing table configurations.
                - dict: A dictionary containing table-specific configurations for processing.
        """

        awsmanager = AwsManager(region="eu-west-1")
        sql_params = awsmanager.get_secret(secret=kwargs['connections'])
        datasources = json.loads(sql_params.get(f"datasources_{kwargs['product']}"))
        endpoints = datasources.get("endpoints")
        global_queries = datasources.get("queries")
        tables = json.loads(sql_params.get(f"tables_{kwargs['product']}"))
        processing_map = kwargs.get("processing_map")
        return sql_params, endpoints, global_queries, tables, processing_map
    
    @staticmethod 
    def __parse_database_data(db_data, global_queries):
        """
        Parses database data to extract or merge custom queries.

        Args:
            db_data (Union[str, dict]): Either a string representing database name or a dictionary containing database name and custom queries.
            global_queries (dict): Dictionary containing global queries.

        Returns:
            tuple: A tuple containing:
                - str: Database name.
                - dict: Merged queries for the database.

        Raises:
            ValueError: If the format of db_data is unexpected.
        """

        # Si db_data es una cadena de texto:
        if isinstance(db_data, str):
            # Si la base de datos tiene consultas personalizadas en global_queries:
            if db_data in global_queries:
                # Devuelve las consultas personalizadas fusionadas con las por defecto
                return db_data, {**global_queries[db_data]}
            else:
                # De lo contrario, devuelve solo las consultas por defecto
                return db_data, global_queries['default']
        
        # Si db_data es un diccionario:
        elif isinstance(db_data, dict) and db_data:
            dbname, custom_queries = list(db_data.items())[0]
            return dbname, {**global_queries['default'], **custom_queries}
        else:
            raise ValueError("Unexpected database data format.")
        
    @staticmethod 
    def __get_specific_query_for_table(table_name, query_dict):
        """
        Retrieves a specific query for a given table name from the provided query dictionary.

        Args:
            table_name (str): The table name for which to fetch the query.
            query_dict (dict): Dictionary containing queries mapped by table names.

        Returns:
            str or None: The specific query for the table or None if not found.
        """

        query_key = f"{table_name}_query"

        # Try to get the specific query for the database
        specific_query = query_dict.get(query_key)

        # If we can't find the specific query, try to get it from the default
        if not specific_query:
            specific_query = query_dict.get("default", {}).get(query_key)

        return specific_query

    @staticmethod  
    def __merge_dataframes(dfs_dict):
        """
        Merges dataframes of the same table name present in the provided dictionary.

        Args:
            dfs_dict (dict): A dictionary with table names as keys and lists of DataFrames as values.

        Returns:
            dict: A dictionary with table names as keys and merged DataFrames as values.
        """

        for table_name, dfs_list in dfs_dict.items():
            if len(dfs_list) > 1:
                dfs_dict[table_name] = reduce(lambda df1, df2: df1.unionByName(df2, allowMissingColumns=True), dfs_list)
            else:
                dfs_dict[table_name] = dfs_list[0]
        return dfs_dict
    
    @staticmethod  
    def __extract(spark, dfs_dict, endpoints, global_queries, processing_map, sql_params, tables, days, hours, bucket_in):
        """
        Extracts data from the JDBC source based on the provided configurations and appends it to the dfs_dict.

        Args:
            spark (SparkSession): The active Spark session.
            dfs_dict (dict): A dictionary to append extracted dataframes.
            endpoints (list): A list of endpoint configurations.
            global_queries (dict): Dictionary containing global queries.
            processing_map (dict): A dictionary containing table-specific configurations for processing.
            sql_params (dict): Dictionary containing SQL connection parameters.
            tables (dict): A dictionary containing table configurations.
            days (bool or int): Number of days to filter data or False to fetch all data.

        Returns:
            dict: Updated dfs_dict with extracted dataframes.
        """
 
        for endpoint in endpoints:
            for db_data in endpoint['databases']:
                dbname, query_dict = Pipeline.__parse_database_data(db_data, global_queries)

                for table_name, table_info in processing_map.items():
                    if table_name == "VideoUnassistedImagesCaptures":
                        print(table_name)
                    specific_query = Pipeline.__get_specific_query_for_table(table_name, query_dict)
                    if  table_info.get('type') == "jdbc":
                    
                        # If we still can't find the query, we print the error message and continue to the following table
                        if not specific_query:
                            print(f"The database {dbname} does not have a query for the table {table_name}. Skipping...")
                            continue
                        
                        df = read_jdbc(
                            spark=spark,
                            url=endpoint.get("url") + dbname,
                            table_name=tables.get(f"{table_name}_table"), 
                            dbname=dbname,
                            dbtable=specific_query,
                            username=sql_params.get("username"),
                            password=sql_params.get("password"),
                            days=days,
                            hours= hours
                        )
                        df.cache()
                        
                        try:
                            df = table_info.get('function')(df, dbname)
                        except:
                            df = table_info.get('function')(df)
                         # Si no existe una lista para esta tabla, crea una
                        if table_name not in dfs_dict:
                            dfs_dict[table_name] = []

                        # Agrega el DataFrame a la lista de esta tabla
                        dfs_dict[table_name].append(df)
                        
            
        for table_name, table_info in processing_map.items():
            if table_info.get('type') == "datalake":
                    path = f"{table_info.get('source_path')}"
                    df = read_datalake(spark=spark, basepath=bucket_in, path=path, format=table_info.get('format'))
                    df = table_info.get('function')(spark, df)
                    
                        # Agrega el DataFrame a la lista de esta tabla
                    dfs_dict[table_name] = [df]   
            
            
                    
        return dfs_dict
    
    @staticmethod
    def __load(**kwargs):
        if kwargs.get('layer') in ['raw', 'landing']:
            spark, dfs_dict, bucket, env, processing_map, partitions, upsert, errors, dimensions = (
                kwargs['spark'], kwargs['dfs_dict'], kwargs['bucket'], kwargs['env'],
                kwargs['processing_map'], kwargs['partitions'], kwargs['upsert'],
                kwargs['errors'], kwargs.get('dimensions', False)
            )
        else:
            spark, dfs_dict, bucket, env, partitions, errors, upsert,product, dimensions = (
                kwargs['spark'], kwargs['dfs_dict'], kwargs['bucket_out'].replace("raw", "curated"), kwargs['env'],
                kwargs['partitions'], kwargs['errors'], kwargs['upsert'],kwargs.get('product','va'), kwargs.get('dimensions', False)
            )
        import datetime as dt
        ActivityDate = dt.datetime.now()
        ActivityDate_str = ActivityDate.strftime('%Y-%m-%d %H:%M:%S.%f')

        def __write_dataframe_to_aws(df, table_name,version, path, partitions, merge_conditions, upsert):
            df = df.withColumn("ActivityDate", lit(ActivityDate))
            result = write_aws(
                spark=spark,
                df=df,
                bucket=bucket,
                prefix=env + path + table_name,
                partitions=None if table_name == "customers" or table_name == "agents"  else partitions,
                upsert=upsert,
                format="delta",
                merge_conditions=merge_conditions,
            )
            if result:
                errors.append(result)

        def __process_dimensions(product):
            from ...videoid.assisted.model.model_dimension import DIMENSIONS as VA_DIMENSIONS
            from ...videoid.unassisted.model.model_dimension import DIMENSIONS as VU_DIMENSIONS
            from pyspark.sql.types import StructType
            
            if product=='va':
                DIMENSIONS = VA_DIMENSIONS
            elif product=='vu':
                DIMENSIONS = VU_DIMENSIONS
            
            for table_config in DIMENSIONS:
                # Crear esquema
                schema = StructType()
                for field in table_config["schema"]:
                    field_type = globals()[field["type"]]()
                    schema.add(field["name"], field_type, field["nullable"])
                # Crear DataFrame
                df = spark.createDataFrame(table_config["data"], schema=schema)

                # Obtener el nombre de la tabla
                table_name = table_config["table_name"]
                version = table_config["version"]
                path = f"tc/{product}/"
                merge_conditions = False
                partitions = None
                # Escribir DataFrame a la tabla
                __write_dataframe_to_aws(df, table_name, version, path, partitions, merge_conditions, upsert)

        def __process_dfs_dict(partitions= None):
            """
            Process and write dataframes to AWS based on the given 'layer' (either 'raw' or 'curated').
            
            Args:
            - No direct arguments. Uses `kwargs` implicitly to determine the processing layer.
            
            Returns:
            - None. The function writes dataframes to AWS directly.
            
            Raises:
            - ValueError: If the provided layer is neither 'raw' nor 'curated'.
            """
            
            for table_name, df in dfs_dict.items():
                if kwargs.get('layer') in ["raw", "landing"]:
                    table_info = processing_map.get(table_name)
                    
                    path = table_info.get('path')
                    version = table_info.get('version')
                    merge_conditions = table_info.get('merge_conditions')
                    partitions_ = False if table_info.get('dm') else partitions
                    # Add other 'raw' layer specific configurations here if needed.
                    
                    __write_dataframe_to_aws(df, table_name, version, path, partitions_, merge_conditions, upsert)
                
                #TODO REFECTORY    
                elif kwargs.get('layer') == "curated":
                    table_info = dfs_dict.get(table_name)  # Assuming you want to fetch from dfs_dict for the 'curated' layer.
                    
                    df = table_info.get('table')  # Ensure this is the desired action.
                    path = table_info.get('path')
                    version = table_info.get('version')
                    partitions = False if table_info.get('type') == "dm" else partitions
                    merge_conditions = table_info.get('merge_conditions', False)
                    # Add other 'curated' layer specific configurations here if needed.
                    
                    __write_dataframe_to_aws(df, table_name, version, path, partitions, merge_conditions, upsert)
                    
                else:
                    raise ValueError(f"Provided layer '{kwargs.get('layer')}' is not recognized. Expected 'raw' or 'curated'.")



        if dimensions:
            __process_dimensions(product=product)

        __process_dfs_dict(partitions)

        if errors:
            raise Exception("Errors occurred during processing: ", errors)

        return ActivityDate_str

    @staticmethod
    def __extract_from_datalake(spark, bucket_in, date_event, table_paths, days, hours):
        """
        Extracts data from the data lake and filters it based on the activity date.

        Parameters:
        - spark (SparkSession): An active Spark session.
        - bucket_in (str): AWS bucket to read the data from.
        - date_event (str): Date string to filter the data.
        - dimensions (bool): Flag to indicate whether to extract dimensions data or not.

        Returns:
        dict: A dictionary containing extracted dataframes.

        Note:
        The function reads data from several paths defined in the 'paths' dictionary. 
        For each path, it reads the data in parquet format and filters it based on the 
        'ActivityDate' if the 'filter' flag for that path is True. 
        The resulting dataframes are stored in a dictionary with the same keys as the 'paths' 
        dictionary and returned.
        """
        table_paths = table_paths


        dfs = {}
        for name, info in table_paths.items():
            df = read_datalake(spark=spark, basepath=bucket_in, path=info['path'], format="delta")
            if info['filter'] and date_event:
                if info.get('column_to_filter'):
                    if days:
                        df = df.filter(col(info['column_to_filter']) >= expr(f"current_timestamp() - INTERVAL {days} DAYS"))
                    if hours:
                        df = df.filter(col(info['column_to_filter']) >= expr(f"current_timestamp() - INTERVAL {hours} HOURS"))
                else:
                    df = df.filter(col("ActivityDate") == date_event)
            dfs[name] = df

        return dfs


    @staticmethod
    @timer
    def run(**kwargs):
        """
        Runs the ETL pipeline: reads from JDBC, processes the data, and writes to AWS.

        Args:
            spark (SparkSession): The Spark session.
            ... [rest of the arguments, similar to your original docstring]
        Raises:
            ValueError: If required parameters are not provided.
            Exception: If an error occurs during the pipeline execution.
        """

        Pipeline.__validate_parameters(kwargs)
        layer = kwargs.get("layer")

        if layer in ["raw", "landing"]:
            return Pipeline.__run_raw_layer(kwargs)
        elif layer == "curated":
            return Pipeline.__run_curated_layer(kwargs)
        else:
            raise ValueError(f"Unsupported layer: {layer}")

    @staticmethod
    def __run_raw_layer(kwargs):
        # Initialize values and configurations
        spark, upsert, env, dimensions,layer, product, errors, bucket, bucket_in, days, hours, partitions = Pipeline.__extract_common_parameters(kwargs)
        sql_params, endpoints, global_queries, tables, processing_map = Pipeline.__initialize_configs(kwargs)
        
        # ETL process
        dfs_dict = defaultdict(list)
        
        # Extract
        dfs_dict = Pipeline.__extract(spark, dfs_dict, endpoints, global_queries, processing_map, sql_params, tables, days, hours, bucket_in)
        
        # Transform
        dfs_dict = Pipeline.__merge_dataframes(dfs_dict)
        
        # Load
        return Pipeline.__load(spark=spark, dfs_dict=dfs_dict, bucket=bucket, env=env, processing_map=processing_map,partitions=partitions,errors=errors, upsert=upsert, layer=layer)

    @staticmethod
    def __run_curated_layer(kwargs):
        spark, upsert, env, dimensions, layer, product, errors, bucket_in, bucket_out, table_paths, partitions, date_event, days, hours = Pipeline.__extract_common_parameters(kwargs)
               
            # Extract
        dfs = Pipeline.__extract_from_datalake(spark, bucket_in, date_event, table_paths, days, hours )
            
        for transformation_layer in kwargs.get('transformation_layers'):

            dfs_transformed = transformation_layer.transform(dfs, spark)

            transformed_dfs_dict = transformation_layer.get_processing_map(dfs_transformed)

            if 'dfs_dict' in locals():
                dfs_dict.update(transformed_dfs_dict)
            else:
                dfs_dict = transformed_dfs_dict
                    
        return Pipeline.__load(spark=spark, dfs_dict=dfs_dict, bucket_out=bucket_out, env=env, partitions=partitions,errors=errors, upsert=upsert, layer=layer, dimensions=dimensions,product=product)

    